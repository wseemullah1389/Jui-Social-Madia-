JUI Social Media - GitHub APK build package

IMPORTANT:
This ZIP contains Android project files AND the GitHub Actions workflow.
Uploading this ZIP as a single ZIP file to a GitHub repository will NOT activate the workflow.
GitHub must have the project files extracted into the repository root, and the workflow file must be at:
.github/workflows/android-apk.yml

If you are using GitHub on a phone, do not delete this ZIP. The easiest path is to upload the project ZIP to the repository, then separately create the workflow file at the exact path above and paste the contents of .github/workflows/android-apk.yml from this package.

This build attempt may still fail if the Android source project has build errors. The included app source currently has Firebase configuration; it is not yet connected to the separate Supabase backend.
