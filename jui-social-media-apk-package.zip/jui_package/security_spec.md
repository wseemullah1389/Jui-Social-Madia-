# JUI Social Madia — Firestore Security Specification (Phase 0 TDD)

## 1. Data Invariants
1. **Permanent Super Owner Protection (`/platform_config/super_owner`)**:
   - Can only be created once when `/platform_config/super_owner` does not exist.
   - `ownerUid` is strictly immutable (`incoming().ownerUid == existing().ownerUid`) and the document can never be deleted (`allow delete: if false`).
   - No admin or user can demote, suspend, block, delete, or replace the Super Owner.
2. **Global Admin Boundaries (`/admin_roles/{adminUid}`)**:
   - Only the Super Owner can create, update, or delete global admin role documents.
   - Ordinary admins cannot modify their own permission boundaries or grant privileges to others.
3. **Append-Only Administrative Audit Log (`/audit_logs/{logId}`)**:
   - Only the Super Owner can read (`get`, `list`) audit logs.
   - Only the Super Owner or authorized admins with `reauthVerified == true` can append (`create`) logs.
   - `update` and `delete` are permanently denied (`if false`).
4. **Video Approval Isolation (`/videos/{videoId}`)**:
   - Every uploaded video must be created with `status == 'PENDING'`, `fileMimeType` in `['video/mp4', 'video/webm', 'video/quicktime']`, and `fileSizeBytes <= 104857600`.
   - Pending or rejected videos cannot be read or listed by other ordinary users; only `status == 'APPROVED'`, the uploader (`authorUid == request.auth.uid`), or moderators with `canApproveVideos == true` can read/list them.
5. **Private Messaging Isolation (`/conversations/{conversationId}`, `/messages/{messageId}`)**:
   - Only the two conversation participants (`request.auth.uid in resource.data.participantUids`) can read or list conversations and messages.
   - Ordinary admins cannot snoop on private messages.
   - Blocked users cannot send messages or follow the user who blocked them.
6. **Group Roles & Optional Post Moderation (`/groups/{groupId}`, `/group_members/{membershipId}`, `/group_posts/{postId}`)**:
   - When a group has `requirePostApproval == true`, new posts must start with `status == 'PENDING'` and are only visible to the author, group moderators/admins (`request.auth.uid in resource.data.moderatorUids`), or global group admins until approved.

## 2. The Dirty Dozen Adversarial Payloads
1. **Unauthenticated Read**: Unauthenticated client attempts to read `/videos` or `/users`.
2. **Direct Approved Video Upload Bypass**: Authenticated user attempts to create `/videos/vid_1` with `status: "APPROVED"`.
3. **Unauthorized Pending Video Read**: User B attempts to `get` or `list` User A's `PENDING` video.
4. **Admin Self-Privilege Escalation**: Admin with `canApproveVideos: true, canManageGroups: false` attempts to update `/admin_roles/{adminUid}` to set `canManageGroups: true`.
5. **Admin Attempting to Demote/Replace Super Owner**: Admin attempts to update `/platform_config/super_owner` with a new `ownerUid` or delete `/platform_config/super_owner`.
6. **Admin Attempting to Suspend or Block Super Owner**: Admin or user attempts to set `accountStatus: "SUSPENDED"` on the Super Owner's profile or create a block against the Super Owner.
7. **Audit Log Tampering**: Admin attempts to update or delete an entry in `/audit_logs/{logId}`, or read `/audit_logs` without being Super Owner.
8. **Private Message Snooping by Admin**: Global admin who is not a participant attempts to `get` or `list` `/messages/{messageId}`.
9. **Blocked User Harassment**: Blocked user attempts to send a message or follow the user who blocked them.
10. **Duplicate Username Hijack**: User B attempts to register `/usernames/{username}` already claimed by User A.
11. **Unapproved Group Post Bypass**: Member of a group with `requirePostApproval: true` attempts to create a group post with `status: "APPROVED"`.
12. **Shadow Field / Resource Poisoning**: Authenticated user sends an unlisted ghost field (`isVerified: true`) or oversized string on `/users/{userId}`.
