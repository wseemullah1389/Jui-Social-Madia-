package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.test.core.app.ApplicationProvider
import com.example.ui.components.JuiSplashScreen
import com.example.ui.components.JuiWordmarkHeader
import com.example.ui.theme.JuiSocialMadiaTheme
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @get:Rule
  val composeTestRule = createComposeRule()

  @Test
  fun appNameResource_isExactJuiSocialMadia() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("JUI Social Madia", appName)
  }

  @Test
  fun splashScreenAndWordmark_renderExactBrandName() {
    composeTestRule.setContent {
      JuiSocialMadiaTheme {
        JuiSplashScreen(onContinue = {})
      }
    }
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("splash_screen").assertIsDisplayed()
    composeTestRule.onNodeWithText("JUI Social Madia").assertIsDisplayed()
    composeTestRule.onNodeWithTag("splash_continue_button").assertIsDisplayed()
  }

  @Test
  fun wordmarkHeader_displaysOfficialBranding() {
    composeTestRule.setContent {
      JuiSocialMadiaTheme {
        JuiWordmarkHeader(subtitle = "Verified Short-Video Feed")
      }
    }
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("jui_wordmark_title").assertIsDisplayed()
    composeTestRule.onNodeWithText("JUI Social Madia").assertIsDisplayed()
  }
}
