package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.CommunityGroup
import com.example.data.model.GroupMember
import com.example.data.model.ShortVideo
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestoreException
import java.util.UUID
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class JuiSocialRepositoryRuleTest : FirestoreEmulatorTestBase() {

  private fun uniqueSuffix(): String = UUID.randomUUID().toString().replace("-", "").take(8)

  @Test
  fun observeApprovedFeed_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
    auth.signOut()
    val repo = JuiSocialRepository(firestore, auth)

    var caught: Throwable? = null
    try {
      withTimeout(FLOW_TIMEOUT_MS) {
        repo.observeApprovedFeed().first()
      }
    } catch (e: Throwable) {
      caught = e
    }
    assertNotNull("Expected unauthenticated feed query to fail", caught)
    val fsEx = checkNotNull(caught?.unwrapFirestoreException()) {
      "Expected nested FirebaseFirestoreException, got $caught"
    }
    assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx.code)
  }

  @Test
  fun registerUserProfile_duplicateUsername_isDeniedByBackend() = runBlocking {
    val suffix = uniqueSuffix()
    val sharedUsername = "juiuser_$suffix"

    signInTestUser("alice_$suffix@test.com")
    val aliceRepo = JuiSocialRepository(firestore, auth)
    val firstRes = withTimeout(DEFAULT_TIMEOUT_MS) {
      aliceRepo.registerUserProfile(
        username = sharedUsername,
        displayName = "Alice JUI",
        bio = "Creator",
      )
    }
    assertTrue("First registration should succeed: ${firstRes.exceptionOrNull()}", firstRes.isSuccess)

    signInTestUser("bob_$suffix@test.com")
    val bobRepo = JuiSocialRepository(firestore, auth)
    val dupRes = withTimeout(DEFAULT_TIMEOUT_MS) {
      bobRepo.registerUserProfile(
        username = sharedUsername,
        displayName = "Bob Duplicate",
        bio = "Duplicate test",
      )
    }
    assertTrue("Duplicate username registration must fail", dupRes.isFailure)
  }

  @Test
  fun videoApprovalAndSuperOwnerGovernance_enforcesAllSecurityInvariants() = runBlocking {
    val suffix = uniqueSuffix()

    // 1. Sign in as Super Owner using the bootstrapped owner email or first-time setup
    val ownerUid = signInTestUser("owner_$suffix@test.com")
    val ownerRepo = JuiSocialRepository(firestore, auth)
    // Claim Super Owner if not yet claimed in this emulator session
    val existingOwnerSnap = withTimeout(DEFAULT_TIMEOUT_MS) {
      firestore.collection("platform_config").document("super_owner").get().await()
    }
    val activeOwnerUid = if (!existingOwnerSnap.exists()) {
      val claimRes = withTimeout(DEFAULT_TIMEOUT_MS) {
        ownerRepo.claimInitialSuperOwner("Founder Super Owner", reauthVerified = true)
      }
      assertTrue("Initial Super Owner setup should succeed: ${claimRes.exceptionOrNull()}", claimRes.isSuccess)
      ownerUid
    } else {
      existingOwnerSnap.getString("ownerUid") ?: ownerUid
    }

    // Ensure we are signed in as the active Super Owner
    val modEmail = "moderator_$suffix@test.com"
    val modUid = signInTestUser(modEmail)

    // Sign back in as Super Owner to appoint modUid as a video moderator (without group or admin management)
    signInTestUser("owner_$suffix@test.com")
    if (activeOwnerUid == ownerUid) {
      val assignRes = withTimeout(DEFAULT_TIMEOUT_MS) {
        ownerRepo.assignOrUpdateAdminRole(
          targetAdminUid = modUid,
          targetAdminName = "Video Mod",
          canApproveVideos = true,
          canModerateComments = true,
          canManageReports = false,
          canManageGroups = false,
          canManageAppeals = false,
          actorName = "Founder Super Owner",
          reauthVerified = true,
        )
      }
      assertTrue("Super Owner appointing admin should succeed: ${assignRes.exceptionOrNull()}", assignRes.isSuccess)
    }

    // 2. Sign in as Moderator and verify that Owner Demotion, Owner Deletion, and Privilege Escalation are DENIED
    signInTestUser(modEmail)
    val modRepo = JuiSocialRepository(firestore, auth)

    // Attempt 1: Moderator tries to escalate own privileges (granting canManageGroups = true) -> DENIED
    val escalationRes = withTimeout(DEFAULT_TIMEOUT_MS) {
      modRepo.assignOrUpdateAdminRole(
        targetAdminUid = modUid,
        targetAdminName = "Escalated Mod",
        canApproveVideos = true,
        canModerateComments = true,
        canManageReports = true,
        canManageGroups = true,
        canManageAppeals = true,
        actorName = "Video Mod",
        reauthVerified = true,
      )
    }
    assertTrue("Admin self-privilege escalation must be denied", escalationRes.isFailure)

    // Attempt 2: Moderator tries to demote/replace Super Owner -> DENIED
    val demoteAttempt = runCatching {
      withTimeout(DEFAULT_TIMEOUT_MS) {
        firestore.collection("platform_config").document("super_owner").update(
          mapOf(
            "ownerUid" to modUid,
            "reauthVerified" to true,
            "updatedAt" to FieldValue.serverTimestamp(),
          )
        ).await()
      }
    }
    assertTrue("Owner demotion/replacement attempt must be denied", demoteAttempt.isFailure)

    // Attempt 3: Moderator tries to delete Super Owner config -> DENIED
    val deleteOwnerAttempt = runCatching {
      withTimeout(DEFAULT_TIMEOUT_MS) {
        firestore.collection("platform_config").document("super_owner").delete().await()
      }
    }
    assertTrue("Owner deletion attempt must be denied", deleteOwnerAttempt.isFailure)

    // 3. Sign in as Alice, upload a video: must start as PENDING; direct APPROVED upload must fail
    val aliceUid = signInTestUser("alice_vid_$suffix@test.com")
    val aliceRepo = JuiSocialRepository(firestore, auth)

    val bypassUpload = withTimeout(DEFAULT_TIMEOUT_MS) {
      aliceRepo.uploadShortVideo(
        authorUsername = "alice_$suffix",
        authorDisplayName = "Alice",
        caption = "Bypass attempt",
        hashtags = "#jui",
        videoUrl = "jui://media/bypass.mp4",
        audioTitle = "JUI Synth",
        audioLicense = "CC-BY 4.0",
        forcedStatusForTest = "APPROVED",
      )
    }
    assertTrue("Uploading video directly with APPROVED status must be denied", bypassUpload.isFailure)

    val pendingUpload = withTimeout(DEFAULT_TIMEOUT_MS) {
      aliceRepo.uploadShortVideo(
        authorUsername = "alice_$suffix",
        authorDisplayName = "Alice",
        caption = "My Pending Short Video #jui",
        hashtags = "#jui",
        videoUrl = "jui://media/valid.mp4",
        audioTitle = "JUI Synth",
        audioLicense = "CC-BY 4.0",
      )
    }
    assertTrue("Valid PENDING video upload should succeed: ${pendingUpload.exceptionOrNull()}", pendingUpload.isSuccess)
    val videoId = pendingUpload.getOrThrow()

    // 4. Sign in as Bob (another ordinary user): Bob CANNOT read Alice's PENDING video
    val bobUid = signInTestUser("bob_vid_$suffix@test.com")
    val bobRepo = JuiSocialRepository(firestore, auth)
    val bobReadPending = withTimeout(DEFAULT_TIMEOUT_MS) {
      bobRepo.getVideoById(videoId)
    }
    assertTrue("Other user reading PENDING video must be denied", bobReadPending.isFailure)

    // 5. If activeOwnerUid == ownerUid, Moderator approves Alice's video, and Bob can then read it
    if (activeOwnerUid == ownerUid) {
      signInTestUser(modEmail)
      val pendingVideoObj = withTimeout(DEFAULT_TIMEOUT_MS) {
        modRepo.getVideoById(videoId).getOrThrow()
      }
      assertNotNull(pendingVideoObj)
      val approveRes = withTimeout(DEFAULT_TIMEOUT_MS) {
        modRepo.moderateVideo(
          video = pendingVideoObj!!,
          approve = true,
          rejectionReason = "",
          moderatorName = "Video Mod",
          reauthVerified = true,
        )
      }
      assertTrue("Moderator approving video should succeed: ${approveRes.exceptionOrNull()}", approveRes.isSuccess)

      signInTestUser("bob_vid_$suffix@test.com")
      val bobReadApproved = withTimeout(DEFAULT_TIMEOUT_MS) {
        bobRepo.getVideoById(videoId)
      }
      assertTrue("Other user reading APPROVED video should succeed", bobReadApproved.isSuccess)
      assertEquals("APPROVED", bobReadApproved.getOrThrow()?.status)
    }

    // 6. Private Messaging & Blocking test between Alice and Bob
    signInTestUser("alice_vid_$suffix@test.com")
    val sendMsgRes = withTimeout(DEFAULT_TIMEOUT_MS) {
      aliceRepo.sendPrivateMessage(
        senderName = "Alice",
        recipientUid = bobUid,
        recipientName = "Bob",
        text = "Hi Bob on JUI Social Madia!",
      )
    }
    assertTrue("Sending private message should succeed: ${sendMsgRes.exceptionOrNull()}", sendMsgRes.isSuccess)
    val msgId = sendMsgRes.getOrThrow()

    // Moderator (non-participant) attempting to read Alice & Bob's private message -> DENIED
    signInTestUser(modEmail)
    val modSnoopAttempt = runCatching {
      withTimeout(DEFAULT_TIMEOUT_MS) {
        firestore.collection("messages").document(msgId).get().await()
      }
    }
    assertTrue("Non-participant admin reading private message must be denied", modSnoopAttempt.isFailure)

    // 7. Group creation and optional post approval test
    signInTestUser("alice_vid_$suffix@test.com")
    val groupRes = withTimeout(DEFAULT_TIMEOUT_MS) {
      aliceRepo.createGroup(
        name = "JUI Filmmakers $suffix",
        description = "Short video creators group",
        creatorName = "Alice",
        requirePostApproval = true,
        isPublic = true,
      )
    }
    assertTrue("Creating group should succeed: ${groupRes.exceptionOrNull()}", groupRes.isSuccess)
    val groupId = groupRes.getOrThrow()
    val groupObj = CommunityGroup(
      id = groupId,
      name = "JUI Filmmakers $suffix",
      description = "Short video creators group",
      creatorUid = aliceUid,
      creatorName = "Alice",
      requirePostApproval = true,
      isPublic = true,
      membersCount = 1L,
      moderatorUids = listOf(aliceUid),
    )

    // Bob requests membership, Alice approves Bob, Bob tries to bypass post approval -> DENIED
    signInTestUser("bob_vid_$suffix@test.com")
    val reqMember = withTimeout(DEFAULT_TIMEOUT_MS) {
      bobRepo.requestGroupMembership(groupObj, "Bob")
    }
    assertTrue("Requesting group membership should succeed", reqMember.isSuccess)

    signInTestUser("alice_vid_$suffix@test.com")
    val approveMember = withTimeout(DEFAULT_TIMEOUT_MS) {
      aliceRepo.approveGroupMember(
        GroupMember(
          id = "${groupId}_$bobUid",
          groupId = groupId,
          userId = bobUid,
          username = "Bob",
          role = "MEMBER",
          status = "PENDING",
          moderatorUids = listOf(aliceUid),
        )
      )
    }
    assertTrue("Approving group member should succeed: ${approveMember.exceptionOrNull()}", approveMember.isSuccess)

    signInTestUser("bob_vid_$suffix@test.com")
    val bypassGroupPost = withTimeout(DEFAULT_TIMEOUT_MS) {
      bobRepo.createGroupPost(
        group = groupObj,
        authorName = "Bob",
        contentType = "TEXT",
        text = "Direct approved bypass",
        forcedStatusForTest = "APPROVED",
      )
    }
    assertTrue("Bypassing group post approval must be denied", bypassGroupPost.isFailure)

    val validPendingPost = withTimeout(DEFAULT_TIMEOUT_MS) {
      bobRepo.createGroupPost(
        group = groupObj,
        authorName = "Bob",
        contentType = "TEXT",
        text = "Pending group post for review",
      )
    }
    assertTrue("Submitting pending group post should succeed: ${validPendingPost.exceptionOrNull()}", validPendingPost.isSuccess)
    val postId = validPendingPost.getOrThrow()

    signInTestUser("alice_vid_$suffix@test.com")
    val approvePostRes = withTimeout(DEFAULT_TIMEOUT_MS) {
      aliceRepo.moderateGroupPost(postId, approve = true)
    }
    assertTrue("Group moderator approving post should succeed: ${approvePostRes.exceptionOrNull()}", approvePostRes.isSuccess)
  }

  private companion object {
    const val DEFAULT_TIMEOUT_MS = 5000L
    const val FLOW_TIMEOUT_MS = 3000L
  }
}
