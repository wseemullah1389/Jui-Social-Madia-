package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.model.UiState
import com.example.data.repository.JuiSocialRepository
import com.example.ui.JuiSocialViewModel
import com.example.ui.auth.JuiAuthAndOnboardingScreen
import com.example.ui.auth.ProfileRegistrationGateScreen
import com.example.ui.auth.signOutJuiUser
import com.example.ui.components.JuiSplashScreen
import com.example.ui.screens.AdminAndSuperOwnerDashboardScreen
import com.example.ui.screens.GroupsAndCommunitiesScreen
import com.example.ui.screens.NotificationsAndPrivateInboxScreen
import com.example.ui.screens.ProfileAndSettingsScreen
import com.example.ui.screens.ShortVideoFeedScreen
import com.example.ui.screens.VideoUploadAndPendingStatusScreen
import com.example.ui.theme.JuiCardSurface
import com.example.ui.theme.JuiCyanAccent
import com.example.ui.theme.JuiDeepSurface
import com.example.ui.theme.JuiMidnight
import com.example.ui.theme.JuiSocialMadiaTheme
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

internal fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
  val listener = FirebaseAuth.AuthStateListener { auth ->
    trySend(auth.currentUser)
  }
  addAuthStateListener(listener)
  awaitClose { removeAuthStateListener(listener) }
}

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      JuiSocialMadiaTheme {
        JuiSocialRootApp()
      }
    }
  }
}

@Composable
fun JuiSocialRootApp() {
  var showSplash by rememberSaveable { mutableStateOf(true) }

  if (showSplash) {
    JuiSplashScreen(onContinue = { showSplash = false })
    return
  }

  val auth = remember { Firebase.auth }
  val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
  val user = currentUser

  if (user == null) {
    JuiAuthAndOnboardingScreen(
      onAuthSuccess = {}
    )
  } else {
    JuiAuthenticatedNavigation(
      currentUserId = user.uid,
      currentUserEmail = user.email,
      suggestedDisplayName = user.displayName ?: "JUI Creator",
    )
  }
}

@Composable
fun JuiAuthenticatedNavigation(
  currentUserId: String,
  currentUserEmail: String?,
  suggestedDisplayName: String,
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()

  val viewModel: JuiSocialViewModel = viewModel(
    key = currentUserId,
    factory = viewModelFactory {
      initializer {
        val app = checkNotNull(this[APPLICATION_KEY]) {
          "APPLICATION_KEY missing from CreationExtras"
        }
        val databaseId = app.getString(R.string.firestore_database_id)
        val db = FirebaseFirestore.getInstance(databaseId)
        JuiSocialViewModel(
          repository = JuiSocialRepository(db, Firebase.auth),
          currentUserId = currentUserId,
          currentUserEmail = currentUserEmail,
        )
      }
    }
  )

  val profileState by viewModel.currentUserProfile.collectAsStateWithLifecycle()
  val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()
  val isBusy by viewModel.isBusy.collectAsStateWithLifecycle()

  val feedState by viewModel.approvedFeedState.collectAsStateWithLifecycle()
  val myUploadedVideos by viewModel.myUploadedVideos.collectAsStateWithLifecycle()
  val likedVideoIds by viewModel.likedVideoIds.collectAsStateWithLifecycle()
  val savedVideoIds by viewModel.savedVideoIds.collectAsStateWithLifecycle()
  val activeVideoForComments by viewModel.selectedVideoForComments.collectAsStateWithLifecycle()
  val activeComments by viewModel.activeVideoComments.collectAsStateWithLifecycle()

  val activeProfiles by viewModel.activeProfiles.collectAsStateWithLifecycle()
  val followingList by viewModel.followingList.collectAsStateWithLifecycle()
  val followersList by viewModel.followersList.collectAsStateWithLifecycle()
  val blockedUsers by viewModel.blockedUsers.collectAsStateWithLifecycle()

  val notifications by viewModel.notifications.collectAsStateWithLifecycle()
  val conversations by viewModel.conversations.collectAsStateWithLifecycle()
  val privateMessages by viewModel.privateMessages.collectAsStateWithLifecycle()

  val publicGroups by viewModel.publicGroups.collectAsStateWithLifecycle()
  val myGroupMemberships by viewModel.myGroupMemberships.collectAsStateWithLifecycle()
  val pendingGroupRequests by viewModel.pendingGroupRequestsForMe.collectAsStateWithLifecycle()
  val pendingGroupPosts by viewModel.pendingGroupPostsForMe.collectAsStateWithLifecycle()
  val selectedGroup by viewModel.selectedGroup.collectAsStateWithLifecycle()
  val selectedGroupPosts by viewModel.selectedGroupApprovedPosts.collectAsStateWithLifecycle()
  val selectedGroupMembers by viewModel.selectedGroupApprovedMembers.collectAsStateWithLifecycle()

  val myReports by viewModel.myReports.collectAsStateWithLifecycle()
  val superOwnerConfig by viewModel.superOwnerConfig.collectAsStateWithLifecycle()
  val currentAdminRole by viewModel.currentAdminRole.collectAsStateWithLifecycle()
  val pendingModerationVideos by viewModel.pendingModerationVideos.collectAsStateWithLifecycle()
  val openAdminReports by viewModel.openAdminReports.collectAsStateWithLifecycle()
  val allAdminRoles by viewModel.allAdminRoles.collectAsStateWithLifecycle()
  val auditLogs by viewModel.auditLogs.collectAsStateWithLifecycle()

  when (val pState = profileState) {
    is UiState.Loading -> {
      Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center,
      ) {
        CircularProgressIndicator(color = JuiCyanAccent)
      }
      return
    }
    is UiState.Error -> {
      ProfileRegistrationGateScreen(
        suggestedDisplayName = suggestedDisplayName,
        isSubmitting = isBusy,
        errorMessage = statusBanner ?: pState.message,
        onSubmitRegistration = { u, d, b, priv, age ->
          viewModel.registerProfile(u, d, b, priv, age)
        },
        onSignOut = {
          signOutJuiUser(context, onSignOutComplete = {}, scope = scope)
        },
      )
      return
    }
    is UiState.Success -> {
      if (pState.data == null) {
        ProfileRegistrationGateScreen(
          suggestedDisplayName = suggestedDisplayName,
          isSubmitting = isBusy,
          errorMessage = statusBanner,
          onSubmitRegistration = { u, d, b, priv, age ->
            viewModel.registerProfile(u, d, b, priv, age)
          },
          onSignOut = {
            signOutJuiUser(context, onSignOutComplete = {}, scope = scope)
          },
        )
        return
      }
    }
  }

  val activeProfile = (profileState as? UiState.Success)?.data
  val isSuperOwner = viewModel.isCurrentUserSuperOwner(superOwnerConfig)
  var selectedNavTab by rememberSaveable { mutableIntStateOf(0) }

  if (selectedNavTab != 0) {
    BackHandler {
      if (selectedGroup != null) {
        viewModel.selectGroup(null)
      } else {
        selectedNavTab = 0
      }
    }
  }

  val navItems = listOf(
    Triple(0, "Feed", Icons.Default.Home),
    Triple(1, "Upload", Icons.Default.CloudUpload),
    Triple(2, "Groups", Icons.Default.Groups),
    Triple(3, "Inbox", Icons.Default.Forum),
    Triple(4, "Profile", Icons.Default.Person),
    Triple(5, "Governance", Icons.Default.AdminPanelSettings),
  )

  BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
    val isExpandedScreen = maxWidth >= 600.dp

    Scaffold(
      contentWindowInsets = WindowInsets.safeDrawing,
      containerColor = JuiMidnight,
      bottomBar = {
        if (!isExpandedScreen) {
          NavigationBar(
            containerColor = JuiDeepSurface,
            modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars),
          ) {
            navItems.forEach { (idx, label, icon) ->
              NavigationBarItem(
                selected = selectedNavTab == idx,
                onClick = { selectedNavTab = idx },
                icon = { Icon(icon, contentDescription = label) },
                label = { Text(label) },
                modifier = Modifier.testTag("bottom_nav_tab_$idx"),
              )
            }
          }
        }
      },
    ) { innerPadding ->
      Row(
        modifier = Modifier
          .fillMaxSize()
          .padding(innerPadding),
      ) {
        if (isExpandedScreen) {
          NavigationRail(containerColor = JuiDeepSurface) {
            navItems.forEach { (idx, label, icon) ->
              NavigationRailItem(
                selected = selectedNavTab == idx,
                onClick = { selectedNavTab = idx },
                icon = { Icon(icon, contentDescription = label) },
                label = { Text(label) },
                modifier = Modifier.testTag("rail_nav_tab_$idx"),
              )
            }
          }
        }

        Column(modifier = Modifier.weight(1f)) {
          if (!statusBanner.isNullOrBlank()) {
            Surface(
              color = JuiCardSurface,
              modifier = Modifier.fillMaxWidth(),
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Text(
                  text = statusBanner ?: "",
                  color = Color.White,
                  modifier = Modifier.weight(1f),
                )
                TextButton(onClick = { viewModel.clearBanner() }) {
                  Text("Dismiss", color = JuiCyanAccent)
                }
              }
            }
          }

          val approvedList = (feedState as? UiState.Success)?.data ?: emptyList()
          val myUsername = activeProfile?.username ?: "juicreator"
          val myDisplayName = activeProfile?.displayName ?: suggestedDisplayName

          when (selectedNavTab) {
            0 -> ShortVideoFeedScreen(
              feedState = feedState,
              currentUserProfile = activeProfile,
              likedVideoIds = likedVideoIds,
              savedVideoIds = savedVideoIds,
              followingList = followingList,
              allProfiles = activeProfiles,
              activeVideoForComments = activeVideoForComments,
              activeComments = activeComments,
              canModerateComments = isSuperOwner || currentAdminRole?.canModerateComments == true,
              onToggleLike = { viewModel.toggleLike(it, myUsername) },
              onToggleSave = { viewModel.toggleSave(it) },
              onShareVideo = { viewModel.recordShare(it) },
              onRecordView = { viewModel.recordView(it) },
              onToggleFollow = { targetUid, targetUsername ->
                viewModel.toggleFollow(myUsername, targetUid, targetUsername)
              },
              onOpenComments = { viewModel.selectVideoForComments(it) },
              onPostComment = { vid, text, parentId ->
                viewModel.postComment(vid, myUsername, text, parentId)
              },
              onModeratorRemoveComment = { viewModel.removeCommentAsModerator(it) },
              onReportTarget = { targetId, targetType, reason ->
                viewModel.submitSafetyReport(myUsername, targetId, targetType, reason, "Submitted from feed")
              },
              onNavigateToUpload = { selectedNavTab = 1 },
            )
            1 -> VideoUploadAndPendingStatusScreen(
              currentUserProfile = activeProfile,
              myUploadedVideos = myUploadedVideos,
              isBusy = isBusy,
              onUploadVideo = { caption, tags, url, audioTitle, audioLicense, mime, size, dur ->
                viewModel.uploadVideo(
                  authorUsername = myUsername,
                  authorDisplayName = myDisplayName,
                  caption = caption,
                  hashtags = tags,
                  videoUrl = url,
                  audioTitle = audioTitle,
                  audioLicense = audioLicense,
                  fileMimeType = mime,
                  fileSizeBytes = size,
                  durationSeconds = dur,
                )
              },
              onSubmitAppeal = { vidId, details ->
                viewModel.submitSafetyReport(myUsername, vidId, "APPEAL", "Video Moderation Appeal", details)
              },
            )
            2 -> GroupsAndCommunitiesScreen(
              currentUserId = currentUserId,
              currentUsername = myUsername,
              publicGroups = publicGroups,
              myMemberships = myGroupMemberships,
              pendingMemberRequests = pendingGroupRequests,
              pendingGroupPosts = pendingGroupPosts,
              selectedGroup = selectedGroup,
              selectedGroupPosts = selectedGroupPosts,
              selectedGroupMembers = selectedGroupMembers,
              onSelectGroup = { viewModel.selectGroup(it) },
              onCreateGroup = { name, desc, reqApproval ->
                viewModel.createCommunityGroup(name, desc, myUsername, reqApproval)
              },
              onRequestJoin = { viewModel.requestGroupJoin(it, myUsername) },
              onApproveMember = { member, role -> viewModel.approveMember(member, role) },
              onLeaveGroup = { viewModel.leaveCommunityGroup(it) },
              onCreateGroupPost = { grp, type, text, media ->
                viewModel.publishGroupPost(grp, myUsername, type, text, media)
              },
              onModerateGroupPost = { postId, approve ->
                viewModel.moderateGroupPostDecision(postId, approve)
              },
              onReportGroup = { grpId, reason ->
                viewModel.submitSafetyReport(myUsername, grpId, "GROUP", reason, "Reported from group view")
              },
            )
            3 -> NotificationsAndPrivateInboxScreen(
              currentUserId = currentUserId,
              currentUserDisplayName = myDisplayName,
              notifications = notifications,
              conversations = conversations,
              messages = privateMessages,
              allProfiles = activeProfiles,
              onMarkNotificationRead = { viewModel.markNotificationAsRead(it) },
              onSendMessage = { recUid, recName, text, retention ->
                viewModel.sendMessage(myDisplayName, recUid, recName, text, retention)
              },
              onMarkMessageRead = { viewModel.markMessageAsRead(it) },
              onBlockUser = { targetUid, targetUser, reason ->
                viewModel.blockUser(targetUid, targetUser, reason)
              },
              onReportUser = { targetUid, reason ->
                viewModel.submitSafetyReport(myUsername, targetUid, "USER", reason, "Reported from inbox")
              },
            )
            4 -> ProfileAndSettingsScreen(
              profile = activeProfile,
              isSuperOwner = isSuperOwner,
              adminRole = currentAdminRole,
              myUploadedVideos = myUploadedVideos,
              approvedFeedVideos = approvedList,
              savedVideoIds = savedVideoIds,
              followers = followersList,
              following = followingList,
              blockedUsers = blockedUsers,
              myReports = myReports,
              onUpdateProfile = { name, bio, priv ->
                viewModel.updateProfile(name, bio, priv)
              },
              onUnblockUser = { viewModel.unblockUser(it) },
              onSubmitReportOrSupport = { targetId, targetType, reason, details ->
                viewModel.submitSafetyReport(myUsername, targetId, targetType, reason, details)
              },
              onDeleteAccount = {
                viewModel.deleteOwnAccount(myUsername) {
                  signOutJuiUser(context, onSignOutComplete = {}, scope = scope)
                }
              },
              onSignOut = {
                signOutJuiUser(context, onSignOutComplete = {}, scope = scope)
              },
            )
            5 -> AdminAndSuperOwnerDashboardScreen(
              currentUserId = currentUserId,
              currentUserDisplayName = myDisplayName,
              superOwnerConfig = superOwnerConfig,
              isSuperOwner = isSuperOwner,
              adminRole = currentAdminRole,
              pendingVideos = pendingModerationVideos,
              approvedVideosCount = approvedList.size,
              activeUsers = activeProfiles,
              publicGroups = publicGroups,
              openReports = openAdminReports,
              allAdminRoles = allAdminRoles,
              auditLogs = auditLogs,
              onClaimSuperOwner = {
                viewModel.claimPermanentSuperOwner(myDisplayName)
              },
              onUpdateGlobalSettings = { status, allowReg, reqMod ->
                viewModel.updatePlatformSettings(myDisplayName, status, allowReg, reqMod)
              },
              onModerateVideo = { vid, approve, reason ->
                viewModel.moderatePendingVideo(vid, approve, reason, myDisplayName)
              },
              onResolveReport = { repId, status, note ->
                viewModel.resolveModerationReport(repId, status, note, myDisplayName)
              },
              onAssignAdminRole = { targetUid, targetName, vids, cmts, reps, grps, apps ->
                viewModel.assignAdminPermissions(
                  targetAdminUid = targetUid,
                  targetAdminName = targetName,
                  canApproveVideos = vids,
                  canModerateComments = cmts,
                  canManageReports = reps,
                  canManageGroups = grps,
                  canManageAppeals = apps,
                  actorName = myDisplayName,
                )
              },
              onRevokeAdminRole = { targetUid ->
                viewModel.revokeAdminRole(targetUid, myDisplayName)
              },
              onToggleSuspendUser = { targetUid, suspend ->
                viewModel.toggleUserAccountSuspension(targetUid, suspend, myDisplayName)
              },
            )
          }
        }
      }
    }
  }
}
