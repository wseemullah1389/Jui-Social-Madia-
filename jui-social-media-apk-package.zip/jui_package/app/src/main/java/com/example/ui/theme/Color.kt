package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val JuiMidnight = Color(0xFF0B0F19)
val JuiDeepSurface = Color(0xFF131B2E)
val JuiCardSurface = Color(0xFF1C2640)
val JuiElevatedSurface = Color(0xFF253252)

val JuiElectricBlue = Color(0xFF2563EB)
val JuiBrightBlue = Color(0xFF3B82F6)
val JuiCyanAccent = Color(0xFF06B6D4)
val JuiVioletPurple = Color(0xFF7C3AED)
val JuiNeonPurple = Color(0xFFA855F7)

val JuiTextPrimary = Color(0xFFF8FAFC)
val JuiTextSecondary = Color(0xFF94A3B8)
val JuiSuccessGreen = Color(0xFF10B981)
val JuiWarningAmber = Color(0xFFF59E0B)
val JuiDangerRed = Color(0xFFEF4444)
