package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AppNotification
import com.example.data.model.CommunityGroup
import com.example.data.model.Conversation
import com.example.data.model.GroupMember
import com.example.data.model.GroupPost
import com.example.data.model.PrivateMessage
import com.example.data.model.UserProfile
import com.example.ui.components.JuiBrandGradient
import com.example.ui.components.JuiWordmarkHeader
import com.example.ui.theme.JuiCardSurface
import com.example.ui.theme.JuiCyanAccent
import com.example.ui.theme.JuiDangerRed
import com.example.ui.theme.JuiDeepSurface
import com.example.ui.theme.JuiElectricBlue
import com.example.ui.theme.JuiMidnight
import com.example.ui.theme.JuiSuccessGreen
import com.example.ui.theme.JuiTextSecondary
import com.example.ui.theme.JuiWarningAmber

@Composable
fun GroupsAndCommunitiesScreen(
  currentUserId: String,
  currentUsername: String,
  publicGroups: List<CommunityGroup>,
  myMemberships: List<GroupMember>,
  pendingMemberRequests: List<GroupMember>,
  pendingGroupPosts: List<GroupPost>,
  selectedGroup: CommunityGroup?,
  selectedGroupPosts: List<GroupPost>,
  selectedGroupMembers: List<GroupMember>,
  onSelectGroup: (CommunityGroup?) -> Unit,
  onCreateGroup: (name: String, description: String, requirePostApproval: Boolean) -> Unit,
  onRequestJoin: (CommunityGroup) -> Unit,
  onApproveMember: (GroupMember, String) -> Unit,
  onLeaveGroup: (String) -> Unit,
  onCreateGroupPost: (CommunityGroup, String, String, String) -> Unit,
  onModerateGroupPost: (String, Boolean) -> Unit,
  onReportGroup: (String, String) -> Unit,
) {
  var groupSearchQuery by remember { mutableStateOf("") }
  var showCreateForm by remember { mutableStateOf(false) }
  var newGroupName by remember { mutableStateOf("") }
  var newGroupDesc by remember { mutableStateOf("") }
  var requirePostApproval by remember { mutableStateOf(true) }

  if (selectedGroup != null) {
    GroupDetailScreen(
      group = selectedGroup,
      currentUserId = currentUserId,
      myMembership = myMemberships.find { it.groupId == selectedGroup.id },
      approvedMembers = selectedGroupMembers,
      approvedPosts = selectedGroupPosts,
      pendingRequestsForGroup = pendingMemberRequests.filter { it.groupId == selectedGroup.id },
      pendingPostsForGroup = pendingGroupPosts.filter { it.groupId == selectedGroup.id },
      onBack = { onSelectGroup(null) },
      onRequestJoin = { onRequestJoin(selectedGroup) },
      onLeaveGroup = { onLeaveGroup(selectedGroup.id) },
      onApproveMember = onApproveMember,
      onCreatePost = { type, text, media -> onCreateGroupPost(selectedGroup, type, text, media) },
      onModeratePost = onModerateGroupPost,
      onReportGroup = { onReportGroup(selectedGroup.id, "Group policy review") },
    )
    return
  }

  val filteredGroups = publicGroups.filter {
    groupSearchQuery.isBlank() ||
      it.name.contains(groupSearchQuery, ignoreCase = true) ||
      it.description.contains(groupSearchQuery, ignoreCase = true)
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(JuiMidnight)
      .padding(16.dp)
      .testTag("groups_screen"),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        JuiWordmarkHeader(subtitle = "Communities & Moderated Groups")
        Button(
          onClick = { showCreateForm = !showCreateForm },
          colors = ButtonDefaults.buttonColors(containerColor = JuiElectricBlue),
          modifier = Modifier.testTag("toggle_create_group_button"),
        ) {
          Icon(Icons.Default.Add, contentDescription = null)
          Spacer(modifier = Modifier.width(6.dp))
          Text("New Group")
        }
      }
    }

    if (showCreateForm) {
      item {
        Card(
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = JuiDeepSurface),
          modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, JuiBrandGradient, RoundedCornerShape(20.dp)),
        ) {
          Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Text("Create Community Group", style = MaterialTheme.typography.titleLarge, color = Color.White)
            OutlinedTextField(
              value = newGroupName,
              onValueChange = { newGroupName = it },
              label = { Text("Group Name (min 3 chars)") },
              singleLine = true,
              modifier = Modifier
                .fillMaxWidth()
                .testTag("create_group_name_input"),
            )
            OutlinedTextField(
              value = newGroupDesc,
              onValueChange = { newGroupDesc = it },
              label = { Text("Group Description") },
              modifier = Modifier
                .fillMaxWidth()
                .testTag("create_group_desc_input"),
            )
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text("Require Post Approval", color = Color.White, style = MaterialTheme.typography.titleMedium)
                Text("Posts stay PENDING until approved by a group moderator", color = JuiTextSecondary, style = MaterialTheme.typography.bodyMedium)
              }
              Switch(
                checked = requirePostApproval,
                onCheckedChange = { requirePostApproval = it },
              )
            }
            Button(
              onClick = {
                if (newGroupName.trim().length >= 3 && newGroupDesc.isNotBlank()) {
                  onCreateGroup(newGroupName, newGroupDesc, requirePostApproval)
                  newGroupName = ""
                  newGroupDesc = ""
                  showCreateForm = false
                }
              },
              modifier = Modifier
                .fillMaxWidth()
                .testTag("submit_create_group_button"),
            ) {
              Text("Create Group as CREATOR")
            }
          }
        }
      }
    }

    item {
      OutlinedTextField(
        value = groupSearchQuery,
        onValueChange = { groupSearchQuery = it },
        label = { Text("Search groups & communities") },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
      )
    }

    if (filteredGroups.isEmpty()) {
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = JuiCardSurface),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Text(
            text = "No groups found. Tap 'New Group' above to create a JUI Social Madia community!",
            color = JuiTextSecondary,
            modifier = Modifier.padding(18.dp),
          )
        }
      }
    } else {
      items(filteredGroups, key = { it.id }) { grp ->
        val membership = myMemberships.find { it.groupId == grp.id }
        Card(
          colors = CardDefaults.cardColors(containerColor = JuiCardSurface),
          modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelectGroup(grp) }
            .testTag("group_item_card_${grp.id}"),
        ) {
          Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Group, contentDescription = null, tint = JuiCyanAccent)
                Spacer(modifier = Modifier.width(8.dp))
                Text(grp.name, style = MaterialTheme.typography.titleLarge, color = Color.White)
              }
              Surface(
                color = JuiElectricBlue.copy(alpha = 0.22f),
                shape = RoundedCornerShape(50),
              ) {
                Text(
                  text = membership?.let { "${it.role} (${it.status})" } ?: "OPEN",
                  style = MaterialTheme.typography.labelMedium,
                  color = JuiCyanAccent,
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                )
              }
            }
            Text(grp.description, style = MaterialTheme.typography.bodyMedium, color = JuiTextSecondary)
            Text(
              text = "Post Moderation: ${if (grp.requirePostApproval) "Approval Required (PENDING first)" else "Direct Posting"}",
              style = MaterialTheme.typography.labelMedium,
              color = JuiWarningAmber,
            )
          }
        }
      }
    }
  }
}

@Composable
private fun GroupDetailScreen(
  group: CommunityGroup,
  currentUserId: String,
  myMembership: GroupMember?,
  approvedMembers: List<GroupMember>,
  approvedPosts: List<GroupPost>,
  pendingRequestsForGroup: List<GroupMember>,
  pendingPostsForGroup: List<GroupPost>,
  onBack: () -> Unit,
  onRequestJoin: () -> Unit,
  onLeaveGroup: () -> Unit,
  onApproveMember: (GroupMember, String) -> Unit,
  onCreatePost: (contentType: String, text: String, mediaUrl: String) -> Unit,
  onModeratePost: (String, Boolean) -> Unit,
  onReportGroup: () -> Unit,
) {
  var postText by remember { mutableStateOf("") }
  var selectedContentType by remember { mutableStateOf("TEXT") }
  var mediaUrl by remember { mutableStateOf("") }

  val isModeratorOrAdmin = group.creatorUid == currentUserId ||
    group.moderatorUids.contains(currentUserId) ||
    myMembership?.role in listOf("CREATOR", "GROUP_ADMIN", "MODERATOR")

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(JuiMidnight)
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        TextButton(onClick = onBack) {
          Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          Spacer(modifier = Modifier.width(6.dp))
          Text("All Groups")
        }
        IconButton(onClick = onReportGroup) {
          Icon(Icons.Default.Flag, contentDescription = "Report Group", tint = JuiWarningAmber)
        }
      }
    }

    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = JuiDeepSurface),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(
          modifier = Modifier.padding(18.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Text(group.name, style = MaterialTheme.typography.headlineMedium, color = Color.White)
          Text(group.description, style = MaterialTheme.typography.bodyMedium, color = JuiTextSecondary)
          Text(
            text = "Creator: @${group.creatorName} • Your Role: ${myMembership?.role ?: "Not a Member"} (${myMembership?.status ?: "NONE"})",
            style = MaterialTheme.typography.labelLarge,
            color = JuiCyanAccent,
          )
          Text(
            text = "Security Note: Group admins manage only their own group and can never modify global admin roles or the Permanent Super Owner.",
            style = MaterialTheme.typography.labelMedium,
            color = JuiTextSecondary,
          )

          Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (myMembership == null) {
              Button(
                onClick = onRequestJoin,
                modifier = Modifier.testTag("request_group_join_button"),
              ) {
                Text("Request Membership")
              }
            } else if (myMembership.role != "CREATOR") {
              OutlinedButton(onClick = onLeaveGroup) {
                Text("Leave Group")
              }
            }
          }
        }
      }
    }

    // Group Moderator Queue for Membership Requests & Pending Posts
    if (isModeratorOrAdmin && (pendingRequestsForGroup.isNotEmpty() || pendingPostsForGroup.isNotEmpty())) {
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = JuiCardSurface),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Text(
              text = "Group Moderation Queue (${pendingRequestsForGroup.size} members, ${pendingPostsForGroup.size} posts)",
              style = MaterialTheme.typography.titleMedium,
              color = JuiWarningAmber,
            )
            pendingRequestsForGroup.forEach { req ->
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Text("Request: @${req.username}", color = Color.White)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                  Button(onClick = { onApproveMember(req, "MEMBER") }) {
                    Text("Approve Member")
                  }
                  OutlinedButton(onClick = { onApproveMember(req, "MODERATOR") }) {
                    Text("Make Mod")
                  }
                }
              }
            }
            pendingPostsForGroup.forEach { p ->
              Card(colors = CardDefaults.cardColors(containerColor = JuiDeepSurface)) {
                Column(modifier = Modifier.padding(12.dp)) {
                  Text("PENDING ${p.contentType} by @${p.authorName}", color = JuiCyanAccent, style = MaterialTheme.typography.labelLarge)
                  Text(p.text, color = Color.White)
                  Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { onModeratePost(p.id, true) }) {
                      Icon(Icons.Default.Check, contentDescription = null)
                      Text("Approve")
                    }
                    OutlinedButton(onClick = { onModeratePost(p.id, false) }) {
                      Icon(Icons.Default.Close, contentDescription = null)
                      Text("Reject")
                    }
                  }
                }
              }
            }
          }
        }
      }
    }

    // Create Group Post Box (if approved member)
    if (myMembership?.status == "APPROVED") {
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = JuiCardSurface),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Text("Create Group Post", style = MaterialTheme.typography.titleMedium, color = Color.White)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              listOf("TEXT", "IMAGE", "VIDEO").forEach { type ->
                FilterChip(
                  selected = selectedContentType == type,
                  onClick = { selectedContentType = type },
                  label = { Text(type) },
                )
              }
            }
            OutlinedTextField(
              value = postText,
              onValueChange = { postText = it },
              label = { Text("Share an update with ${group.name}...") },
              modifier = Modifier
                .fillMaxWidth()
                .testTag("group_post_text_input"),
            )
            if (selectedContentType != "TEXT") {
              OutlinedTextField(
                value = mediaUrl,
                onValueChange = { mediaUrl = it },
                label = { Text("$selectedContentType Media Reference / Caption URI") },
                modifier = Modifier.fillMaxWidth(),
              )
            }
            Button(
              onClick = {
                if (postText.isNotBlank()) {
                  onCreatePost(selectedContentType, postText, mediaUrl)
                  postText = ""
                  mediaUrl = ""
                }
              },
              modifier = Modifier
                .fillMaxWidth()
                .testTag("publish_group_post_button"),
            ) {
              Text(if (group.requirePostApproval) "Submit Group Post (PENDING Approval)" else "Publish Group Post")
            }
          }
        }
      }
    }

    item {
      Text(
        text = "Approved Group Posts (${approvedPosts.size}) • Members (${approvedMembers.size})",
        style = MaterialTheme.typography.titleMedium,
        color = Color.White,
      )
    }

    items(approvedPosts, key = { it.id }) { post ->
      Card(
        colors = CardDefaults.cardColors(containerColor = JuiCardSurface),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text("@${post.authorName}", color = JuiCyanAccent, fontWeight = FontWeight.Bold)
            Text("${post.contentType} • ${post.status}", color = JuiSuccessGreen, style = MaterialTheme.typography.labelMedium)
          }
          Text(post.text, color = Color.White, style = MaterialTheme.typography.bodyLarge)
          if (post.mediaUrl.isNotBlank()) {
            Text("Attached Media: ${post.mediaUrl}", color = JuiTextSecondary, style = MaterialTheme.typography.labelMedium)
          }
        }
      }
    }
  }
}

@Composable
fun NotificationsAndPrivateInboxScreen(
  currentUserId: String,
  currentUserDisplayName: String,
  notifications: List<AppNotification>,
  conversations: List<Conversation>,
  messages: List<PrivateMessage>,
  allProfiles: List<UserProfile>,
  onMarkNotificationRead: (String) -> Unit,
  onSendMessage: (recipientUid: String, recipientName: String, text: String, retentionDays: Long) -> Unit,
  onMarkMessageRead: (String) -> Unit,
  onBlockUser: (targetUid: String, targetUsername: String, reason: String) -> Unit,
  onReportUser: (targetUid: String, reason: String) -> Unit,
) {
  var selectedTab by remember { mutableIntStateOf(0) }
  var activePartnerProfile by remember { mutableStateOf<UserProfile?>(null) }
  var messageInput by remember { mutableStateOf("") }
  var retentionDays by remember { mutableLongStateOf(90L) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(JuiMidnight)
      .padding(16.dp)
      .testTag("inbox_and_notifications_screen"),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      JuiWordmarkHeader(subtitle = "Notifications & Protected 1-to-1 Chat")
      Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        FilterChip(
          selected = selectedTab == 0,
          onClick = { selectedTab = 0 },
          label = { Text("Alerts (${notifications.count { !it.isRead }})") },
          modifier = Modifier.testTag("inbox_tab_alerts"),
        )
        FilterChip(
          selected = selectedTab == 1,
          onClick = { selectedTab = 1 },
          label = { Text("Direct Chat") },
          modifier = Modifier.testTag("inbox_tab_chat"),
        )
      }
    }

    if (selectedTab == 0) {
      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        if (notifications.isEmpty()) {
          item {
            Card(colors = CardDefaults.cardColors(containerColor = JuiCardSurface), modifier = Modifier.fillMaxWidth()) {
              Text(
                text = "No notifications yet. Likes, comments, follows, video moderation decisions, and group updates appear here.",
                color = JuiTextSecondary,
                modifier = Modifier.padding(18.dp),
              )
            }
          }
        } else {
          items(notifications, key = { it.id }) { notif ->
            Card(
              colors = CardDefaults.cardColors(
                containerColor = if (notif.isRead) JuiCardSurface else JuiDeepSurface
              ),
              modifier = Modifier
                .fillMaxWidth()
                .clickable { onMarkNotificationRead(notif.id) },
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.Notifications, contentDescription = null, tint = JuiCyanAccent)
                  Spacer(modifier = Modifier.width(10.dp))
                  Column {
                    Text(notif.title, style = MaterialTheme.typography.titleMedium, color = Color.White)
                    Text(notif.body, style = MaterialTheme.typography.bodyMedium, color = JuiTextSecondary)
                    Text("Type: ${notif.type} • From: ${notif.actorName}", style = MaterialTheme.typography.labelMedium, color = JuiCyanAccent)
                  }
                }
                if (!notif.isRead) {
                  TextButton(onClick = { onMarkNotificationRead(notif.id) }) {
                    Text("Mark Read")
                  }
                }
              }
            }
          }
        }
      }
    } else {
      // Private 1-to-1 Messaging
      Card(
        colors = CardDefaults.cardColors(containerColor = JuiDeepSurface),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Text(
            text = "Zero-Trust Private Messaging Protection",
            style = MaterialTheme.typography.labelLarge,
            color = JuiCyanAccent,
          )
          Text(
            text = "Messages are strictly isolated to the two conversation participants on the backend. Ordinary admins cannot read private conversations.",
            style = MaterialTheme.typography.labelMedium,
            color = JuiTextSecondary,
          )
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Text("Retention:", style = MaterialTheme.typography.labelMedium, color = Color.White)
            listOf(30L, 90L, 365L).forEach { days ->
              FilterChip(
                selected = retentionDays == days,
                onClick = { retentionDays = days },
                label = { Text("${days}d") },
              )
            }
          }
        }
      }

      if (activePartnerProfile == null) {
        val otherUsers = allProfiles.filter { it.userId != currentUserId }
        Text("Select a Creator to Message (${otherUsers.size})", style = MaterialTheme.typography.titleMedium, color = Color.White)
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          items(otherUsers, key = { it.userId }) { user ->
            val lastConv = conversations.find { it.participantUids.contains(user.userId) }
            Card(
              colors = CardDefaults.cardColors(containerColor = JuiCardSurface),
              modifier = Modifier
                .fillMaxWidth()
                .clickable { activePartnerProfile = user }
                .testTag("chat_partner_card_${user.username}"),
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text("${user.displayName} (@${user.username})", style = MaterialTheme.typography.titleMedium, color = Color.White)
                  Text(
                    text = lastConv?.lastMessageText?.ifBlank { "Tap to start private 1-to-1 conversation" }
                      ?: "Tap to start private 1-to-1 conversation",
                    style = MaterialTheme.typography.bodyMedium,
                    color = JuiTextSecondary,
                  )
                }
                Text("Chat", color = JuiCyanAccent, fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      } else {
        val partner = activePartnerProfile!!
        val threadMessages = messages.filter {
          (it.senderUid == currentUserId && it.recipientUid == partner.userId) ||
            (it.senderUid == partner.userId && it.recipientUid == currentUserId)
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          TextButton(onClick = { activePartnerProfile = null }) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            Spacer(modifier = Modifier.width(4.dp))
            Text("Conversations")
          }
          Text("@${partner.username}", style = MaterialTheme.typography.titleMedium, color = Color.White)
          Row {
            IconButton(
              onClick = {
                onBlockUser(partner.userId, partner.username, "Blocked from private chat")
                activePartnerProfile = null
              },
              modifier = Modifier.testTag("block_chat_partner_button"),
            ) {
              Icon(Icons.Default.Block, contentDescription = "Block User", tint = JuiDangerRed)
            }
            IconButton(
              onClick = { onReportUser(partner.userId, "Reported from private chat") },
            ) {
              Icon(Icons.Default.Flag, contentDescription = "Report User", tint = JuiWarningAmber)
            }
          }
        }

        LazyColumn(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          items(threadMessages, key = { it.id }) { msg ->
            val isMine = msg.senderUid == currentUserId
            if (!isMine && !msg.isRead) {
              onMarkMessageRead(msg.id)
            }
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = if (isMine) Arrangement.End else Arrangement.Start,
            ) {
              Card(
                colors = CardDefaults.cardColors(
                  containerColor = if (isMine) JuiElectricBlue else JuiCardSurface
                ),
                shape = RoundedCornerShape(16.dp),
              ) {
                Column(modifier = Modifier.padding(12.dp)) {
                  Text(msg.text, color = Color.White, style = MaterialTheme.typography.bodyMedium)
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                      text = if (msg.isRead) "Read" else "Delivered",
                      style = MaterialTheme.typography.labelMedium,
                      color = Color.White.copy(alpha = 0.75f),
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                      imageVector = Icons.Default.DoneAll,
                      contentDescription = null,
                      tint = if (msg.isRead) JuiCyanAccent else Color.White.copy(alpha = 0.6f),
                      modifier = Modifier.size(14.dp),
                    )
                  }
                }
              }
            }
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          OutlinedTextField(
            value = messageInput,
            onValueChange = { messageInput = it },
            placeholder = { Text("Write private message to @${partner.username}...") },
            singleLine = true,
            modifier = Modifier
              .weight(1f)
              .testTag("private_message_input"),
          )
          IconButton(
            onClick = {
              if (messageInput.isNotBlank()) {
                onSendMessage(partner.userId, partner.displayName, messageInput, retentionDays)
                messageInput = ""
              }
            },
            modifier = Modifier.testTag("send_private_message_button"),
          ) {
            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send Message", tint = JuiCyanAccent)
          }
        }
      }
    }
  }
}
