package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.HistoryEdu
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AdminRole
import com.example.data.model.AuditLog
import com.example.data.model.BlockRecord
import com.example.data.model.CommunityGroup
import com.example.data.model.FollowRecord
import com.example.data.model.ModerationReport
import com.example.data.model.ShortVideo
import com.example.data.model.SuperOwnerConfig
import com.example.data.model.UserProfile
import com.example.ui.components.JuiBrandGradient
import com.example.ui.components.JuiLogoBadge
import com.example.ui.components.JuiWordmarkHeader
import com.example.ui.components.ReauthConfirmationDialog
import com.example.ui.theme.JuiCardSurface
import com.example.ui.theme.JuiCyanAccent
import com.example.ui.theme.JuiDangerRed
import com.example.ui.theme.JuiDeepSurface
import com.example.ui.theme.JuiElectricBlue
import com.example.ui.theme.JuiMidnight
import com.example.ui.theme.JuiSuccessGreen
import com.example.ui.theme.JuiTextSecondary
import com.example.ui.theme.JuiWarningAmber

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileAndSettingsScreen(
  profile: UserProfile?,
  isSuperOwner: Boolean,
  adminRole: AdminRole?,
  myUploadedVideos: List<ShortVideo>,
  approvedFeedVideos: List<ShortVideo>,
  savedVideoIds: Set<String>,
  followers: List<FollowRecord>,
  following: List<FollowRecord>,
  blockedUsers: List<BlockRecord>,
  myReports: List<ModerationReport>,
  onUpdateProfile: (displayName: String, bio: String, isPrivate: Boolean) -> Unit,
  onUnblockUser: (String) -> Unit,
  onSubmitReportOrSupport: (targetId: String, targetType: String, reason: String, details: String) -> Unit,
  onDeleteAccount: () -> Unit,
  onSignOut: () -> Unit,
) {
  var selectedSection by remember { mutableIntStateOf(0) }
  var showEditDialog by remember { mutableStateOf(false) }
  var showDeleteConfirm by remember { mutableStateOf(false) }
  var pushNotificationsEnabled by remember { mutableStateOf(true) }
  var supportSubject by remember { mutableStateOf("") }
  var supportDetails by remember { mutableStateOf("") }

  val savedVideos = approvedFeedVideos.filter { savedVideoIds.contains(it.id) }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(JuiMidnight)
      .padding(16.dp)
      .testTag("profile_and_settings_screen"),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        JuiWordmarkHeader(subtitle = "Creator Profile, Safety & Settings")
        OutlinedButton(
          onClick = onSignOut,
          modifier = Modifier.testTag("profile_sign_out_button"),
        ) {
          Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Logout")
        }
      }
    }

    // Profile Identity Card
    item {
      Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = JuiDeepSurface),
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, JuiBrandGradient, RoundedCornerShape(22.dp)),
      ) {
        Column(
          modifier = Modifier.padding(20.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
          ) {
            JuiLogoBadge(size = 58.dp)
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = profile?.displayName ?: "JUI Creator",
                style = MaterialTheme.typography.headlineMedium,
                color = Color.White,
              )
              Text(
                text = "@${profile?.username ?: "user"} • ${if (profile?.isPrivate == true) "Private Account" else "Public Account"}",
                style = MaterialTheme.typography.bodyMedium,
                color = JuiCyanAccent,
              )
              val roleLabel = when {
                isSuperOwner -> "PERMANENT SUPER OWNER"
                adminRole != null -> "GLOBAL ADMIN"
                else -> "VERIFIED MEMBER"
              }
              Text(
                text = "Role: $roleLabel • Status: ${profile?.accountStatus ?: "ACTIVE"}",
                style = MaterialTheme.typography.labelMedium,
                color = JuiSuccessGreen,
              )
            }
            OutlinedButton(
              onClick = { showEditDialog = true },
              modifier = Modifier.testTag("edit_profile_button"),
            ) {
              Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Edit")
            }
          }

          Text(
            text = profile?.bio?.ifBlank { "No bio added yet." } ?: "",
            style = MaterialTheme.typography.bodyMedium,
            color = JuiTextSecondary,
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
          ) {
            ProfileMetricPill("Uploads", "${myUploadedVideos.size}")
            ProfileMetricPill("Saved", "${savedVideos.size}")
            ProfileMetricPill("Followers", "${followers.size}")
            ProfileMetricPill("Following", "${following.size}")
          }
        }
      }
    }

    // Section Selector Chips
    item {
      FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(
          0 to "Uploads (${myUploadedVideos.size})",
          1 to "Saved (${savedVideos.size})",
          2 to "Followers & Following",
          3 to "Reports & Support",
          4 to "Privacy, Policy & Settings",
        ).forEach { (idx, label) ->
          FilterChip(
            selected = selectedSection == idx,
            onClick = { selectedSection = idx },
            label = { Text(label) },
          )
        }
      }
    }

    when (selectedSection) {
      0 -> {
        items(myUploadedVideos, key = { it.id }) { vid ->
          Card(colors = CardDefaults.cardColors(containerColor = JuiCardSurface), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp)) {
              Text(vid.caption, style = MaterialTheme.typography.titleMedium, color = Color.White)
              Text("Status: ${vid.status} • Views: ${vid.viewsCount} • Likes: ${vid.likesCount}", color = JuiCyanAccent, style = MaterialTheme.typography.labelMedium)
            }
          }
        }
      }
      1 -> {
        if (savedVideos.isEmpty()) {
          item {
            Text("No saved videos yet. Tap the bookmark icon on any approved video in the feed.", color = JuiTextSecondary)
          }
        } else {
          items(savedVideos, key = { it.id }) { vid ->
            Card(colors = CardDefaults.cardColors(containerColor = JuiCardSurface), modifier = Modifier.fillMaxWidth()) {
              Column(modifier = Modifier.padding(14.dp)) {
                Text("@${vid.authorUsername}: ${vid.caption}", style = MaterialTheme.typography.titleMedium, color = Color.White)
                Text(vid.hashtags, color = JuiCyanAccent, style = MaterialTheme.typography.labelMedium)
              }
            }
          }
        }
      }
      2 -> {
        item {
          Text("Followers (${followers.size})", style = MaterialTheme.typography.titleMedium, color = Color.White)
        }
        items(followers, key = { it.id }) { f ->
          Card(colors = CardDefaults.cardColors(containerColor = JuiCardSurface), modifier = Modifier.fillMaxWidth()) {
            Text("@${f.followerUsername}", color = Color.White, modifier = Modifier.padding(12.dp))
          }
        }
        item {
          Text("Following (${following.size})", style = MaterialTheme.typography.titleMedium, color = Color.White)
        }
        items(following, key = { it.id }) { f ->
          Card(colors = CardDefaults.cardColors(containerColor = JuiCardSurface), modifier = Modifier.fillMaxWidth()) {
            Text("@${f.followedUsername}", color = JuiCyanAccent, modifier = Modifier.padding(12.dp))
          }
        }
        item {
          Text("Blocked Accounts (${blockedUsers.size})", style = MaterialTheme.typography.titleMedium, color = Color.White)
        }
        items(blockedUsers, key = { it.id }) { b ->
          Card(colors = CardDefaults.cardColors(containerColor = JuiCardSurface), modifier = Modifier.fillMaxWidth()) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text("@${b.blockedUsername} (${b.reason})", color = Color.White)
              OutlinedButton(onClick = { onUnblockUser(b.blockedUid) }) {
                Text("Unblock")
              }
            }
          }
        }
      }
      3 -> {
        item {
          Card(colors = CardDefaults.cardColors(containerColor = JuiCardSurface), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.SupportAgent, contentDescription = null, tint = JuiCyanAccent)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Submit Safety Report, Moderation Appeal, or Support Ticket", style = MaterialTheme.typography.titleMedium, color = Color.White)
              }
              OutlinedTextField(
                value = supportSubject,
                onValueChange = { supportSubject = it },
                label = { Text("Subject / Reason (min 3 chars)") },
                modifier = Modifier.fillMaxWidth(),
              )
              OutlinedTextField(
                value = supportDetails,
                onValueChange = { supportDetails = it },
                label = { Text("Details") },
                modifier = Modifier.fillMaxWidth(),
              )
              Button(
                onClick = {
                  if (supportSubject.trim().length >= 3) {
                    onSubmitReportOrSupport("platform_support", "APPEAL", supportSubject, supportDetails)
                    supportSubject = ""
                    supportDetails = ""
                  }
                },
                modifier = Modifier.fillMaxWidth(),
              ) {
                Text("Submit to JUI Moderation & Support Team")
              }
            }
          }
        }
        item {
          Text("My Submitted Reports & Appeals (${myReports.size})", style = MaterialTheme.typography.titleMedium, color = Color.White)
        }
        items(myReports, key = { it.id }) { rep ->
          Card(colors = CardDefaults.cardColors(containerColor = JuiCardSurface), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(14.dp)) {
              Text("${rep.targetType} • Status: ${rep.status}", color = JuiCyanAccent, fontWeight = FontWeight.Bold)
              Text("Reason: ${rep.reason}", color = Color.White)
              if (rep.resolutionNote.isNotBlank()) {
                Text("Resolution: ${rep.resolutionNote}", color = JuiSuccessGreen)
              }
            }
          }
        }
      }
      4 -> {
        item {
          Card(colors = CardDefaults.cardColors(containerColor = JuiCardSurface), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Policy, contentDescription = null, tint = JuiCyanAccent)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Privacy Policy, Community Guidelines & Terms", style = MaterialTheme.typography.titleMedium, color = Color.White)
              }
              Text(
                text = "• Privacy & PII Isolation: Public profiles store zero email or phone PII. Private 1-to-1 messages are isolated to conversation participants.\n" +
                  "• Video Moderation: All uploaded videos begin in PENDING status and require moderator approval before public visibility.\n" +
                  "• Age Safety: Accounts require 13+ age verification.\n" +
                  "• Audio Licensing: Uploads use CC-BY / CC0 or original creator audio attribution.\n" +
                  "• Official Support Contact: support@juisocialmadia.example",
                style = MaterialTheme.typography.bodyMedium,
                color = JuiTextSecondary,
              )
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Text("Moderation & Activity Notifications", color = Color.White)
                Switch(checked = pushNotificationsEnabled, onCheckedChange = { pushNotificationsEnabled = it })
              }
              Button(
                onClick = { showDeleteConfirm = true },
                colors = ButtonDefaults.buttonColors(containerColor = JuiDangerRed),
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("delete_account_button"),
              ) {
                Icon(Icons.Default.DeleteForever, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Delete My Account")
              }
            }
          }
        }
      }
    }
  }

  if (showEditDialog && profile != null) {
    var editName by remember { mutableStateOf(profile.displayName) }
    var editBio by remember { mutableStateOf(profile.bio) }
    var editPrivate by remember { mutableStateOf(profile.isPrivate) }

    AlertDialog(
      onDismissRequest = { showEditDialog = false },
      containerColor = JuiCardSurface,
      title = { Text("Edit JUI Social Madia Profile", color = Color.White) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          OutlinedTextField(
            value = editName,
            onValueChange = { editName = it },
            label = { Text("Display Name") },
            singleLine = true,
          )
          OutlinedTextField(
            value = editBio,
            onValueChange = { editBio = it },
            label = { Text("Bio") },
          )
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text("Private Account", color = Color.White)
            Switch(checked = editPrivate, onCheckedChange = { editPrivate = it })
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            onUpdateProfile(editName, editBio, editPrivate)
            showEditDialog = false
          }
        ) {
          Text("Save Changes")
        }
      },
      dismissButton = {
        TextButton(onClick = { showEditDialog = false }) {
          Text("Cancel")
        }
      },
    )
  }

  if (showDeleteConfirm) {
    AlertDialog(
      onDismissRequest = { showDeleteConfirm = false },
      containerColor = JuiCardSurface,
      title = { Text("Delete Account?", color = Color.White) },
      text = {
        Text(
          text = "Are you sure you want to permanently delete your profile and release your @username? Note: The Permanent Super Owner account is protected by backend rules and cannot be deleted.",
          color = JuiTextSecondary,
        )
      },
      confirmButton = {
        Button(
          onClick = {
            showDeleteConfirm = false
            onDeleteAccount()
          },
          colors = ButtonDefaults.buttonColors(containerColor = JuiDangerRed),
        ) {
          Text("Confirm Delete")
        }
      },
      dismissButton = {
        TextButton(onClick = { showDeleteConfirm = false }) {
          Text("Cancel")
        }
      },
    )
  }
}

@Composable
private fun ProfileMetricPill(label: String, value: String) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Text(value, style = MaterialTheme.typography.titleLarge, color = Color.White, fontWeight = FontWeight.Bold)
    Text(label, style = MaterialTheme.typography.labelMedium, color = JuiTextSecondary)
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdminAndSuperOwnerDashboardScreen(
  currentUserId: String,
  currentUserDisplayName: String,
  superOwnerConfig: SuperOwnerConfig?,
  isSuperOwner: Boolean,
  adminRole: AdminRole?,
  pendingVideos: List<ShortVideo>,
  approvedVideosCount: Int,
  activeUsers: List<UserProfile>,
  publicGroups: List<CommunityGroup>,
  openReports: List<ModerationReport>,
  allAdminRoles: List<AdminRole>,
  auditLogs: List<AuditLog>,
  onClaimSuperOwner: () -> Unit,
  onUpdateGlobalSettings: (status: String, allowReg: Boolean, reqMod: Boolean) -> Unit,
  onModerateVideo: (video: ShortVideo, approve: Boolean, reason: String) -> Unit,
  onResolveReport: (reportId: String, status: String, note: String) -> Unit,
  onAssignAdminRole: (
    targetUid: String,
    targetName: String,
    videos: Boolean,
    comments: Boolean,
    reports: Boolean,
    groups: Boolean,
    appeals: Boolean,
  ) -> Unit,
  onRevokeAdminRole: (String) -> Unit,
  onToggleSuspendUser: (targetUid: String, suspend: Boolean) -> Unit,
) {
  var activeTab by remember { mutableIntStateOf(0) }
  var pendingSearchQuery by remember { mutableStateOf("") }
  var rejectionReasonInput by remember { mutableStateOf("Violates community guidelines") }
  var pendingReauthAction by remember { mutableStateOf<Pair<String, () -> Unit>?>(null) }

  // Admin appointment state
  var targetAdminUid by remember { mutableStateOf("") }
  var targetAdminName by remember { mutableStateOf("") }
  var permVideos by remember { mutableStateOf(true) }
  var permComments by remember { mutableStateOf(true) }
  var permReports by remember { mutableStateOf(false) }
  var permGroups by remember { mutableStateOf(false) }
  var permAppeals by remember { mutableStateOf(false) }

  val filteredPendingVideos = pendingVideos.filter {
    pendingSearchQuery.isBlank() ||
      it.caption.contains(pendingSearchQuery, ignoreCase = true) ||
      it.authorUsername.contains(pendingSearchQuery, ignoreCase = true) ||
      it.hashtags.contains(pendingSearchQuery, ignoreCase = true)
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(JuiMidnight)
      .padding(16.dp)
      .testTag("admin_and_owner_screen"),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    item {
      JuiWordmarkHeader(subtitle = "Admin Moderation & Permanent Super Owner Console")
    }

    // Real Platform Statistics Banner (zero fabricated numbers — live counts from Firestore)
    item {
      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = JuiDeepSurface),
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, JuiBrandGradient, RoundedCornerShape(20.dp)),
      ) {
        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Shield, contentDescription = null, tint = JuiCyanAccent)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = if (isSuperOwner) "Permanent Super Owner Authority Active"
              else if (adminRole != null) "Authorized Global Admin Session"
              else "Standard Member View (Backend Enforced)",
              style = MaterialTheme.typography.titleMedium,
              color = Color.White,
            )
          }
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            ProfileMetricPill("Pending Videos", "${pendingVideos.size}")
            ProfileMetricPill("Live Videos", "$approvedVideosCount")
            ProfileMetricPill("Users", "${activeUsers.size}")
            ProfileMetricPill("Groups", "${publicGroups.size}")
            ProfileMetricPill("Open Reports", "${openReports.size}")
          }
        }
      }
    }

    // One-time Server-Side Super Owner Setup Card if not yet claimed
    if (superOwnerConfig == null) {
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = JuiCardSurface),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.GppGood, contentDescription = null, tint = JuiSuccessGreen)
              Spacer(modifier = Modifier.width(8.dp))
              Text("One-Time Permanent Super Owner Setup", style = MaterialTheme.typography.titleLarge, color = Color.White)
            }
            Text(
              text = "No Super Owner document (/platform_config/super_owner) exists yet. Establish the initial permanent Super Owner now. Once created, ownerUid is locked as immutable on the server and can never be demoted, replaced, or deleted.",
              style = MaterialTheme.typography.bodyMedium,
              color = JuiTextSecondary,
            )
            Button(
              onClick = {
                pendingReauthAction = "Establish Permanent Super Owner" to onClaimSuperOwner
              },
              colors = ButtonDefaults.buttonColors(containerColor = JuiElectricBlue),
              modifier = Modifier
                .fillMaxWidth()
                .testTag("claim_super_owner_button"),
            ) {
              Icon(Icons.Default.Security, contentDescription = null)
              Spacer(modifier = Modifier.width(8.dp))
              Text("Initialize Permanent Super Owner (Re-Auth Required)")
            }
          }
        }
      }
    }

    item {
      FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(
          0 to "Pending Videos (${pendingVideos.size})",
          1 to "Reports & Appeals (${openReports.size})",
          2 to "Super Owner & Admins",
          3 to "Audit Logs (${auditLogs.size})",
        ).forEach { (idx, title) ->
          FilterChip(
            selected = activeTab == idx,
            onClick = { activeTab = idx },
            label = { Text(title) },
            modifier = Modifier.testTag("admin_tab_$idx"),
          )
        }
      }
    }

    when (activeTab) {
      0 -> {
        item {
          OutlinedTextField(
            value = pendingSearchQuery,
            onValueChange = { pendingSearchQuery = it },
            label = { Text("Search & filter PENDING videos by caption, @user, or #hashtag") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
          )
        }
        item {
          OutlinedTextField(
            value = rejectionReasonInput,
            onValueChange = { rejectionReasonInput = it },
            label = { Text("Rejection Reason (sent to uploader if rejected)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
          )
        }
        if (filteredPendingVideos.isEmpty()) {
          item {
            Card(colors = CardDefaults.cardColors(containerColor = JuiCardSurface), modifier = Modifier.fillMaxWidth()) {
              Text(
                text = "No PENDING videos in the moderation queue (or your account does not hold canApproveVideos permission).",
                color = JuiTextSecondary,
                modifier = Modifier.padding(16.dp),
              )
            }
          }
        } else {
          items(filteredPendingVideos, key = { it.id }) { vid ->
            Card(colors = CardDefaults.cardColors(containerColor = JuiCardSurface), modifier = Modifier.fillMaxWidth()) {
              Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("@${vid.authorUsername} • Status: ${vid.status}", color = JuiWarningAmber, fontWeight = FontWeight.Bold)
                Text(vid.caption, color = Color.White, style = MaterialTheme.typography.titleMedium)
                Text("${vid.hashtags} • ${vid.fileMimeType} • ${vid.fileSizeBytes / 1024} KB", color = JuiTextSecondary, style = MaterialTheme.typography.bodyMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                  Button(
                    onClick = { onModerateVideo(vid, true, "") },
                    colors = ButtonDefaults.buttonColors(containerColor = JuiSuccessGreen),
                    modifier = Modifier.testTag("approve_video_button_${vid.id}"),
                  ) {
                    Icon(Icons.Default.Check, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Approve")
                  }
                  OutlinedButton(
                    onClick = { onModerateVideo(vid, false, rejectionReasonInput) },
                    modifier = Modifier.testTag("reject_video_button_${vid.id}"),
                  ) {
                    Icon(Icons.Default.Close, contentDescription = null, tint = JuiDangerRed)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Reject", color = JuiDangerRed)
                  }
                }
              }
            }
          }
        }
      }
      1 -> {
        if (openReports.isEmpty()) {
          item {
            Card(colors = CardDefaults.cardColors(containerColor = JuiCardSurface), modifier = Modifier.fillMaxWidth()) {
              Text(
                text = "No open reports or moderation appeals.",
                color = JuiTextSecondary,
                modifier = Modifier.padding(16.dp),
              )
            }
          }
        } else {
          items(openReports, key = { it.id }) { rep ->
            Card(colors = CardDefaults.cardColors(containerColor = JuiCardSurface), modifier = Modifier.fillMaxWidth()) {
              Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("${rep.targetType} Report by @${rep.reporterName}", color = JuiCyanAccent, fontWeight = FontWeight.Bold)
                Text("Reason: ${rep.reason}", color = Color.White)
                Text("Details: ${rep.details}", color = JuiTextSecondary)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  Button(onClick = { onResolveReport(rep.id, "RESOLVED", "Action taken by moderator") }) {
                    Text("Resolve")
                  }
                  OutlinedButton(onClick = { onResolveReport(rep.id, "DISMISSED", "Reviewed — no violation found") }) {
                    Text("Dismiss")
                  }
                }
              }
            }
          }
        }
      }
      2 -> {
        // Permanent Super Owner Governance & Global Admin Permission Boundaries
        item {
          Card(colors = CardDefaults.cardColors(containerColor = JuiCardSurface), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = JuiCyanAccent)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Permanent Super Owner & Admin Permission Boundaries", style = MaterialTheme.typography.titleMedium, color = Color.White)
              }
              Text(
                text = "Super Owner UID: ${superOwnerConfig?.ownerUid ?: "Not yet initialized"}\n" +
                  "Owner Name: ${superOwnerConfig?.ownerName ?: "N/A"}\n" +
                  "Platform Status: ${superOwnerConfig?.platformStatus ?: "ONLINE"}\n" +
                  "Backend Guarantee: Ordinary admins can never demote, delete, suspend, block, or replace the Super Owner, nor escalate their own privileges.",
                style = MaterialTheme.typography.bodyMedium,
                color = JuiTextSecondary,
              )

              if (isSuperOwner && superOwnerConfig != null) {
                Button(
                  onClick = {
                    val nextStatus = if (superOwnerConfig.platformStatus == "ONLINE") "MAINTENANCE" else "ONLINE"
                    pendingReauthAction = "Toggle Platform Status to $nextStatus" to {
                      onUpdateGlobalSettings(
                        nextStatus,
                        superOwnerConfig.allowPublicRegistration,
                        superOwnerConfig.requireModerationForAllVideos,
                      )
                    }
                  },
                ) {
                  Text("Toggle Platform Maintenance Mode (Re-Auth)")
                }
              }
            }
          }
        }

        // Appoint / Update Global Admin Permissions
        item {
          Card(colors = CardDefaults.cardColors(containerColor = JuiCardSurface), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Text("Appoint or Update Global Admin Role (Super Owner Only)", style = MaterialTheme.typography.titleMedium, color = Color.White)
              OutlinedTextField(
                value = targetAdminUid,
                onValueChange = { targetAdminUid = it },
                label = { Text("Target User UID") },
                singleLine = true,
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("admin_target_uid_input"),
              )
              OutlinedTextField(
                value = targetAdminName,
                onValueChange = { targetAdminName = it },
                label = { Text("Admin Display Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
              )

              PermissionCheckboxRow("Approve / Reject Pending Videos", permVideos) { permVideos = it }
              PermissionCheckboxRow("Moderate Comments", permComments) { permComments = it }
              PermissionCheckboxRow("Manage Safety Reports", permReports) { permReports = it }
              PermissionCheckboxRow("Manage Community Groups", permGroups) { permGroups = it }
              PermissionCheckboxRow("Manage Moderation Appeals", permAppeals) { permAppeals = it }

              Button(
                onClick = {
                  if (targetAdminUid.isNotBlank()) {
                    pendingReauthAction = "Assign Admin Permissions to $targetAdminUid" to {
                      onAssignAdminRole(
                        targetAdminUid.trim(),
                        targetAdminName.ifBlank { "Global Moderator" },
                        permVideos,
                        permComments,
                        permReports,
                        permGroups,
                        permAppeals,
                      )
                    }
                  }
                },
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("assign_admin_role_button"),
              ) {
                Icon(Icons.Default.Lock, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Save Admin Permissions (Re-Auth & Audit)")
              }
            }
          }
        }

        // Existing Global Admins List
        items(allAdminRoles, key = { it.adminUid }) { role ->
          Card(colors = CardDefaults.cardColors(containerColor = JuiCardSurface), modifier = Modifier.fillMaxWidth()) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text("${role.adminName} (${role.adminUid})", color = Color.White, fontWeight = FontWeight.Bold)
                Text(
                  text = "Videos=${role.canApproveVideos} • Comments=${role.canModerateComments} • Reports=${role.canManageReports} • Groups=${role.canManageGroups}",
                  color = JuiCyanAccent,
                  style = MaterialTheme.typography.labelMedium,
                )
              }
              OutlinedButton(
                onClick = {
                  pendingReauthAction = "Revoke Admin Role for ${role.adminName}" to {
                    onRevokeAdminRole(role.adminUid)
                  }
                }
              ) {
                Text("Revoke", color = JuiDangerRed)
              }
            }
          }
        }

        // User Account Management (Suspend / Restore)
        item {
          Text("User Account Management (${activeUsers.size})", style = MaterialTheme.typography.titleMedium, color = Color.White)
        }
        items(activeUsers, key = { it.userId }) { user ->
          val isTargetOwner = user.userId == superOwnerConfig?.ownerUid
          Card(colors = CardDefaults.cardColors(containerColor = JuiCardSurface), modifier = Modifier.fillMaxWidth()) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text("${user.displayName} (@${user.username})", color = Color.White)
                Text("UID: ${user.userId} • Status: ${user.accountStatus}", color = JuiTextSecondary, style = MaterialTheme.typography.labelMedium)
              }
              if (isTargetOwner) {
                Text("PROTECTED OWNER", color = JuiSuccessGreen, style = MaterialTheme.typography.labelMedium)
              } else {
                val isSuspended = user.accountStatus == "SUSPENDED"
                OutlinedButton(
                  onClick = {
                    pendingReauthAction = "${if (isSuspended) "Restore" else "Suspend"} @${user.username}" to {
                      onToggleSuspendUser(user.userId, !isSuspended)
                    }
                  }
                ) {
                  Text(if (isSuspended) "Restore" else "Suspend")
                }
              }
            }
          }
        }
      }
      3 -> {
        // Append-Only Administrative Audit Logs
        item {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.HistoryEdu, contentDescription = null, tint = JuiCyanAccent)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Append-Only Administrative Audit Log (${auditLogs.size})",
              style = MaterialTheme.typography.titleMedium,
              color = Color.White,
            )
          }
        }
        if (auditLogs.isEmpty()) {
          item {
            Card(colors = CardDefaults.cardColors(containerColor = JuiCardSurface), modifier = Modifier.fillMaxWidth()) {
              Text(
                text = "Audit logs are strictly restricted to the Permanent Super Owner on the backend.",
                color = JuiTextSecondary,
                modifier = Modifier.padding(16.dp),
              )
            }
          }
        } else {
          items(auditLogs, key = { it.id }) { log ->
            Card(colors = CardDefaults.cardColors(containerColor = JuiCardSurface), modifier = Modifier.fillMaxWidth()) {
              Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                  Text(log.action, color = JuiCyanAccent, fontWeight = FontWeight.Bold)
                  Text(log.result, color = JuiSuccessGreen, style = MaterialTheme.typography.labelMedium)
                }
                Text("Actor: ${log.actorName} (${log.actorUid}) • Target: ${log.targetType} (${log.targetId})", color = Color.White, style = MaterialTheme.typography.labelMedium)
                Text(log.details, color = JuiTextSecondary, style = MaterialTheme.typography.bodyMedium)
              }
            }
          }
        }
      }
    }
  }

  pendingReauthAction?.let { (title, action) ->
    ReauthConfirmationDialog(
      actionTitle = title,
      onConfirm = {
        pendingReauthAction = null
        action()
      },
      onDismiss = { pendingReauthAction = null },
    )
  }
}

@Composable
private fun PermissionCheckboxRow(
  label: String,
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit,
) {
  Row(
    verticalAlignment = Alignment.CenterVertically,
    modifier = Modifier.fillMaxWidth(),
  ) {
    Checkbox(checked = checked, onCheckedChange = onCheckedChange)
    Text(label, color = Color.White, style = MaterialTheme.typography.bodyMedium)
  }
}
