package com.example.ui.auth

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LockReset
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.example.ui.components.JuiBrandGradient
import com.example.ui.components.JuiLogoBadge
import com.example.ui.components.JuiWordmarkHeader
import com.example.ui.theme.JuiCardSurface
import com.example.ui.theme.JuiCyanAccent
import com.example.ui.theme.JuiDangerRed
import com.example.ui.theme.JuiDeepSurface
import com.example.ui.theme.JuiElectricBlue
import com.example.ui.theme.JuiMidnight
import com.example.ui.theme.JuiSuccessGreen
import com.example.ui.theme.JuiTextSecondary
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

fun attemptAutoSignIn(
  context: Context,
  credentialManager: CredentialManager,
  onAuthSuccess: () -> Unit,
  onUnauthenticated: () -> Unit,
  scope: CoroutineScope,
) {
  if (Firebase.auth.currentUser != null) {
    onAuthSuccess()
    return
  }
  val clientId = try {
    context.getString(R.string.default_web_client_id)
  } catch (e: Exception) {
    onUnauthenticated()
    return
  }

  val googleIdOption = GetGoogleIdOption.Builder()
    .setFilterByAuthorizedAccounts(true)
    .setServerClientId(clientId)
    .setAutoSelectEnabled(true)
    .build()

  val request = GetCredentialRequest.Builder().addCredentialOption(googleIdOption).build()

  scope.launch {
    try {
      val result = credentialManager.getCredential(context, request)
      val credential = result.credential
      if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
        val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
        val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
        Firebase.auth.signInWithCredential(authCredential).await()
        onAuthSuccess()
      } else {
        onUnauthenticated()
      }
    } catch (e: Exception) {
      onUnauthenticated()
    }
  }
}

fun onGoogleSignInClicked(
  context: Context,
  credentialManager: CredentialManager,
  onAuthSuccess: () -> Unit,
  onAuthError: (String) -> Unit,
  scope: CoroutineScope,
  onAuthCancelled: () -> Unit = {},
) {
  val clientId = try {
    context.getString(R.string.default_web_client_id)
  } catch (e: Exception) {
    onAuthError("Google Sign-In configuration missing: default_web_client_id not found")
    return
  }

  val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
  val request = GetCredentialRequest.Builder().addCredentialOption(signInOption).build()

  scope.launch {
    try {
      val activityContext = context as? Activity ?: context
      val result = credentialManager.getCredential(activityContext, request)
      val credential = result.credential
      if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
        val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
        val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
        Firebase.auth.signInWithCredential(authCredential).await()
        onAuthSuccess()
      } else {
        onAuthError("Unexpected credential type")
      }
    } catch (e: GetCredentialCancellationException) {
      Log.w("Auth", "Google Sign-In cancelled or dismissed: ${e.message}", e)
      onAuthCancelled()
    } catch (e: Exception) {
      Log.e("Auth", "Google Sign-In failed", e)
      onAuthError(e.localizedMessage ?: "Sign in failed")
    }
  }
}

fun signOutJuiUser(
  context: Context,
  onSignOutComplete: () -> Unit,
  scope: CoroutineScope,
) {
  val credentialManager = CredentialManager.create(context)
  Firebase.auth.signOut()
  scope.launch {
    try {
      credentialManager.clearCredentialState(ClearCredentialStateRequest())
    } catch (e: Exception) {
      Log.e("Auth", "Failed to clear credential state", e)
    } finally {
      onSignOutComplete()
    }
  }
}

@Composable
fun JuiAuthAndOnboardingScreen(
  onAuthSuccess: () -> Unit,
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val credentialManager = remember { CredentialManager.create(context) }

  var isLoading by remember { mutableStateOf(false) }
  var errorMessage by remember { mutableStateOf<String?>(null) }
  var onboardingStep by remember { mutableIntStateOf(0) }
  var showPasswordRecoveryDialog by remember { mutableStateOf(false) }

  val onboardingSlides = listOf(
    Triple(
      "Moderated Short-Video Feed",
      "Every uploaded video on JUI Social Madia starts in PENDING status and is reviewed by authorized moderators before appearing in the public feed.",
      "Safe & Verified Media",
    ),
    Triple(
      "Community Groups & Private Chat",
      "Join creator communities with role-based moderation and enjoy private 1-to-1 messaging protected from unauthorized snooping.",
      "Protected Privacy",
    ),
    Triple(
      "Permanent Super Owner Governance",
      "Backed by zero-trust Firestore rules, granular admin permissions, re-authentication checks, and append-only administrative audit logs.",
      "Zero-Trust Architecture",
    ),
  )

  LaunchedEffect(Unit) {
    attemptAutoSignIn(
      context = context,
      credentialManager = credentialManager,
      onAuthSuccess = onAuthSuccess,
      onUnauthenticated = {},
      scope = scope,
    )
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(JuiMidnight)
      .systemBarsPadding(),
    contentAlignment = Alignment.Center,
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .widthIn(max = 520.dp)
        .verticalScroll(rememberScrollState())
        .padding(24.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
      // Top Hero Card with JUI Social Madia Branding
      Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = JuiDeepSurface),
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, JuiBrandGradient, RoundedCornerShape(24.dp)),
      ) {
        Box(modifier = Modifier.fillMaxWidth()) {
          Image(
            painter = painterResource(id = R.drawable.img_jui_hero_banner_1792917020662),
            contentDescription = "JUI Social Madia Banner",
            contentScale = ContentScale.Crop,
            alpha = 0.28f,
            modifier = Modifier
              .fillMaxWidth()
              .height(180.dp),
          )
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
          ) {
            JuiLogoBadge(size = 68.dp)
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              text = "JUI Social Madia",
              style = MaterialTheme.typography.headlineLarge,
              color = Color.White,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.testTag("auth_brand_title"),
            )
            Text(
              text = "Next-Gen Moderated Short Video & Community Platform",
              style = MaterialTheme.typography.bodyMedium,
              color = JuiTextSecondary,
            )
          }
        }
      }

      // Onboarding Interactive Card
      val currentSlide = onboardingSlides[onboardingStep]
      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = JuiCardSurface),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(
          modifier = Modifier.padding(20.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Surface(
              color = JuiElectricBlue.copy(alpha = 0.2f),
              shape = RoundedCornerShape(50),
            ) {
              Text(
                text = currentSlide.third,
                style = MaterialTheme.typography.labelMedium,
                color = JuiCyanAccent,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
              )
            }
            Text(
              text = "Step ${onboardingStep + 1} of ${onboardingSlides.size}",
              style = MaterialTheme.typography.labelMedium,
              color = JuiTextSecondary,
            )
          }
          Text(
            text = currentSlide.first,
            style = MaterialTheme.typography.titleLarge,
            color = Color.White,
          )
          Text(
            text = currentSlide.second,
            style = MaterialTheme.typography.bodyMedium,
            color = JuiTextSecondary,
          )
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            TextButton(
              onClick = {
                onboardingStep = (onboardingStep - 1 + onboardingSlides.size) % onboardingSlides.size
              },
            ) {
              Text("Previous")
            }
            TextButton(
              onClick = {
                onboardingStep = (onboardingStep + 1) % onboardingSlides.size
              },
              modifier = Modifier.testTag("onboarding_next_button"),
            ) {
              Text("Next Feature")
            }
          }
        }
      }

      // Sign-In & Registration Card
      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = JuiDeepSurface),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(
          modifier = Modifier.padding(20.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.VerifiedUser,
              contentDescription = null,
              tint = JuiCyanAccent,
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Secure Account Registration & Sign-In",
              style = MaterialTheme.typography.titleMedium,
              color = Color.White,
            )
          }
          Text(
            text = "Authenticate securely using Google Identity via Android Credential Manager. After signing in, you will claim your unique @username on JUI Social Madia.",
            style = MaterialTheme.typography.bodyMedium,
            color = JuiTextSecondary,
          )

          if (errorMessage != null) {
            Surface(
              color = JuiDangerRed.copy(alpha = 0.16f),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.fillMaxWidth(),
            ) {
              Text(
                text = errorMessage ?: "",
                color = JuiDangerRed,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(12.dp),
              )
            }
          }

          Button(
            onClick = {
              errorMessage = null
              isLoading = true
              onGoogleSignInClicked(
                context = context,
                credentialManager = credentialManager,
                onAuthSuccess = {
                  isLoading = false
                  onAuthSuccess()
                },
                onAuthError = { msg ->
                  isLoading = false
                  errorMessage = msg
                },
                scope = scope,
                onAuthCancelled = {
                  isLoading = false
                },
              )
            },
            enabled = !isLoading,
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = JuiElectricBlue),
            modifier = Modifier
              .fillMaxWidth()
              .height(54.dp)
              .testTag("google_sign_in_button"),
          ) {
            if (isLoading) {
              CircularProgressIndicator(
                modifier = Modifier.size(22.dp),
                color = Color.White,
                strokeWidth = 2.dp,
              )
            } else {
              Icon(Icons.Default.AccountCircle, contentDescription = null)
              Spacer(modifier = Modifier.width(10.dp))
              Text("Sign in with Google", fontWeight = FontWeight.Bold)
            }
          }

          TextButton(
            onClick = { showPasswordRecoveryDialog = true },
            modifier = Modifier.testTag("account_recovery_button"),
          ) {
            Icon(Icons.Default.LockReset, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Account Recovery & Password Reset Info")
          }
        }
      }
    }
  }

  if (showPasswordRecoveryDialog) {
    AlertDialog(
      onDismissRequest = { showPasswordRecoveryDialog = false },
      containerColor = JuiCardSurface,
      title = { Text("Account Recovery & Session Security", color = Color.White) },
      text = {
        Text(
          text = "JUI Social Madia uses hardware-backed Google Identity (Credential Manager) so your password is never stored or exposed to client servers.\n\nTo reset your Google account password or manage 2-Step Verification, visit myaccount.google.com/security on your Android device.",
          color = JuiTextSecondary,
        )
      },
      confirmButton = {
        Button(onClick = { showPasswordRecoveryDialog = false }) {
          Text("Got It")
        }
      },
    )
  }
}

@Composable
fun ProfileRegistrationGateScreen(
  suggestedDisplayName: String,
  isSubmitting: Boolean,
  errorMessage: String?,
  onSubmitRegistration: (username: String, displayName: String, bio: String, isPrivate: Boolean, ageVerified: Boolean) -> Unit,
  onSignOut: () -> Unit,
) {
  var username by remember {
    mutableStateOf(
      suggestedDisplayName.lowercase().replace(Regex("[^a-z0-9_]"), "").take(16).ifEmpty { "juicreator" }
    )
  }
  var displayName by remember { mutableStateOf(suggestedDisplayName.ifEmpty { "JUI Creator" }) }
  var bio by remember { mutableStateOf("Creating short videos on JUI Social Madia") }
  var isPrivate by remember { mutableStateOf(false) }
  var ageVerified by remember { mutableStateOf(true) }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(JuiMidnight)
      .systemBarsPadding(),
    contentAlignment = Alignment.Center,
  ) {
    Card(
      shape = RoundedCornerShape(24.dp),
      colors = CardDefaults.cardColors(containerColor = JuiDeepSurface),
      modifier = Modifier
        .fillMaxWidth()
        .widthIn(max = 520.dp)
        .padding(20.dp)
        .verticalScroll(rememberScrollState()),
    ) {
      Column(
        modifier = Modifier.padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        JuiWordmarkHeader(subtitle = "Complete Your Unique Creator Profile")

        Text(
          text = "Choose a unique @username. Duplicate usernames are automatically blocked by the JUI Social Madia backend.",
          style = MaterialTheme.typography.bodyMedium,
          color = JuiTextSecondary,
        )

        if (!errorMessage.isNullOrBlank()) {
          Surface(
            color = JuiDangerRed.copy(alpha = 0.18f),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Text(
              text = errorMessage,
              color = JuiDangerRed,
              style = MaterialTheme.typography.bodyMedium,
              modifier = Modifier.padding(12.dp),
            )
          }
        }

        OutlinedTextField(
          value = username,
          onValueChange = { username = it.lowercase().replace(Regex("[^a-z0-9_]"), "") },
          label = { Text("Unique Username (3-30 chars, a-z, 0-9, _)") },
          prefix = { Text("@") },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("register_username_input"),
        )

        OutlinedTextField(
          value = displayName,
          onValueChange = { displayName = it },
          label = { Text("Display Name") },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("register_display_name_input"),
        )

        OutlinedTextField(
          value = bio,
          onValueChange = { bio = it },
          label = { Text("Bio (up to 250 chars)") },
          maxLines = 3,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("register_bio_input"),
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text("Private Account", color = Color.White, style = MaterialTheme.typography.titleMedium)
            Text("Only approved followers see your activity", color = JuiTextSecondary, style = MaterialTheme.typography.bodyMedium)
          }
          Switch(checked = isPrivate, onCheckedChange = { isPrivate = it })
        }

        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Checkbox(
            checked = ageVerified,
            onCheckedChange = { ageVerified = it },
          )
          Text(
            text = "I confirm I am at least 13 years old and agree to the JUI Social Madia Community Guidelines & Safety Policy.",
            style = MaterialTheme.typography.bodyMedium,
            color = Color.White,
          )
        }

        Button(
          onClick = {
            onSubmitRegistration(username, displayName, bio, isPrivate, ageVerified)
          },
          enabled = !isSubmitting && username.length >= 3 && displayName.isNotBlank() && ageVerified,
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.buttonColors(containerColor = JuiElectricBlue),
          modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .testTag("complete_registration_button"),
        ) {
          if (isSubmitting) {
            CircularProgressIndicator(modifier = Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
          } else {
            Icon(Icons.Default.CheckCircle, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Create JUI Social Madia Profile", fontWeight = FontWeight.Bold)
          }
        }

        OutlinedButton(
          onClick = onSignOut,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Text("Sign Out")
        }
      }
    }
  }
}
