package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.AdminRole
import com.example.data.model.AppNotification
import com.example.data.model.AuditLog
import com.example.data.model.BlockRecord
import com.example.data.model.CommunityGroup
import com.example.data.model.Conversation
import com.example.data.model.FollowRecord
import com.example.data.model.GroupMember
import com.example.data.model.GroupPost
import com.example.data.model.ModerationReport
import com.example.data.model.PrivateMessage
import com.example.data.model.ShortVideo
import com.example.data.model.SuperOwnerConfig
import com.example.data.model.UserProfile
import com.example.data.model.VideoComment
import com.example.data.model.VideoInteraction
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.snapshots
import java.util.UUID
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class JuiSocialRepository(
  private val db: FirebaseFirestore,
  private val auth: FirebaseAuth = Firebase.auth,
) {
  constructor(context: Context) : this(
    FirebaseFirestore.getInstance(
      context.applicationContext.getString(R.string.firestore_database_id)
    ),
    Firebase.auth
  )

  private fun requireUserId(): String {
    return auth.currentUser?.uid
      ?: throw IllegalStateException("User must be signed in before accessing JUI Social Madia.")
  }

  private fun sanitizeId(raw: String): String {
    return raw.trim().replace(Regex("[^a-zA-Z0-9_\\-]"), "_").take(120).ifEmpty {
      "id_${UUID.randomUUID().toString().replace("-", "").take(16)}"
    }
  }

  // =========================================================================
  // 1. USER PROFILES & USERNAME REGISTRATION
  // =========================================================================
  fun observeUserProfile(userId: String): Flow<UserProfile?> {
    val path = "users/$userId"
    return db.collection("users").document(userId)
      .snapshots()
      .map { snapshot ->
        if (snapshot.exists()) {
          snapshot.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
        } else {
          null
        }
      }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.GET, path)
        throw e
      }
  }

  fun observeActiveProfiles(): Flow<List<UserProfile>> {
    val path = "users"
    return db.collection(path)
      .whereEqualTo("accountStatus", "ACTIVE")
      .snapshots()
      .map { snap ->
        snap.toObjects(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
      }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
        throw e
      }
  }

  suspend fun registerUserProfile(
    username: String,
    displayName: String,
    bio: String,
    isPrivate: Boolean = false,
    ageVerified: Boolean = true,
  ): Result<UserProfile> = runCatching {
    val uid = requireUserId()
    val cleanUsername = username.trim().lowercase().replace(Regex("[^a-z0-9_]"), "")
    require(cleanUsername.length in 3..30) { "Username must be 3-30 alphanumeric/underscore characters." }
    require(displayName.trim().isNotEmpty()) { "Display name is required." }
    require(ageVerified) { "Age safety verification is required to use JUI Social Madia." }

    val usernameRef = db.collection("usernames").document(cleanUsername)
    val userRef = db.collection("users").document(uid)

    try {
      val batch = db.batch()
      batch.set(
        usernameRef,
        mapOf(
          "username" to cleanUsername,
          "userId" to uid,
          "createdAt" to FieldValue.serverTimestamp(),
        )
      )
      batch.set(
        userRef,
        mapOf(
          "userId" to uid,
          "username" to cleanUsername,
          "displayName" to displayName.trim().take(60),
          "bio" to bio.trim().take(250),
          "avatarUrl" to "",
          "isPrivate" to isPrivate,
          "ageVerified" to true,
          "accountStatus" to "ACTIVE",
          "followersCount" to 0L,
          "followingCount" to 0L,
          "uploadedVideosCount" to 0L,
          "createdAt" to FieldValue.serverTimestamp(),
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      )
      batch.commit().await()
      val saved = userRef.get().await().toObject(
        UserProfile::class.java,
        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
      )
      checkNotNull(saved) { "Profile creation failed" }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, userRef.path)
      throw e
    }
  }

  suspend fun updateUserProfile(
    displayName: String,
    bio: String,
    isPrivate: Boolean,
  ): Result<Unit> = runCatching {
    val uid = requireUserId()
    val userRef = db.collection("users").document(uid)
    try {
      userRef.update(
        mapOf(
          "displayName" to displayName.trim().take(60),
          "bio" to bio.trim().take(250),
          "isPrivate" to isPrivate,
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, userRef.path)
      throw e
    }
  }

  suspend fun deleteOwnAccount(username: String): Result<Unit> = runCatching {
    val uid = requireUserId()
    val userRef = db.collection("users").document(uid)
    val usernameRef = db.collection("usernames").document(username)
    try {
      val batch = db.batch()
      batch.delete(userRef)
      if (username.isNotBlank()) {
        batch.delete(usernameRef)
      }
      batch.commit().await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, userRef.path)
      throw e
    }
  }

  // =========================================================================
  // 2. FOLLOWS & BLOCKS
  // =========================================================================
  fun observeFollowing(userId: String): Flow<List<FollowRecord>> {
    val path = "follows"
    return db.collection(path)
      .whereEqualTo("followerUid", userId)
      .snapshots()
      .map { it.toObjects(FollowRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
        throw e
      }
  }

  fun observeFollowers(userId: String): Flow<List<FollowRecord>> {
    val path = "follows"
    return db.collection(path)
      .whereEqualTo("followedUid", userId)
      .snapshots()
      .map { it.toObjects(FollowRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
        throw e
      }
  }

  fun observeBlockedUsers(userId: String): Flow<List<BlockRecord>> {
    val path = "blocks"
    return db.collection(path)
      .whereEqualTo("blockerUid", userId)
      .snapshots()
      .map { it.toObjects(BlockRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
        throw e
      }
  }

  suspend fun followUser(
    followerUsername: String,
    followedUid: String,
    followedUsername: String,
  ): Result<Unit> = runCatching {
    val uid = requireUserId()
    val followId = "${uid}_$followedUid"
    val followRef = db.collection("follows").document(followId)
    try {
      followRef.set(
        mapOf(
          "followerUid" to uid,
          "followerUsername" to followerUsername.take(60),
          "followedUid" to followedUid,
          "followedUsername" to followedUsername.take(60),
          "createdAt" to FieldValue.serverTimestamp(),
        )
      ).await()
      sendNotification(
        recipientUid = followedUid,
        actorName = followerUsername,
        type = "FOLLOW",
        title = "New Follower on JUI Social Madia",
        body = "@$followerUsername started following you.",
        targetId = uid,
      )
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, followRef.path)
      throw e
    }
  }

  suspend fun unfollowUser(followedUid: String): Result<Unit> = runCatching {
    val uid = requireUserId()
    val followRef = db.collection("follows").document("${uid}_$followedUid")
    try {
      followRef.delete().await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, followRef.path)
      throw e
    }
  }

  suspend fun blockUser(
    blockedUid: String,
    blockedUsername: String,
    reason: String,
  ): Result<Unit> = runCatching {
    val uid = requireUserId()
    val blockId = "${uid}_$blockedUid"
    val blockRef = db.collection("blocks").document(blockId)
    try {
      blockRef.set(
        mapOf(
          "blockerUid" to uid,
          "blockedUid" to blockedUid,
          "blockedUsername" to blockedUsername.take(60),
          "reason" to reason.trim().take(200),
          "createdAt" to FieldValue.serverTimestamp(),
        )
      ).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, blockRef.path)
      throw e
    }
  }

  suspend fun unblockUser(blockedUid: String): Result<Unit> = runCatching {
    val uid = requireUserId()
    val blockRef = db.collection("blocks").document("${uid}_$blockedUid")
    try {
      blockRef.delete().await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, blockRef.path)
      throw e
    }
  }

  // =========================================================================
  // 3. SHORT VIDEO FEED & VIDEO APPROVAL SYSTEM
  // =========================================================================
  fun observeApprovedFeed(): Flow<List<ShortVideo>> {
    val path = "videos"
    return db.collection(path)
      .whereEqualTo("status", "APPROVED")
      .snapshots()
      .map { snap ->
        snap.toObjects(ShortVideo::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.createdAt?.seconds ?: 0L }
      }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
        throw e
      }
  }

  fun observeUserUploadedVideos(authorUid: String): Flow<List<ShortVideo>> {
    val path = "videos"
    return db.collection(path)
      .whereEqualTo("authorUid", authorUid)
      .snapshots()
      .map { snap ->
        snap.toObjects(ShortVideo::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.createdAt?.seconds ?: 0L }
      }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
        throw e
      }
  }

  fun observePendingVideosForModeration(): Flow<List<ShortVideo>> {
    val path = "videos"
    return db.collection(path)
      .whereEqualTo("status", "PENDING")
      .snapshots()
      .map { snap ->
        snap.toObjects(ShortVideo::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.createdAt?.seconds ?: 0L }
      }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
        throw e
      }
  }

  suspend fun getVideoById(videoId: String): Result<ShortVideo?> = runCatching {
    val docRef = db.collection("videos").document(videoId)
    try {
      docRef.get().await().toObject(ShortVideo::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.GET, docRef.path)
      throw e
    }
  }

  suspend fun uploadShortVideo(
    authorUsername: String,
    authorDisplayName: String,
    caption: String,
    hashtags: String,
    videoUrl: String,
    audioTitle: String,
    audioLicense: String,
    fileMimeType: String = "video/mp4",
    fileSizeBytes: Long = 4_500_000L,
    durationSeconds: Long = 15L,
    forcedStatusForTest: String = "PENDING",
  ): Result<String> = runCatching {
    val uid = requireUserId()
    val videoId = "vid_${UUID.randomUUID().toString().replace("-", "").take(16)}"
    val docRef = db.collection("videos").document(videoId)
    try {
      docRef.set(
        mapOf(
          "authorUid" to uid,
          "authorUsername" to authorUsername.take(60),
          "authorDisplayName" to authorDisplayName.take(80),
          "caption" to caption.trim().take(300),
          "hashtags" to hashtags.trim().take(200),
          "videoUrl" to videoUrl.trim().take(500).ifEmpty { "jui://media/$videoId.mp4" },
          "thumbnailUrl" to "",
          "audioTitle" to audioTitle.trim().take(120).ifEmpty { "Original JUI Studio Audio" },
          "audioLicense" to audioLicense.trim().take(120).ifEmpty { "CC-BY 4.0 Royalty-Free" },
          "fileMimeType" to fileMimeType,
          "fileSizeBytes" to fileSizeBytes,
          "durationSeconds" to durationSeconds,
          "status" to forcedStatusForTest,
          "rejectionReason" to "",
          "moderatedByUid" to "",
          "likesCount" to 0L,
          "commentsCount" to 0L,
          "sharesCount" to 0L,
          "viewsCount" to 0L,
          "savesCount" to 0L,
          "createdAt" to FieldValue.serverTimestamp(),
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
      videoId
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path)
      throw e
    }
  }

  suspend fun moderateVideo(
    video: ShortVideo,
    approve: Boolean,
    rejectionReason: String,
    moderatorName: String,
    reauthVerified: Boolean = true,
  ): Result<Unit> = runCatching {
    val uid = requireUserId()
    val newStatus = if (approve) "APPROVED" else "REJECTED"
    val cleanReason = if (approve) "" else rejectionReason.trim().ifEmpty { "Does not meet JUI community guidelines" }
    val docRef = db.collection("videos").document(video.id)
    try {
      docRef.update(
        mapOf(
          "status" to newStatus,
          "rejectionReason" to cleanReason.take(300),
          "moderatedByUid" to uid,
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
      sendNotification(
        recipientUid = video.authorUid,
        actorName = moderatorName,
        type = "VIDEO_DECISION",
        title = if (approve) "Video Approved!" else "Video Rejected",
        body = if (approve) {
          "Your video '${video.caption.take(40)}' is now live on the JUI Social Madia feed."
        } else {
          "Your video '${video.caption.take(40)}' was rejected. Reason: $cleanReason"
        },
        targetId = video.id,
      )
      appendAuditLog(
        actorName = moderatorName,
        action = if (approve) "APPROVE_VIDEO" else "REJECT_VIDEO",
        targetId = video.id,
        targetType = "VIDEO",
        result = "SUCCESS",
        details = if (approve) "Approved video by @${video.authorUsername}" else "Rejected: $cleanReason",
        reauthVerified = reauthVerified,
      )
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      throw e
    }
  }

  suspend fun toggleLikeVideo(
    video: ShortVideo,
    actorUsername: String,
    currentlyLiked: Boolean,
  ): Result<Unit> = runCatching {
    val uid = requireUserId()
    val likeRef = db.collection("video_likes").document("${video.id}_$uid")
    val videoRef = db.collection("videos").document(video.id)
    try {
      if (currentlyLiked) {
        likeRef.delete().await()
        videoRef.update(
          mapOf(
            "likesCount" to (video.likesCount - 1L).coerceAtLeast(0L),
            "updatedAt" to FieldValue.serverTimestamp(),
          )
        ).await()
      } else {
        likeRef.set(
          mapOf(
            "videoId" to video.id,
            "userId" to uid,
            "createdAt" to FieldValue.serverTimestamp(),
          )
        ).await()
        videoRef.update(
          mapOf(
            "likesCount" to (video.likesCount + 1L),
            "updatedAt" to FieldValue.serverTimestamp(),
          )
        ).await()
        if (video.authorUid != uid) {
          sendNotification(
            recipientUid = video.authorUid,
            actorName = actorUsername,
            type = "LIKE",
            title = "New Like on Your Video",
            body = "@$actorUsername liked '${video.caption.take(40)}'",
            targetId = video.id,
          )
        }
      }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, likeRef.path)
      throw e
    }
  }

  suspend fun toggleSaveVideo(
    video: ShortVideo,
    currentlySaved: Boolean,
  ): Result<Unit> = runCatching {
    val uid = requireUserId()
    val saveRef = db.collection("saved_videos").document("${video.id}_$uid")
    val videoRef = db.collection("videos").document(video.id)
    try {
      if (currentlySaved) {
        saveRef.delete().await()
        videoRef.update(
          mapOf(
            "savesCount" to (video.savesCount - 1L).coerceAtLeast(0L),
            "updatedAt" to FieldValue.serverTimestamp(),
          )
        ).await()
      } else {
        saveRef.set(
          mapOf(
            "videoId" to video.id,
            "userId" to uid,
            "createdAt" to FieldValue.serverTimestamp(),
          )
        ).await()
        videoRef.update(
          mapOf(
            "savesCount" to (video.savesCount + 1L),
            "updatedAt" to FieldValue.serverTimestamp(),
          )
        ).await()
      }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, saveRef.path)
      throw e
    }
  }

  suspend fun recordVideoShareOrView(video: ShortVideo, isShare: Boolean): Result<Unit> = runCatching {
    val videoRef = db.collection("videos").document(video.id)
    try {
      val field = if (isShare) "sharesCount" else "viewsCount"
      val nextVal = if (isShare) video.sharesCount + 1L else video.viewsCount + 1L
      videoRef.update(
        mapOf(
          field to nextVal,
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, videoRef.path)
      throw e
    }
  }

  fun observeLikedVideoIds(userId: String): Flow<Set<String>> {
    val path = "video_likes"
    return db.collection(path)
      .whereEqualTo("userId", userId)
      .snapshots()
      .map { snap ->
        snap.toObjects(VideoInteraction::class.java).map { it.videoId }.toSet()
      }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
        throw e
      }
  }

  fun observeSavedVideoIds(userId: String): Flow<Set<String>> {
    val path = "saved_videos"
    return db.collection(path)
      .whereEqualTo("userId", userId)
      .snapshots()
      .map { snap ->
        snap.toObjects(VideoInteraction::class.java).map { it.videoId }.toSet()
      }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
        throw e
      }
  }

  // =========================================================================
  // 4. COMMENTS & REPLIES
  // =========================================================================
  fun observeCommentsForVideo(videoId: String): Flow<List<VideoComment>> {
    val path = "comments"
    return db.collection(path)
      .whereEqualTo("videoId", videoId)
      .whereEqualTo("status", "ACTIVE")
      .snapshots()
      .map { snap ->
        snap.toObjects(VideoComment::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedBy { it.createdAt?.seconds ?: 0L }
      }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
        throw e
      }
  }

  suspend fun addComment(
    video: ShortVideo,
    authorUsername: String,
    text: String,
    parentCommentId: String = "",
  ): Result<String> = runCatching {
    val uid = requireUserId()
    val commentId = "cmt_${UUID.randomUUID().toString().replace("-", "").take(16)}"
    val commentRef = db.collection("comments").document(commentId)
    val videoRef = db.collection("videos").document(video.id)
    try {
      commentRef.set(
        mapOf(
          "videoId" to video.id,
          "authorUid" to uid,
          "authorUsername" to authorUsername.take(60),
          "text" to text.trim().take(400),
          "parentCommentId" to parentCommentId.take(128),
          "status" to "ACTIVE",
          "createdAt" to FieldValue.serverTimestamp(),
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
      videoRef.update(
        mapOf(
          "commentsCount" to (video.commentsCount + 1L),
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
      if (video.authorUid != uid) {
        sendNotification(
          recipientUid = video.authorUid,
          actorName = authorUsername,
          type = "COMMENT",
          title = "New Comment on Your Video",
          body = "@$authorUsername: ${text.take(60)}",
          targetId = video.id,
        )
      }
      commentId
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, commentRef.path)
      throw e
    }
  }

  suspend fun moderateRemoveComment(commentId: String): Result<Unit> = runCatching {
    val commentRef = db.collection("comments").document(commentId)
    try {
      commentRef.update(
        mapOf(
          "status" to "REMOVED",
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, commentRef.path)
      throw e
    }
  }

  // =========================================================================
  // 5. PRIVATE MESSAGES & CONVERSATIONS
  // =========================================================================
  fun observeConversations(userId: String): Flow<List<Conversation>> {
    val path = "conversations"
    return db.collection(path)
      .whereArrayContains("participantUids", userId)
      .snapshots()
      .map { snap ->
        snap.toObjects(Conversation::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.updatedAt?.seconds ?: 0L }
      }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
        throw e
      }
  }

  fun observeMessages(userId: String): Flow<List<PrivateMessage>> {
    val path = "messages"
    return db.collection(path)
      .whereArrayContains("participantUids", userId)
      .snapshots()
      .map { snap ->
        snap.toObjects(PrivateMessage::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedBy { it.createdAt?.seconds ?: 0L }
      }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
        throw e
      }
  }

  suspend fun sendPrivateMessage(
    senderName: String,
    recipientUid: String,
    recipientName: String,
    text: String,
    retentionDays: Long = 90L,
  ): Result<String> = runCatching {
    val uid = requireUserId()
    val sortedUids = listOf(uid, recipientUid).sorted()
    val convId = sanitizeId("conv_${sortedUids[0]}_${sortedUids[1]}")
    val convRef = db.collection("conversations").document(convId)
    val msgId = "msg_${UUID.randomUUID().toString().replace("-", "").take(16)}"
    val msgRef = db.collection("messages").document(msgId)
    try {
      val existingConv = try {
        convRef.get().await().exists()
      } catch (_: Exception) {
        false
      }
      if (!existingConv) {
        convRef.set(
          mapOf(
            "participantUids" to sortedUids,
            "participantNames" to "$senderName & $recipientName".take(150),
            "lastMessageText" to text.trim().take(400),
            "retentionDays" to retentionDays,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp(),
          )
        ).await()
      } else {
        convRef.update(
          mapOf(
            "lastMessageText" to text.trim().take(400),
            "retentionDays" to retentionDays,
            "updatedAt" to FieldValue.serverTimestamp(),
          )
        ).await()
      }

      msgRef.set(
        mapOf(
          "conversationId" to convId,
          "senderUid" to uid,
          "senderName" to senderName.take(80),
          "recipientUid" to recipientUid,
          "participantUids" to sortedUids,
          "text" to text.trim().take(1000),
          "isRead" to false,
          "createdAt" to FieldValue.serverTimestamp(),
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
      msgId
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, msgRef.path)
      throw e
    }
  }

  suspend fun markMessageRead(messageId: String): Result<Unit> = runCatching {
    val msgRef = db.collection("messages").document(messageId)
    try {
      msgRef.update(
        mapOf(
          "isRead" to true,
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, msgRef.path)
      throw e
    }
  }

  // =========================================================================
  // 6. NOTIFICATIONS
  // =========================================================================
  fun observeNotifications(userId: String): Flow<List<AppNotification>> {
    val path = "notifications"
    return db.collection(path)
      .whereEqualTo("recipientUid", userId)
      .snapshots()
      .map { snap ->
        snap.toObjects(AppNotification::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.createdAt?.seconds ?: 0L }
      }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
        throw e
      }
  }

  suspend fun sendNotification(
    recipientUid: String,
    actorName: String,
    type: String,
    title: String,
    body: String,
    targetId: String,
  ): Result<Unit> = runCatching {
    val uid = requireUserId()
    val notifId = "ntf_${UUID.randomUUID().toString().replace("-", "").take(16)}"
    val notifRef = db.collection("notifications").document(notifId)
    try {
      notifRef.set(
        mapOf(
          "recipientUid" to recipientUid,
          "actorUid" to uid,
          "actorName" to actorName.take(80),
          "type" to type,
          "title" to title.take(120),
          "body" to body.take(300),
          "targetId" to targetId.take(128),
          "isRead" to false,
          "createdAt" to FieldValue.serverTimestamp(),
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, notifRef.path)
      throw e
    }
  }

  suspend fun markNotificationRead(notificationId: String): Result<Unit> = runCatching {
    val notifRef = db.collection("notifications").document(notificationId)
    try {
      notifRef.update(
        mapOf(
          "isRead" to true,
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, notifRef.path)
      throw e
    }
  }

  // =========================================================================
  // 7. GROUPS, MEMBERSHIPS & GROUP POSTS
  // =========================================================================
  fun observePublicGroups(): Flow<List<CommunityGroup>> {
    val path = "groups"
    return db.collection(path)
      .whereEqualTo("isPublic", true)
      .snapshots()
      .map { snap ->
        snap.toObjects(CommunityGroup::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.createdAt?.seconds ?: 0L }
      }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
        throw e
      }
  }

  fun observeUserGroupMemberships(userId: String): Flow<List<GroupMember>> {
    val path = "group_members"
    return db.collection(path)
      .whereEqualTo("userId", userId)
      .snapshots()
      .map { snap ->
        snap.toObjects(GroupMember::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
      }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
        throw e
      }
  }

  fun observeApprovedGroupMembers(groupId: String): Flow<List<GroupMember>> {
    val path = "group_members"
    return db.collection(path)
      .whereEqualTo("groupId", groupId)
      .whereEqualTo("status", "APPROVED")
      .snapshots()
      .map { snap ->
        snap.toObjects(GroupMember::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
      }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
        throw e
      }
  }

  fun observePendingGroupMembersForModerator(moderatorUid: String): Flow<List<GroupMember>> {
    val path = "group_members"
    return db.collection(path)
      .whereArrayContains("moderatorUids", moderatorUid)
      .snapshots()
      .map { snap ->
        snap.toObjects(GroupMember::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .filter { it.status == "PENDING" }
      }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
        throw e
      }
  }

  fun observeApprovedGroupPosts(groupId: String): Flow<List<GroupPost>> {
    val path = "group_posts"
    return db.collection(path)
      .whereEqualTo("groupId", groupId)
      .whereEqualTo("status", "APPROVED")
      .snapshots()
      .map { snap ->
        snap.toObjects(GroupPost::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.createdAt?.seconds ?: 0L }
      }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
        throw e
      }
  }

  fun observePendingGroupPostsForModerator(moderatorUid: String): Flow<List<GroupPost>> {
    val path = "group_posts"
    return db.collection(path)
      .whereArrayContains("moderatorUids", moderatorUid)
      .snapshots()
      .map { snap ->
        snap.toObjects(GroupPost::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .filter { it.status == "PENDING" }
      }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
        throw e
      }
  }

  suspend fun createGroup(
    name: String,
    description: String,
    creatorName: String,
    requirePostApproval: Boolean,
    isPublic: Boolean = true,
  ): Result<String> = runCatching {
    val uid = requireUserId()
    val groupId = "grp_${UUID.randomUUID().toString().replace("-", "").take(16)}"
    val groupRef = db.collection("groups").document(groupId)
    val memberRef = db.collection("group_members").document("${groupId}_$uid")
    try {
      groupRef.set(
        mapOf(
          "name" to name.trim().take(80),
          "description" to description.trim().take(400),
          "creatorUid" to uid,
          "creatorName" to creatorName.take(80),
          "requirePostApproval" to requirePostApproval,
          "isPublic" to isPublic,
          "membersCount" to 1L,
          "moderatorUids" to listOf(uid),
          "createdAt" to FieldValue.serverTimestamp(),
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
      memberRef.set(
        mapOf(
          "groupId" to groupId,
          "userId" to uid,
          "username" to creatorName.take(80),
          "role" to "CREATOR",
          "status" to "APPROVED",
          "moderatorUids" to listOf(uid),
          "createdAt" to FieldValue.serverTimestamp(),
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
      groupId
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, groupRef.path)
      throw e
    }
  }

  suspend fun requestGroupMembership(
    group: CommunityGroup,
    username: String,
  ): Result<Unit> = runCatching {
    val uid = requireUserId()
    val memberRef = db.collection("group_members").document("${group.id}_$uid")
    try {
      memberRef.set(
        mapOf(
          "groupId" to group.id,
          "userId" to uid,
          "username" to username.take(80),
          "role" to "MEMBER",
          "status" to "PENDING",
          "moderatorUids" to group.moderatorUids,
          "createdAt" to FieldValue.serverTimestamp(),
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, memberRef.path)
      throw e
    }
  }

  suspend fun approveGroupMember(
    member: GroupMember,
    newRole: String = "MEMBER",
  ): Result<Unit> = runCatching {
    val memberRef = db.collection("group_members").document(member.id)
    try {
      memberRef.update(
        mapOf(
          "status" to "APPROVED",
          "role" to newRole,
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
      sendNotification(
        recipientUid = member.userId,
        actorName = "Group Moderator",
        type = "GROUP_ACTIVITY",
        title = "Group Membership Approved",
        body = "Your membership in group ${member.groupId} is now APPROVED ($newRole).",
        targetId = member.groupId,
      )
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, memberRef.path)
      throw e
    }
  }

  suspend fun leaveGroup(groupId: String): Result<Unit> = runCatching {
    val uid = requireUserId()
    val memberRef = db.collection("group_members").document("${groupId}_$uid")
    try {
      memberRef.delete().await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, memberRef.path)
      throw e
    }
  }

  suspend fun createGroupPost(
    group: CommunityGroup,
    authorName: String,
    contentType: String,
    text: String,
    mediaUrl: String = "",
    forcedStatusForTest: String? = null,
  ): Result<String> = runCatching {
    val uid = requireUserId()
    val postId = "gpost_${UUID.randomUUID().toString().replace("-", "").take(16)}"
    val postRef = db.collection("group_posts").document(postId)
    val initialStatus = forcedStatusForTest ?: if (group.requirePostApproval) "PENDING" else "APPROVED"
    try {
      postRef.set(
        mapOf(
          "groupId" to group.id,
          "authorUid" to uid,
          "authorName" to authorName.take(80),
          "contentType" to contentType,
          "text" to text.trim().take(600),
          "mediaUrl" to mediaUrl.trim().take(500),
          "status" to initialStatus,
          "moderatedByUid" to "",
          "moderatorUids" to group.moderatorUids,
          "createdAt" to FieldValue.serverTimestamp(),
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
      postId
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, postRef.path)
      throw e
    }
  }

  suspend fun moderateGroupPost(
    postId: String,
    approve: Boolean,
  ): Result<Unit> = runCatching {
    val uid = requireUserId()
    val postRef = db.collection("group_posts").document(postId)
    try {
      postRef.update(
        mapOf(
          "status" to if (approve) "APPROVED" else "REJECTED",
          "moderatedByUid" to uid,
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, postRef.path)
      throw e
    }
  }

  // =========================================================================
  // 8. REPORTS & APPEALS
  // =========================================================================
  fun observeUserReports(reporterUid: String): Flow<List<ModerationReport>> {
    val path = "reports"
    return db.collection(path)
      .whereEqualTo("reporterUid", reporterUid)
      .snapshots()
      .map { snap ->
        snap.toObjects(ModerationReport::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.createdAt?.seconds ?: 0L }
      }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
        throw e
      }
  }

  fun observeOpenReportsForAdmin(): Flow<List<ModerationReport>> {
    val path = "reports"
    return db.collection(path)
      .whereEqualTo("status", "OPEN")
      .snapshots()
      .map { snap ->
        snap.toObjects(ModerationReport::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.createdAt?.seconds ?: 0L }
      }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
        throw e
      }
  }

  suspend fun submitReportOrAppeal(
    reporterName: String,
    targetId: String,
    targetType: String,
    reason: String,
    details: String,
  ): Result<String> = runCatching {
    val uid = requireUserId()
    val reportId = "rep_${UUID.randomUUID().toString().replace("-", "").take(16)}"
    val reportRef = db.collection("reports").document(reportId)
    try {
      reportRef.set(
        mapOf(
          "reporterUid" to uid,
          "reporterName" to reporterName.take(80),
          "targetId" to targetId.take(128),
          "targetType" to targetType,
          "reason" to reason.trim().take(150),
          "details" to details.trim().take(500),
          "status" to "OPEN",
          "resolutionNote" to "",
          "resolvedByUid" to "",
          "createdAt" to FieldValue.serverTimestamp(),
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
      reportId
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, reportRef.path)
      throw e
    }
  }

  suspend fun resolveReport(
    reportId: String,
    status: String,
    resolutionNote: String,
    adminName: String,
  ): Result<Unit> = runCatching {
    val uid = requireUserId()
    val reportRef = db.collection("reports").document(reportId)
    try {
      reportRef.update(
        mapOf(
          "status" to status,
          "resolutionNote" to resolutionNote.trim().take(400),
          "resolvedByUid" to uid,
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
      appendAuditLog(
        actorName = adminName,
        action = "RESOLVE_REPORT_$status",
        targetId = reportId,
        targetType = "REPORT",
        result = "SUCCESS",
        details = resolutionNote.take(200),
        reauthVerified = true,
      )
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, reportRef.path)
      throw e
    }
  }

  // =========================================================================
  // 9. PERMANENT SUPER OWNER, ADMIN ROLES & AUDIT LOGS
  // =========================================================================
  fun observeSuperOwnerConfig(): Flow<SuperOwnerConfig?> {
    val path = "platform_config/super_owner"
    return db.collection("platform_config").document("super_owner")
      .snapshots()
      .map { snap ->
        if (snap.exists()) {
          snap.toObject(SuperOwnerConfig::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
        } else {
          null
        }
      }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.GET, path)
        throw e
      }
  }

  fun observeAdminRole(userId: String): Flow<AdminRole?> {
    val path = "admin_roles/$userId"
    return db.collection("admin_roles").document(userId)
      .snapshots()
      .map { snap ->
        if (snap.exists()) {
          snap.toObject(AdminRole::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
        } else {
          null
        }
      }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.GET, path)
        throw e
      }
  }

  fun observeAllAdminRolesForSuperOwner(): Flow<List<AdminRole>> {
    val path = "admin_roles"
    return db.collection(path)
      .snapshots()
      .map { snap ->
        snap.toObjects(AdminRole::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
      }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
        throw e
      }
  }

  fun observeAuditLogsForSuperOwner(): Flow<List<AuditLog>> {
    val path = "audit_logs"
    return db.collection(path)
      .snapshots()
      .map { snap ->
        snap.toObjects(AuditLog::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.createdAt?.seconds ?: 0L }
      }
      .catch { e ->
        if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
        throw e
      }
  }

  suspend fun claimInitialSuperOwner(
    ownerName: String,
    reauthVerified: Boolean = true,
  ): Result<Unit> = runCatching {
    val uid = requireUserId()
    val docRef = db.collection("platform_config").document("super_owner")
    try {
      docRef.set(
        mapOf(
          "ownerUid" to uid,
          "ownerName" to ownerName.trim().take(80).ifEmpty { "JUI Super Owner" },
          "platformStatus" to "ONLINE",
          "allowPublicRegistration" to true,
          "requireModerationForAllVideos" to true,
          "reauthVerified" to reauthVerified,
          "createdAt" to FieldValue.serverTimestamp(),
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
      appendAuditLog(
        actorName = ownerName,
        action = "ESTABLISH_PERMANENT_SUPER_OWNER",
        targetId = uid,
        targetType = "SUPER_OWNER",
        result = "SUCCESS",
        details = "One-time server-side initialization of permanent Super Owner",
        reauthVerified = reauthVerified,
      )
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path)
      throw e
    }
  }

  suspend fun updateGlobalPlatformSettings(
    ownerName: String,
    platformStatus: String,
    allowPublicRegistration: Boolean,
    requireModerationForAllVideos: Boolean,
    reauthVerified: Boolean = true,
  ): Result<Unit> = runCatching {
    val uid = requireUserId()
    val docRef = db.collection("platform_config").document("super_owner")
    try {
      docRef.update(
        mapOf(
          "ownerName" to ownerName.take(80),
          "platformStatus" to platformStatus,
          "allowPublicRegistration" to allowPublicRegistration,
          "requireModerationForAllVideos" to requireModerationForAllVideos,
          "reauthVerified" to reauthVerified,
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
      appendAuditLog(
        actorName = ownerName,
        action = "UPDATE_GLOBAL_SETTINGS",
        targetId = uid,
        targetType = "PLATFORM_CONFIG",
        result = "SUCCESS",
        details = "Status=$platformStatus, Reg=$allowPublicRegistration, Moderation=$requireModerationForAllVideos",
        reauthVerified = reauthVerified,
      )
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      throw e
    }
  }

  suspend fun assignOrUpdateAdminRole(
    targetAdminUid: String,
    targetAdminName: String,
    canApproveVideos: Boolean,
    canModerateComments: Boolean,
    canManageReports: Boolean,
    canManageGroups: Boolean,
    canManageAppeals: Boolean,
    actorName: String,
    reauthVerified: Boolean = true,
  ): Result<Unit> = runCatching {
    val uid = requireUserId()
    val docRef = db.collection("admin_roles").document(targetAdminUid)
    try {
      val exists = try {
        docRef.get().await().exists()
      } catch (_: Exception) {
        false
      }
      if (!exists) {
        docRef.set(
          mapOf(
            "adminUid" to targetAdminUid,
            "adminName" to targetAdminName.take(80),
            "assignedByUid" to uid,
            "canApproveVideos" to canApproveVideos,
            "canModerateComments" to canModerateComments,
            "canManageReports" to canManageReports,
            "canManageGroups" to canManageGroups,
            "canManageAppeals" to canManageAppeals,
            "reauthVerified" to reauthVerified,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp(),
          )
        ).await()
      } else {
        docRef.update(
          mapOf(
            "adminName" to targetAdminName.take(80),
            "assignedByUid" to uid,
            "canApproveVideos" to canApproveVideos,
            "canModerateComments" to canModerateComments,
            "canManageReports" to canManageReports,
            "canManageGroups" to canManageGroups,
            "canManageAppeals" to canManageAppeals,
            "reauthVerified" to reauthVerified,
            "updatedAt" to FieldValue.serverTimestamp(),
          )
        ).await()
      }
      appendAuditLog(
        actorName = actorName,
        action = "ASSIGN_OR_UPDATE_ADMIN_PERMISSIONS",
        targetId = targetAdminUid,
        targetType = "ADMIN_ROLE",
        result = "SUCCESS",
        details = "videos=$canApproveVideos, comments=$canModerateComments, reports=$canManageReports, groups=$canManageGroups, appeals=$canManageAppeals",
        reauthVerified = reauthVerified,
      )
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docRef.path)
      throw e
    }
  }

  suspend fun removeAdminRole(
    targetAdminUid: String,
    actorName: String,
    reauthVerified: Boolean = true,
  ): Result<Unit> = runCatching {
    val docRef = db.collection("admin_roles").document(targetAdminUid)
    try {
      docRef.delete().await()
      appendAuditLog(
        actorName = actorName,
        action = "REMOVE_ADMIN_ROLE",
        targetId = targetAdminUid,
        targetType = "ADMIN_ROLE",
        result = "SUCCESS",
        details = "Revoked global admin role",
        reauthVerified = reauthVerified,
      )
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, docRef.path)
      throw e
    }
  }

  suspend fun setAccountSuspensionStatus(
    targetUserId: String,
    suspendAccount: Boolean,
    actorName: String,
    reauthVerified: Boolean = true,
  ): Result<Unit> = runCatching {
    val userRef = db.collection("users").document(targetUserId)
    val newStatus = if (suspendAccount) "SUSPENDED" else "ACTIVE"
    try {
      userRef.update(
        mapOf(
          "accountStatus" to newStatus,
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
      appendAuditLog(
        actorName = actorName,
        action = if (suspendAccount) "SUSPEND_USER_ACCOUNT" else "RESTORE_USER_ACCOUNT",
        targetId = targetUserId,
        targetType = "USER_ACCOUNT",
        result = "SUCCESS",
        details = "Account status set to $newStatus",
        reauthVerified = reauthVerified,
      )
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, userRef.path)
      throw e
    }
  }

  suspend fun appendAuditLog(
    actorName: String,
    action: String,
    targetId: String,
    targetType: String,
    result: String,
    details: String,
    reauthVerified: Boolean = true,
  ): Result<String> = runCatching {
    val uid = requireUserId()
    val logId = "log_${UUID.randomUUID().toString().replace("-", "").take(16)}"
    val logRef = db.collection("audit_logs").document(logId)
    try {
      logRef.set(
        mapOf(
          "actorUid" to uid,
          "actorName" to actorName.take(80).ifEmpty { "Admin" },
          "action" to action.take(100),
          "targetId" to targetId.take(128),
          "targetType" to targetType.take(50),
          "result" to result,
          "details" to details.take(500),
          "reauthVerified" to reauthVerified,
          "createdAt" to FieldValue.serverTimestamp(),
        )
      ).await()
      logId
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, logRef.path)
      throw e
    }
  }
}
