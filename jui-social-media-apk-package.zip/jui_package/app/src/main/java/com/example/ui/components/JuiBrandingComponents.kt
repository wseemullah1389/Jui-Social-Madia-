package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.JuiBrightBlue
import com.example.ui.theme.JuiCardSurface
import com.example.ui.theme.JuiCyanAccent
import com.example.ui.theme.JuiElectricBlue
import com.example.ui.theme.JuiMidnight
import com.example.ui.theme.JuiNeonPurple
import com.example.ui.theme.JuiTextSecondary
import com.example.ui.theme.JuiVioletPurple

val JuiBrandGradient = Brush.linearGradient(
  colors = listOf(JuiElectricBlue, JuiVioletPurple, JuiNeonPurple)
)

@Composable
fun JuiLogoBadge(
  size: Dp = 64.dp,
  modifier: Modifier = Modifier,
) {
  Box(
    modifier = modifier
      .size(size)
      .clip(RoundedCornerShape(size * 0.28f))
      .background(JuiBrandGradient)
      .border(1.5.dp, Color.White.copy(alpha = 0.3f), RoundedCornerShape(size * 0.28f)),
    contentAlignment = Alignment.Center,
  ) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val w = this.size.width
      val h = this.size.height
      // Connected social community rings
      drawCircle(
        color = Color.White.copy(alpha = 0.18f),
        radius = w * 0.40f,
        center = Offset(w * 0.5f, h * 0.5f),
        style = Stroke(width = w * 0.04f),
      )
      drawCircle(
        color = JuiCyanAccent.copy(alpha = 0.85f),
        radius = w * 0.055f,
        center = Offset(w * 0.82f, h * 0.26f),
      )
      drawCircle(
        color = Color.White.copy(alpha = 0.85f),
        radius = w * 0.05f,
        center = Offset(w * 0.18f, h * 0.74f),
      )
      // Play triangle backdrop
      val playPath = Path().apply {
        moveTo(w * 0.34f, h * 0.22f)
        lineTo(w * 0.78f, h * 0.50f)
        lineTo(w * 0.34f, h * 0.78f)
        close()
      }
      drawPath(
        path = playPath,
        color = Color.White.copy(alpha = 0.22f),
      )
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Text(
        text = "JUI",
        color = Color.White,
        fontWeight = FontWeight.ExtraBold,
        fontSize = (size.value * 0.32f).sp,
        letterSpacing = 1.sp,
      )
    }
  }
}

@Composable
fun JuiWordmarkHeader(
  subtitle: String? = null,
  modifier: Modifier = Modifier,
) {
  Row(
    modifier = modifier,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    JuiLogoBadge(size = 42.dp)
    Spacer(modifier = Modifier.width(12.dp))
    Column {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
          text = "JUI Social Madia",
          style = MaterialTheme.typography.titleLarge,
          color = Color.White,
          fontWeight = FontWeight.Bold,
          modifier = Modifier.testTag("jui_wordmark_title"),
        )
        Spacer(modifier = Modifier.width(6.dp))
        Icon(
          imageVector = Icons.Default.Verified,
          contentDescription = "Official JUI Social Madia Brand",
          tint = JuiCyanAccent,
          modifier = Modifier.size(18.dp),
        )
      }
      if (!subtitle.isNullOrBlank()) {
        Text(
          text = subtitle,
          style = MaterialTheme.typography.labelMedium,
          color = JuiTextSecondary,
        )
      }
    }
  }
}

@Composable
fun JuiSplashScreen(
  onContinue: () -> Unit,
) {
  val infiniteTransition = rememberInfiniteTransition(label = "splash_pulse")
  val pulseScale by infiniteTransition.animateFloat(
    initialValue = 0.96f,
    targetValue = 1.04f,
    animationSpec = infiniteRepeatable(
      animation = tween(1200, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse,
    ),
    label = "pulse",
  )

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(JuiMidnight)
      .testTag("splash_screen"),
  ) {
    Image(
      painter = painterResource(id = R.drawable.img_jui_hero_banner_1792917020662),
      contentDescription = "JUI Social Madia Hero Art",
      contentScale = ContentScale.Crop,
      alpha = 0.35f,
      modifier = Modifier.fillMaxSize(),
    )
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(32.dp),
      verticalArrangement = Arrangement.Center,
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Surface(
        shape = RoundedCornerShape(28.dp),
        color = JuiCardSurface.copy(alpha = 0.85f),
        modifier = Modifier
          .size((116 * pulseScale).dp)
          .border(2.dp, JuiBrandGradient, RoundedCornerShape(28.dp)),
      ) {
        Image(
          painter = painterResource(id = R.drawable.img_jui_app_icon_1792917020697),
          contentDescription = "JUI Social Madia Logo",
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize(),
        )
      }
      Spacer(modifier = Modifier.height(24.dp))
      Text(
        text = "JUI Social Madia",
        style = MaterialTheme.typography.displayLarge,
        color = Color.White,
        fontWeight = FontWeight.Bold,
      )
      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = "Short Videos • Moderated Community • Protected Governance",
        style = MaterialTheme.typography.bodyMedium,
        color = JuiTextSecondary,
      )
      Spacer(modifier = Modifier.height(36.dp))
      Button(
        onClick = onContinue,
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = JuiElectricBlue),
        modifier = Modifier
          .fillMaxWidth(0.75f)
          .height(52.dp)
          .testTag("splash_continue_button"),
      ) {
        Icon(Icons.Default.PlayArrow, contentDescription = null)
        Spacer(modifier = Modifier.width(8.dp))
        Text("Enter JUI Social Madia", fontWeight = FontWeight.Bold)
      }
    }
  }
}

@Composable
fun ReauthConfirmationDialog(
  actionTitle: String,
  onConfirm: () -> Unit,
  onDismiss: () -> Unit,
) {
  var confirmationCode by remember { mutableStateOf("") }
  val isReady = confirmationCode.trim().equals("CONFIRM", ignoreCase = true)

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = JuiCardSurface,
    icon = {
      Icon(
        imageVector = Icons.Default.Security,
        contentDescription = "Security Re-Authentication",
        tint = JuiCyanAccent,
        modifier = Modifier.size(32.dp),
      )
    },
    title = {
      Text(
        text = "Sensitive Action Verification",
        style = MaterialTheme.typography.titleLarge,
        color = Color.White,
      )
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          text = "You are performing a privileged action on JUI Social Madia:\n\"$actionTitle\"",
          style = MaterialTheme.typography.bodyMedium,
          color = JuiTextSecondary,
        )
        Text(
          text = "Confirm your active authenticated session by typing CONFIRM below. This action will be recorded in the append-only Administrative Audit Log.",
          style = MaterialTheme.typography.bodyMedium,
          color = Color.White,
        )
        OutlinedTextField(
          value = confirmationCode,
          onValueChange = { confirmationCode = it },
          label = { Text("Type CONFIRM to verify session") },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("reauth_confirm_input"),
        )
      }
    },
    confirmButton = {
      Button(
        onClick = onConfirm,
        enabled = isReady,
        colors = ButtonDefaults.buttonColors(containerColor = JuiElectricBlue),
        modifier = Modifier.testTag("reauth_confirm_button"),
      ) {
        Text("Verify & Execute")
      }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss) {
        Text("Cancel")
      }
    },
  )
}
