package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val JuiDarkColorScheme = darkColorScheme(
  primary = JuiBrightBlue,
  onPrimary = Color.White,
  primaryContainer = JuiElectricBlue,
  onPrimaryContainer = Color.White,
  secondary = JuiNeonPurple,
  onSecondary = Color.White,
  secondaryContainer = JuiVioletPurple,
  onSecondaryContainer = Color.White,
  tertiary = JuiCyanAccent,
  onTertiary = JuiMidnight,
  background = JuiMidnight,
  onBackground = JuiTextPrimary,
  surface = JuiDeepSurface,
  onSurface = JuiTextPrimary,
  surfaceVariant = JuiCardSurface,
  onSurfaceVariant = JuiTextSecondary,
  error = JuiDangerRed,
  onError = Color.White,
)

@Composable
fun JuiSocialMadiaTheme(
  content: @Composable () -> Unit
) {
  MaterialTheme(
    colorScheme = JuiDarkColorScheme,
    typography = Typography,
    content = content,
  )
}
