package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Comment
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.FollowRecord
import com.example.data.model.ShortVideo
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.data.model.VideoComment
import com.example.ui.components.JuiBrandGradient
import com.example.ui.components.JuiWordmarkHeader
import com.example.ui.theme.JuiCardSurface
import com.example.ui.theme.JuiCyanAccent
import com.example.ui.theme.JuiDangerRed
import com.example.ui.theme.JuiDeepSurface
import com.example.ui.theme.JuiElectricBlue
import com.example.ui.theme.JuiMidnight
import com.example.ui.theme.JuiNeonPurple
import com.example.ui.theme.JuiSuccessGreen
import com.example.ui.theme.JuiTextSecondary
import com.example.ui.theme.JuiVioletPurple
import com.example.ui.theme.JuiWarningAmber
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ShortVideoFeedScreen(
  feedState: UiState<List<ShortVideo>>,
  currentUserProfile: UserProfile?,
  likedVideoIds: Set<String>,
  savedVideoIds: Set<String>,
  followingList: List<FollowRecord>,
  allProfiles: List<UserProfile>,
  activeVideoForComments: ShortVideo?,
  activeComments: List<VideoComment>,
  canModerateComments: Boolean,
  onToggleLike: (ShortVideo) -> Unit,
  onToggleSave: (ShortVideo) -> Unit,
  onShareVideo: (ShortVideo) -> Unit,
  onRecordView: (ShortVideo) -> Unit,
  onToggleFollow: (targetUid: String, targetUsername: String) -> Unit,
  onOpenComments: (ShortVideo?) -> Unit,
  onPostComment: (ShortVideo, String, String) -> Unit,
  onModeratorRemoveComment: (String) -> Unit,
  onReportTarget: (targetId: String, targetType: String, reason: String) -> Unit,
  onNavigateToUpload: () -> Unit,
) {
  var showSearchMode by remember { mutableStateOf(false) }
  var searchQuery by remember { mutableStateOf("") }
  var selectedHashtag by remember { mutableStateOf<String?>(null) }
  var isMuted by remember { mutableStateOf(false) }
  var isPaused by remember { mutableStateOf(false) }
  var reportTargetVideo by remember { mutableStateOf<ShortVideo?>(null) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(JuiMidnight)
      .testTag("home_feed_screen"),
  ) {
    // Top Brand + Search Switch Bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 10.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      JuiWordmarkHeader(subtitle = "Verified Short-Video Feed")
      Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        FilterChip(
          selected = !showSearchMode,
          onClick = { showSearchMode = false },
          label = { Text("For You") },
          modifier = Modifier.testTag("feed_tab_for_you"),
        )
        FilterChip(
          selected = showSearchMode,
          onClick = { showSearchMode = true },
          label = { Text("Search") },
          leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp)) },
          modifier = Modifier.testTag("feed_tab_search"),
        )
      }
    }

    if (showSearchMode) {
      SearchAndHashtagPane(
        feedState = feedState,
        allProfiles = allProfiles,
        searchQuery = searchQuery,
        onSearchQueryChange = { searchQuery = it },
        selectedHashtag = selectedHashtag,
        onSelectHashtag = { selectedHashtag = if (selectedHashtag == it) null else it },
        onSelectVideo = {
          showSearchMode = false
        },
        onToggleFollow = onToggleFollow,
        followingList = followingList,
        currentUserId = currentUserProfile?.userId ?: "",
      )
    } else {
      when (feedState) {
        is UiState.Loading -> {
          Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = JuiCyanAccent)
          }
        }
        is UiState.Error -> {
          Box(
            modifier = Modifier
              .fillMaxSize()
              .padding(24.dp),
            contentAlignment = Alignment.Center,
          ) {
            Card(colors = CardDefaults.cardColors(containerColor = JuiCardSurface)) {
              Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
              ) {
                Icon(Icons.Default.Warning, contentDescription = null, tint = JuiWarningAmber, modifier = Modifier.size(36.dp))
                Text("Could not load video feed", style = MaterialTheme.typography.titleLarge, color = Color.White)
                Text(feedState.message, style = MaterialTheme.typography.bodyMedium, color = JuiTextSecondary)
              }
            }
          }
        }
        is UiState.Success -> {
          val videos = feedState.data
          if (videos.isEmpty()) {
            Box(
              modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
              contentAlignment = Alignment.Center,
            ) {
              Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = JuiDeepSurface),
                modifier = Modifier
                  .fillMaxWidth()
                  .border(1.dp, JuiBrandGradient, RoundedCornerShape(24.dp)),
              ) {
                Column(
                  modifier = Modifier.padding(28.dp),
                  horizontalAlignment = Alignment.CenterHorizontally,
                  verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                  Icon(
                    imageVector = Icons.Default.Videocam,
                    contentDescription = null,
                    tint = JuiCyanAccent,
                    modifier = Modifier.size(48.dp),
                  )
                  Text(
                    text = "No Approved Public Videos Yet",
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White,
                  )
                  Text(
                    text = "Every video uploaded to JUI Social Madia starts with status PENDING and remains private until approved by an authorized moderator or the Permanent Super Owner.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = JuiTextSecondary,
                  )
                  Button(
                    onClick = onNavigateToUpload,
                    colors = ButtonDefaults.buttonColors(containerColor = JuiElectricBlue),
                    modifier = Modifier.testTag("empty_feed_upload_button"),
                  ) {
                    Icon(Icons.Default.AddCircle, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Upload Your First Short Video")
                  }
                }
              }
            }
          } else {
            val pagerState = rememberPagerState(pageCount = { videos.size })
            VerticalPager(
              state = pagerState,
              modifier = Modifier
                .fillMaxSize()
                .testTag("short_video_vertical_pager"),
            ) { page ->
              val video = videos[page]
              LaunchedEffect(video.id) {
                onRecordView(video)
              }
              ShortVideoPlayerCard(
                video = video,
                isLiked = likedVideoIds.contains(video.id),
                isSaved = savedVideoIds.contains(video.id),
                isFollowingCreator = followingList.any { it.followedUid == video.authorUid },
                isOwnVideo = video.authorUid == currentUserProfile?.userId,
                isMuted = isMuted,
                isPaused = isPaused,
                onToggleMute = { isMuted = !isMuted },
                onTogglePause = { isPaused = !isPaused },
                onToggleLike = { onToggleLike(video) },
                onToggleSave = { onToggleSave(video) },
                onShare = { onShareVideo(video) },
                onOpenComments = { onOpenComments(video) },
                onToggleFollow = { onToggleFollow(video.authorUid, video.authorUsername) },
                onReportVideo = { reportTargetVideo = video },
              )
            }
          }
        }
      }
    }
  }

  // Comments & Replies Bottom Sheet
  if (activeVideoForComments != null) {
    var commentText by remember { mutableStateOf("") }
    var replyToComment by remember { mutableStateOf<VideoComment?>(null) }

    ModalBottomSheet(
      onDismissRequest = { onOpenComments(null) },
      containerColor = JuiDeepSurface,
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Text(
          text = "Comments (${activeComments.size})",
          style = MaterialTheme.typography.titleLarge,
          color = Color.White,
        )
        LazyColumn(
          modifier = Modifier
            .fillMaxWidth()
            .height(260.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          if (activeComments.isEmpty()) {
            item {
              Text(
                text = "No comments yet. Start the conversation!",
                style = MaterialTheme.typography.bodyMedium,
                color = JuiTextSecondary,
              )
            }
          } else {
            items(activeComments, key = { it.id }) { comment ->
              Card(
                colors = CardDefaults.cardColors(containerColor = JuiCardSurface),
                modifier = Modifier.fillMaxWidth(),
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                      Text(
                        text = "@${comment.authorUsername}",
                        style = MaterialTheme.typography.labelLarge,
                        color = JuiCyanAccent,
                      )
                      if (comment.parentCommentId.isNotBlank()) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                          text = "• Reply",
                          style = MaterialTheme.typography.labelMedium,
                          color = JuiTextSecondary,
                        )
                      }
                    }
                    Text(
                      text = comment.text,
                      style = MaterialTheme.typography.bodyMedium,
                      color = Color.White,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                      TextButton(
                        onClick = { replyToComment = comment },
                        contentPadding = PaddingValues(0.dp),
                      ) {
                        Text("Reply", style = MaterialTheme.typography.labelMedium)
                      }
                      TextButton(
                        onClick = {
                          onReportTarget(comment.id, "COMMENT", "Inappropriate comment")
                        },
                        contentPadding = PaddingValues(0.dp),
                      ) {
                        Text("Report", style = MaterialTheme.typography.labelMedium, color = JuiWarningAmber)
                      }
                    }
                  }
                  if (canModerateComments) {
                    IconButton(onClick = { onModeratorRemoveComment(comment.id) }) {
                      Icon(Icons.Default.Delete, contentDescription = "Moderator Remove Comment", tint = JuiDangerRed)
                    }
                  }
                }
              }
            }
          }
        }

        if (replyToComment != null) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = "Replying to @${replyToComment?.authorUsername}",
              style = MaterialTheme.typography.labelMedium,
              color = JuiCyanAccent,
            )
            TextButton(onClick = { replyToComment = null }) {
              Text("Cancel")
            }
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          OutlinedTextField(
            value = commentText,
            onValueChange = { commentText = it },
            placeholder = { Text("Add a respectful comment...") },
            singleLine = true,
            modifier = Modifier
              .weight(1f)
              .testTag("comment_input_field"),
          )
          IconButton(
            onClick = {
              if (commentText.isNotBlank()) {
                onPostComment(
                  activeVideoForComments,
                  commentText,
                  replyToComment?.id ?: ""
                )
                commentText = ""
                replyToComment = null
              }
            },
            modifier = Modifier.testTag("send_comment_button"),
          ) {
            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send Comment", tint = JuiCyanAccent)
          }
        }
        Spacer(modifier = Modifier.height(16.dp))
      }
    }
  }

  if (reportTargetVideo != null) {
    var reportReason by remember { mutableStateOf("Spam or misleading content") }
    AlertDialog(
      onDismissRequest = { reportTargetVideo = null },
      containerColor = JuiCardSurface,
      title = { Text("Report Video", color = Color.White) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text("Why are you reporting this video by @${reportTargetVideo?.authorUsername}?", color = JuiTextSecondary)
          OutlinedTextField(
            value = reportReason,
            onValueChange = { reportReason = it },
            label = { Text("Reason") },
            modifier = Modifier.fillMaxWidth(),
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            reportTargetVideo?.let { onReportTarget(it.id, "VIDEO", reportReason) }
            reportTargetVideo = null
          }
        ) {
          Text("Submit Report")
        }
      },
      dismissButton = {
        TextButton(onClick = { reportTargetVideo = null }) {
          Text("Cancel")
        }
      },
    )
  }
}

@Composable
private fun ShortVideoPlayerCard(
  video: ShortVideo,
  isLiked: Boolean,
  isSaved: Boolean,
  isFollowingCreator: Boolean,
  isOwnVideo: Boolean,
  isMuted: Boolean,
  isPaused: Boolean,
  onToggleMute: () -> Unit,
  onTogglePause: () -> Unit,
  onToggleLike: () -> Unit,
  onToggleSave: () -> Unit,
  onShare: () -> Unit,
  onOpenComments: () -> Unit,
  onToggleFollow: () -> Unit,
  onReportVideo: () -> Unit,
) {
  val infiniteTransition = rememberInfiniteTransition(label = "video_wave")
  val wavePhase by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 4000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart,
    ),
    label = "phase",
  )

  Box(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 12.dp, vertical = 6.dp)
      .clip(RoundedCornerShape(28.dp))
      .background(JuiDeepSurface)
      .border(1.dp, JuiBrandGradient, RoundedCornerShape(28.dp))
      .clickable { onTogglePause() },
  ) {
    // Dynamic Animated Short-Video Visual Stage
    Canvas(modifier = Modifier.fillMaxSize()) {
      val w = size.width
      val h = size.height
      drawRect(
        brush = Brush.verticalGradient(
          colors = listOf(JuiMidnight, JuiElectricBlue.copy(alpha = 0.35f), JuiVioletPurple.copy(alpha = 0.45f), JuiMidnight)
        )
      )
      val animOffset = if (isPaused) 0.5f else wavePhase
      drawCircle(
        brush = Brush.radialGradient(
          colors = listOf(JuiCyanAccent.copy(alpha = 0.28f), Color.Transparent),
          center = Offset(w * (0.25f + 0.5f * animOffset), h * 0.38f),
          radius = w * 0.55f,
        )
      )
      drawCircle(
        brush = Brush.radialGradient(
          colors = listOf(JuiNeonPurple.copy(alpha = 0.26f), Color.Transparent),
          center = Offset(w * (0.75f - 0.4f * animOffset), h * 0.62f),
          radius = w * 0.5f,
        )
      )
    }

    // Top Playback Status & Audio Attribution Pill
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Surface(
        color = JuiMidnight.copy(alpha = 0.72f),
        shape = RoundedCornerShape(50),
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            tint = JuiSuccessGreen,
            modifier = Modifier.size(16.dp),
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "APPROVED • ${video.durationSeconds}s • ${video.viewsCount} views",
            style = MaterialTheme.typography.labelMedium,
            color = Color.White,
          )
        }
      }

      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        IconButton(
          onClick = onTogglePause,
          modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(JuiMidnight.copy(alpha = 0.65f))
            .testTag("video_play_pause_button"),
        ) {
          Icon(
            imageVector = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
            contentDescription = if (isPaused) "Resume Video" else "Pause Video",
            tint = Color.White,
          )
        }
        IconButton(
          onClick = onToggleMute,
          modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(JuiMidnight.copy(alpha = 0.65f))
            .testTag("video_mute_button"),
        ) {
          Icon(
            imageVector = if (isMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
            contentDescription = if (isMuted) "Unmute Audio" else "Mute Audio",
            tint = Color.White,
          )
        }
      }
    }

    // Right-Side Engagement Action Rail
    Column(
      modifier = Modifier
        .align(Alignment.BottomEnd)
        .padding(end = 14.dp, bottom = 24.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      EngagementRailButton(
        icon = if (isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
        tint = if (isLiked) JuiDangerRed else Color.White,
        label = "${video.likesCount}",
        contentDesc = "Like Video",
        testTag = "like_video_button",
        onClick = onToggleLike,
      )
      EngagementRailButton(
        icon = Icons.AutoMirrored.Filled.Comment,
        tint = Color.White,
        label = "${video.commentsCount}",
        contentDesc = "Open Comments",
        testTag = "comment_video_button",
        onClick = onOpenComments,
      )
      EngagementRailButton(
        icon = if (isSaved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
        tint = if (isSaved) JuiCyanAccent else Color.White,
        label = "${video.savesCount}",
        contentDesc = "Save Video",
        testTag = "save_video_button",
        onClick = onToggleSave,
      )
      EngagementRailButton(
        icon = Icons.Default.Share,
        tint = Color.White,
        label = "${video.sharesCount}",
        contentDesc = "Share Video",
        testTag = "share_video_button",
        onClick = onShare,
      )
      IconButton(
        onClick = onReportVideo,
        modifier = Modifier
          .size(48.dp)
          .clip(CircleShape)
          .background(JuiMidnight.copy(alpha = 0.6f))
          .testTag("report_video_button"),
      ) {
        Icon(Icons.Default.Flag, contentDescription = "Report Video", tint = JuiWarningAmber)
      }
    }

    // Bottom Creator Caption, Hashtags & Licensed Audio Bar
    Column(
      modifier = Modifier
        .align(Alignment.BottomStart)
        .fillMaxWidth(0.78f)
        .padding(start = 18.dp, bottom = 22.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Text(
          text = "@${video.authorUsername}",
          style = MaterialTheme.typography.titleLarge,
          color = Color.White,
          fontWeight = FontWeight.Bold,
        )
        if (!isOwnVideo) {
          OutlinedButton(
            onClick = onToggleFollow,
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
            modifier = Modifier
              .height(34.dp)
              .testTag("follow_creator_button"),
          ) {
            Text(
              text = if (isFollowingCreator) "Following" else "Follow",
              style = MaterialTheme.typography.labelMedium,
              color = JuiCyanAccent,
            )
          }
        }
      }

      Text(
        text = video.caption,
        style = MaterialTheme.typography.bodyLarge,
        color = Color.White,
        maxLines = 3,
        overflow = TextOverflow.Ellipsis,
      )

      if (video.hashtags.isNotBlank()) {
        Text(
          text = video.hashtags,
          style = MaterialTheme.typography.labelLarge,
          color = JuiCyanAccent,
        )
      }

      Surface(
        color = JuiMidnight.copy(alpha = 0.7f),
        shape = RoundedCornerShape(10.dp),
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Icon(
            imageVector = Icons.Default.MusicNote,
            contentDescription = null,
            tint = JuiCyanAccent,
            modifier = Modifier.size(16.dp),
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "${video.audioTitle} • ${video.audioLicense}",
            style = MaterialTheme.typography.labelMedium,
            color = JuiTextSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }
    }
  }
}

@Composable
private fun EngagementRailButton(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  tint: Color,
  label: String,
  contentDesc: String,
  testTag: String,
  onClick: () -> Unit,
) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    IconButton(
      onClick = onClick,
      modifier = Modifier
        .size(48.dp)
        .clip(CircleShape)
        .background(JuiMidnight.copy(alpha = 0.65f))
        .testTag(testTag),
    ) {
      Icon(icon, contentDescription = contentDesc, tint = tint)
    }
    Text(
      text = label,
      style = MaterialTheme.typography.labelMedium,
      color = Color.White,
    )
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SearchAndHashtagPane(
  feedState: UiState<List<ShortVideo>>,
  allProfiles: List<UserProfile>,
  searchQuery: String,
  onSearchQueryChange: (String) -> Unit,
  selectedHashtag: String?,
  onSelectHashtag: (String) -> Unit,
  onSelectVideo: (ShortVideo) -> Unit,
  onToggleFollow: (String, String) -> Unit,
  followingList: List<FollowRecord>,
  currentUserId: String,
) {
  val videos = (feedState as? UiState.Success)?.data ?: emptyList()
  val popularHashtags = listOf("#jui", "#shortvideo", "#creators", "#community", "#tech")

  val filteredVideos = videos.filter { v ->
    val matchesQuery = searchQuery.isBlank() ||
      v.caption.contains(searchQuery, ignoreCase = true) ||
      v.hashtags.contains(searchQuery, ignoreCase = true) ||
      v.authorUsername.contains(searchQuery, ignoreCase = true)
    val matchesTag = selectedHashtag == null || v.hashtags.contains(selectedHashtag, ignoreCase = true)
    matchesQuery && matchesTag
  }

  val filteredUsers = allProfiles.filter { u ->
    searchQuery.isNotBlank() && (
      u.username.contains(searchQuery, ignoreCase = true) ||
        u.displayName.contains(searchQuery, ignoreCase = true)
      )
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    item {
      OutlinedTextField(
        value = searchQuery,
        onValueChange = onSearchQueryChange,
        label = { Text("Search users, approved videos, or #hashtags") },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
        singleLine = true,
        modifier = Modifier
          .fillMaxWidth()
          .testTag("search_query_input"),
      )
    }

    item {
      FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        popularHashtags.forEach { tag ->
          AssistChip(
            onClick = { onSelectHashtag(tag) },
            label = { Text(tag) },
          )
        }
      }
    }

    if (filteredUsers.isNotEmpty()) {
      item {
        Text("Matching Creators (${filteredUsers.size})", style = MaterialTheme.typography.titleMedium, color = Color.White)
      }
      items(filteredUsers, key = { it.userId }) { user ->
        Card(
          colors = CardDefaults.cardColors(containerColor = JuiCardSurface),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column {
              Text(user.displayName, style = MaterialTheme.typography.titleMedium, color = Color.White)
              Text("@${user.username}", style = MaterialTheme.typography.bodyMedium, color = JuiCyanAccent)
            }
            if (user.userId != currentUserId) {
              val isFollowing = followingList.any { it.followedUid == user.userId }
              OutlinedButton(onClick = { onToggleFollow(user.userId, user.username) }) {
                Text(if (isFollowing) "Unfollow" else "Follow")
              }
            }
          }
        }
      }
    }

    item {
      Text(
        text = "Approved Videos (${filteredVideos.size})",
        style = MaterialTheme.typography.titleMedium,
        color = Color.White,
      )
    }

    items(filteredVideos, key = { it.id }) { vid ->
      Card(
        colors = CardDefaults.cardColors(containerColor = JuiCardSurface),
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onSelectVideo(vid) },
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Text("@${vid.authorUsername}", style = MaterialTheme.typography.labelLarge, color = JuiCyanAccent)
          Text(vid.caption, style = MaterialTheme.typography.bodyLarge, color = Color.White)
          Text(vid.hashtags, style = MaterialTheme.typography.labelMedium, color = JuiTextSecondary)
        }
      }
    }
  }
}

@Composable
fun VideoUploadAndPendingStatusScreen(
  currentUserProfile: UserProfile?,
  myUploadedVideos: List<ShortVideo>,
  isBusy: Boolean,
  onUploadVideo: (
    caption: String,
    hashtags: String,
    videoUrl: String,
    audioTitle: String,
    audioLicense: String,
    fileMimeType: String,
    fileSizeBytes: Long,
    durationSeconds: Long,
  ) -> Unit,
  onSubmitAppeal: (videoId: String, details: String) -> Unit,
) {
  var caption by remember { mutableStateOf("") }
  var hashtags by remember { mutableStateOf("#jui #shortvideo") }
  var selectedVideoUri by remember { mutableStateOf<Uri?>(null) }
  var selectedAudioIndex by remember { mutableIntStateOf(0) }
  var durationSeconds by remember { mutableIntStateOf(15) }
  var simulatedUploadProgress by remember { mutableFloatStateOf(0f) }
  var isAnimatingUpload by remember { mutableStateOf(false) }
  val scope = rememberCoroutineScope()

  val licensedAudioTracks = listOf(
    "Original JUI Studio Audio" to "CC-BY 4.0 Royalty-Free",
    "JUI Neon Horizon Synth" to "CC0 Public Domain Dedication",
    "JUI Community Pulse Beat" to "JUI Creator Commercial License",
  )

  val videoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri ->
    selectedVideoUri = uri
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(JuiMidnight)
      .padding(16.dp)
      .testTag("upload_and_status_screen"),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    item {
      JuiWordmarkHeader(subtitle = "Studio Upload & Moderation Status Tracker")
    }

    item {
      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = JuiDeepSurface),
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, JuiBrandGradient, RoundedCornerShape(20.dp)),
      ) {
        Column(
          modifier = Modifier.padding(20.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          Text(
            text = "Upload New Short Video (Starts as PENDING)",
            style = MaterialTheme.typography.titleLarge,
            color = Color.White,
          )
          Text(
            text = "Mandatory Moderation Policy: Every uploaded video starts with status PENDING and remains strictly private until approved by an authorized moderator.",
            style = MaterialTheme.typography.bodyMedium,
            color = JuiTextSecondary,
          )

          Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(
              onClick = {
                videoPickerLauncher.launch(
                  PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                )
              },
              modifier = Modifier
                .weight(1f)
                .testTag("pick_gallery_video_button"),
            ) {
              Icon(Icons.Default.VideoFile, contentDescription = null)
              Spacer(modifier = Modifier.width(6.dp))
              Text(if (selectedVideoUri != null) "Video Selected" else "Pick Gallery Video")
            }
          }

          OutlinedTextField(
            value = caption,
            onValueChange = { caption = it },
            label = { Text("Video Caption (required)") },
            modifier = Modifier
              .fillMaxWidth()
              .testTag("upload_caption_input"),
          )

          OutlinedTextField(
            value = hashtags,
            onValueChange = { hashtags = it },
            label = { Text("Hashtags (e.g. #jui #shortvideo)") },
            modifier = Modifier
              .fillMaxWidth()
              .testTag("upload_hashtags_input"),
          )

          Text(
            text = "Legally Permitted Audio & Licensing Attribution:",
            style = MaterialTheme.typography.labelLarge,
            color = Color.White,
          )
          licensedAudioTracks.forEachIndexed { index, pair ->
            FilterChip(
              selected = selectedAudioIndex == index,
              onClick = { selectedAudioIndex = index },
              label = { Text("${pair.first} (${pair.second})") },
            )
          }

          if (isAnimatingUpload || isBusy) {
            LinearProgressIndicator(
              progress = { if (isAnimatingUpload) simulatedUploadProgress else 0.8f },
              color = JuiCyanAccent,
              modifier = Modifier.fillMaxWidth(),
            )
          }

          Button(
            onClick = {
              if (caption.isNotBlank()) {
                scope.launch {
                  isAnimatingUpload = true
                  simulatedUploadProgress = 0.25f
                  delay(120)
                  simulatedUploadProgress = 0.75f
                  delay(120)
                  simulatedUploadProgress = 1.0f
                  isAnimatingUpload = false
                  val audio = licensedAudioTracks[selectedAudioIndex]
                  onUploadVideo(
                    caption,
                    hashtags,
                    selectedVideoUri?.toString() ?: "jui://studio/clip_${System.currentTimeMillis()}.mp4",
                    audio.first,
                    audio.second,
                    "video/mp4",
                    4_800_000L,
                    durationSeconds.toLong(),
                  )
                  caption = ""
                }
              }
            },
            enabled = caption.isNotBlank() && !isBusy && !isAnimatingUpload,
            colors = ButtonDefaults.buttonColors(containerColor = JuiElectricBlue),
            modifier = Modifier
              .fillMaxWidth()
              .height(52.dp)
              .testTag("submit_video_upload_button"),
          ) {
            Icon(Icons.Default.Videocam, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Submit Video for Moderation (PENDING)", fontWeight = FontWeight.Bold)
          }
        }
      }
    }

    item {
      Text(
        text = "My Uploads & Moderation Status (${myUploadedVideos.size})",
        style = MaterialTheme.typography.titleLarge,
        color = Color.White,
      )
    }

    if (myUploadedVideos.isEmpty()) {
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = JuiCardSurface),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Text(
            text = "You have not uploaded any videos yet.",
            style = MaterialTheme.typography.bodyMedium,
            color = JuiTextSecondary,
            modifier = Modifier.padding(16.dp),
          )
        }
      }
    } else {
      items(myUploadedVideos, key = { it.id }) { vid ->
        val badgeColor = when (vid.status) {
          "APPROVED" -> JuiSuccessGreen
          "REJECTED" -> JuiDangerRed
          else -> JuiWarningAmber
        }
        Card(
          colors = CardDefaults.cardColors(containerColor = JuiCardSurface),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text = vid.caption,
                style = MaterialTheme.typography.titleMedium,
                color = Color.White,
                modifier = Modifier.weight(1f),
              )
              Surface(
                color = badgeColor.copy(alpha = 0.2f),
                shape = RoundedCornerShape(50),
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Icon(
                    imageVector = Icons.Default.HourglassTop,
                    contentDescription = null,
                    tint = badgeColor,
                    modifier = Modifier.size(14.dp),
                  )
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(
                    text = vid.status,
                    style = MaterialTheme.typography.labelMedium,
                    color = badgeColor,
                    fontWeight = FontWeight.Bold,
                  )
                }
              }
            }
            Text(
              text = "${vid.hashtags} • ${vid.audioTitle} (${vid.audioLicense})",
              style = MaterialTheme.typography.bodyMedium,
              color = JuiTextSecondary,
            )
            if (vid.status == "REJECTED") {
              Text(
                text = "Rejection Reason: ${vid.rejectionReason}",
                style = MaterialTheme.typography.bodyMedium,
                color = JuiDangerRed,
              )
              OutlinedButton(
                onClick = {
                  onSubmitAppeal(vid.id, "Requesting moderation appeal for rejected video '${vid.caption}'")
                }
              ) {
                Text("Submit Moderation Appeal")
              }
            }
          }
        }
      }
    }
  }
}
