package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class SuperOwnerConfig(
  @DocumentId val id: String = "",
  val ownerUid: String = "",
  val ownerName: String = "",
  val platformStatus: String = "ONLINE",
  val allowPublicRegistration: Boolean = true,
  val requireModerationForAllVideos: Boolean = true,
  val reauthVerified: Boolean = true,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class AdminRole(
  @DocumentId val id: String = "",
  val adminUid: String = "",
  val adminName: String = "",
  val assignedByUid: String = "",
  val canApproveVideos: Boolean = false,
  val canModerateComments: Boolean = false,
  val canManageReports: Boolean = false,
  val canManageGroups: Boolean = false,
  val canManageAppeals: Boolean = false,
  val reauthVerified: Boolean = true,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class AuditLog(
  @DocumentId val id: String = "",
  val actorUid: String = "",
  val actorName: String = "",
  val action: String = "",
  val targetId: String = "",
  val targetType: String = "",
  val result: String = "SUCCESS",
  val details: String = "",
  val reauthVerified: Boolean = true,
  @ServerTimestamp val createdAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class UserProfile(
  @DocumentId val id: String = "",
  val userId: String = "",
  val username: String = "",
  val displayName: String = "",
  val bio: String = "",
  val avatarUrl: String = "",
  val isPrivate: Boolean = false,
  val ageVerified: Boolean = true,
  val accountStatus: String = "ACTIVE",
  val followersCount: Long = 0L,
  val followingCount: Long = 0L,
  val uploadedVideosCount: Long = 0L,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class UsernameRecord(
  @DocumentId val id: String = "",
  val username: String = "",
  val userId: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class FollowRecord(
  @DocumentId val id: String = "",
  val followerUid: String = "",
  val followerUsername: String = "",
  val followedUid: String = "",
  val followedUsername: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class BlockRecord(
  @DocumentId val id: String = "",
  val blockerUid: String = "",
  val blockedUid: String = "",
  val blockedUsername: String = "",
  val reason: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class ShortVideo(
  @DocumentId val id: String = "",
  val authorUid: String = "",
  val authorUsername: String = "",
  val authorDisplayName: String = "",
  val caption: String = "",
  val hashtags: String = "",
  val videoUrl: String = "",
  val thumbnailUrl: String = "",
  val audioTitle: String = "Original JUI Studio Audio",
  val audioLicense: String = "CC-BY 4.0 Royalty-Free",
  val fileMimeType: String = "video/mp4",
  val fileSizeBytes: Long = 4_200_000L,
  val durationSeconds: Long = 15L,
  val status: String = "PENDING",
  val rejectionReason: String = "",
  val moderatedByUid: String = "",
  val likesCount: Long = 0L,
  val commentsCount: Long = 0L,
  val sharesCount: Long = 0L,
  val viewsCount: Long = 0L,
  val savesCount: Long = 0L,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class VideoComment(
  @DocumentId val id: String = "",
  val videoId: String = "",
  val authorUid: String = "",
  val authorUsername: String = "",
  val text: String = "",
  val parentCommentId: String = "",
  val status: String = "ACTIVE",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class VideoInteraction(
  @DocumentId val id: String = "",
  val videoId: String = "",
  val userId: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class Conversation(
  @DocumentId val id: String = "",
  val participantUids: List<String> = emptyList(),
  val participantNames: String = "",
  val lastMessageText: String = "",
  val retentionDays: Long = 90L,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class PrivateMessage(
  @DocumentId val id: String = "",
  val conversationId: String = "",
  val senderUid: String = "",
  val senderName: String = "",
  val recipientUid: String = "",
  val participantUids: List<String> = emptyList(),
  val text: String = "",
  val isRead: Boolean = false,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class AppNotification(
  @DocumentId val id: String = "",
  val recipientUid: String = "",
  val actorUid: String = "",
  val actorName: String = "",
  val type: String = "VIDEO_DECISION",
  val title: String = "",
  val body: String = "",
  val targetId: String = "",
  val isRead: Boolean = false,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class CommunityGroup(
  @DocumentId val id: String = "",
  val name: String = "",
  val description: String = "",
  val creatorUid: String = "",
  val creatorName: String = "",
  val requirePostApproval: Boolean = true,
  val isPublic: Boolean = true,
  val membersCount: Long = 1L,
  val moderatorUids: List<String> = emptyList(),
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class GroupMember(
  @DocumentId val id: String = "",
  val groupId: String = "",
  val userId: String = "",
  val username: String = "",
  val role: String = "MEMBER",
  val status: String = "PENDING",
  val moderatorUids: List<String> = emptyList(),
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class GroupPost(
  @DocumentId val id: String = "",
  val groupId: String = "",
  val authorUid: String = "",
  val authorName: String = "",
  val contentType: String = "TEXT",
  val text: String = "",
  val mediaUrl: String = "",
  val status: String = "PENDING",
  val moderatedByUid: String = "",
  val moderatorUids: List<String> = emptyList(),
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class ModerationReport(
  @DocumentId val id: String = "",
  val reporterUid: String = "",
  val reporterName: String = "",
  val targetId: String = "",
  val targetType: String = "VIDEO",
  val reason: String = "",
  val details: String = "",
  val status: String = "OPEN",
  val resolutionNote: String = "",
  val resolvedByUid: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

sealed interface UiState<out T> {
  data object Loading : UiState<Nothing>
  data class Success<T>(val data: T) : UiState<T>
  data class Error(val message: String) : UiState<Nothing>
}
