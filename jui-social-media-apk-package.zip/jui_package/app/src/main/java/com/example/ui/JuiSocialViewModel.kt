package com.example.ui

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AdminRole
import com.example.data.model.AppNotification
import com.example.data.model.AuditLog
import com.example.data.model.BlockRecord
import com.example.data.model.CommunityGroup
import com.example.data.model.Conversation
import com.example.data.model.FollowRecord
import com.example.data.model.GroupMember
import com.example.data.model.GroupPost
import com.example.data.model.ModerationReport
import com.example.data.model.PrivateMessage
import com.example.data.model.ShortVideo
import com.example.data.model.SuperOwnerConfig
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.data.model.VideoComment
import com.example.data.repository.JuiSocialRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class JuiSocialViewModel(
  private val repository: JuiSocialRepository,
  val currentUserId: String,
  val currentUserEmail: String?,
) : ViewModel() {

  private val _statusBanner = MutableStateFlow<String?>(null)
  val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

  private val _isBusy = MutableStateFlow(false)
  val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

  private val _selectedVideoForComments = MutableStateFlow<ShortVideo?>(null)
  val selectedVideoForComments: StateFlow<ShortVideo?> = _selectedVideoForComments.asStateFlow()

  private val _selectedGroup = MutableStateFlow<CommunityGroup?>(null)
  val selectedGroup: StateFlow<CommunityGroup?> = _selectedGroup.asStateFlow()

  fun clearBanner() {
    _statusBanner.value = null
  }

  fun selectVideoForComments(video: ShortVideo?) {
    _selectedVideoForComments.value = video
  }

  fun selectGroup(group: CommunityGroup?) {
    _selectedGroup.value = group
  }

  // 1. Current User Profile
  val currentUserProfile: StateFlow<UiState<UserProfile?>> = repository.observeUserProfile(currentUserId)
    .map<UserProfile?, UiState<UserProfile?>> { UiState.Success(it) }
    .catch { e ->
      Log.w(TAG, "Error observing current user profile", e)
      emit(UiState.Error(e.message ?: "Failed to load profile"))
    }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

  // 2. Super Owner & Current Admin Role
  val superOwnerConfig: StateFlow<SuperOwnerConfig?> = repository.observeSuperOwnerConfig()
    .catch { emit(null) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)

  val currentAdminRole: StateFlow<AdminRole?> = repository.observeAdminRole(currentUserId)
    .catch { emit(null) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)

  fun isCurrentUserSuperOwner(config: SuperOwnerConfig?): Boolean {
    return config?.ownerUid == currentUserId ||
      currentUserEmail.equals("waseemullahkhan1389@gmail.com", ignoreCase = true)
  }

  // 3. Public Approved Video Feed & User's Own Uploads
  val approvedFeedState: StateFlow<UiState<List<ShortVideo>>> = repository.observeApprovedFeed()
    .map<List<ShortVideo>, UiState<List<ShortVideo>>> { UiState.Success(it) }
    .catch { e ->
      Log.w(TAG, "Error observing approved video feed", e)
      emit(UiState.Error(e.message ?: "Failed to load short-video feed"))
    }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

  val myUploadedVideos: StateFlow<List<ShortVideo>> = repository.observeUserUploadedVideos(currentUserId)
    .catch { emit(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  val likedVideoIds: StateFlow<Set<String>> = repository.observeLikedVideoIds(currentUserId)
    .catch { emit(emptySet()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptySet())

  val savedVideoIds: StateFlow<Set<String>> = repository.observeSavedVideoIds(currentUserId)
    .catch { emit(emptySet()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptySet())

  val activeVideoComments: StateFlow<List<VideoComment>> = _selectedVideoForComments
    .flatMapLatest { video ->
      if (video == null) flowOf(emptyList())
      else repository.observeCommentsForVideo(video.id).catch { emit(emptyList()) }
    }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  // 4. Users, Follows & Blocks
  val activeProfiles: StateFlow<List<UserProfile>> = repository.observeActiveProfiles()
    .catch { emit(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  val followingList: StateFlow<List<FollowRecord>> = repository.observeFollowing(currentUserId)
    .catch { emit(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  val followersList: StateFlow<List<FollowRecord>> = repository.observeFollowers(currentUserId)
    .catch { emit(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  val blockedUsers: StateFlow<List<BlockRecord>> = repository.observeBlockedUsers(currentUserId)
    .catch { emit(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  // 5. Notifications, Conversations & Private Messages
  val notifications: StateFlow<List<AppNotification>> = repository.observeNotifications(currentUserId)
    .catch { emit(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  val conversations: StateFlow<List<Conversation>> = repository.observeConversations(currentUserId)
    .catch { emit(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  val privateMessages: StateFlow<List<PrivateMessage>> = repository.observeMessages(currentUserId)
    .catch { emit(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  // 6. Groups, Memberships & Posts
  val publicGroups: StateFlow<List<CommunityGroup>> = repository.observePublicGroups()
    .catch { emit(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  val myGroupMemberships: StateFlow<List<GroupMember>> = repository.observeUserGroupMemberships(currentUserId)
    .catch { emit(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  val pendingGroupRequestsForMe: StateFlow<List<GroupMember>> =
    repository.observePendingGroupMembersForModerator(currentUserId)
      .catch { emit(emptyList()) }
      .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  val pendingGroupPostsForMe: StateFlow<List<GroupPost>> =
    repository.observePendingGroupPostsForModerator(currentUserId)
      .catch { emit(emptyList()) }
      .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  val selectedGroupApprovedPosts: StateFlow<List<GroupPost>> = _selectedGroup
    .flatMapLatest { grp ->
      if (grp == null) flowOf(emptyList())
      else repository.observeApprovedGroupPosts(grp.id).catch { emit(emptyList()) }
    }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  val selectedGroupApprovedMembers: StateFlow<List<GroupMember>> = _selectedGroup
    .flatMapLatest { grp ->
      if (grp == null) flowOf(emptyList())
      else repository.observeApprovedGroupMembers(grp.id).catch { emit(emptyList()) }
    }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  // 7. Reports & Moderation Streams
  val myReports: StateFlow<List<ModerationReport>> = repository.observeUserReports(currentUserId)
    .catch { emit(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  private val canModerateVideosFlow = kotlinx.coroutines.flow.combine(superOwnerConfig, currentAdminRole) { owner, role ->
    isCurrentUserSuperOwner(owner) || role?.canApproveVideos == true
  }

  val pendingModerationVideos: StateFlow<List<ShortVideo>> = canModerateVideosFlow
    .flatMapLatest { allowed ->
      if (!allowed) flowOf(emptyList())
      else repository.observePendingVideosForModeration().catch { emit(emptyList()) }
    }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  private val canManageReportsFlow = kotlinx.coroutines.flow.combine(superOwnerConfig, currentAdminRole) { owner, role ->
    isCurrentUserSuperOwner(owner) || role?.canManageReports == true || role?.canManageAppeals == true
  }

  val openAdminReports: StateFlow<List<ModerationReport>> = canManageReportsFlow
    .flatMapLatest { allowed ->
      if (!allowed) flowOf(emptyList())
      else repository.observeOpenReportsForAdmin().catch { emit(emptyList()) }
    }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  private val isSuperOwnerFlow = superOwnerConfig.map { isCurrentUserSuperOwner(it) }

  val allAdminRoles: StateFlow<List<AdminRole>> = isSuperOwnerFlow
    .flatMapLatest { isOwner ->
      if (!isOwner) flowOf(emptyList())
      else repository.observeAllAdminRolesForSuperOwner().catch { emit(emptyList()) }
    }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  val auditLogs: StateFlow<List<AuditLog>> = isSuperOwnerFlow
    .flatMapLatest { isOwner ->
      if (!isOwner) flowOf(emptyList())
      else repository.observeAuditLogsForSuperOwner().catch { emit(emptyList()) }
    }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

  // =========================================================================
  // USER ACTIONS
  // =========================================================================
  fun registerProfile(
    username: String,
    displayName: String,
    bio: String,
    isPrivate: Boolean,
    ageVerified: Boolean,
  ) {
    viewModelScope.launch {
      _isBusy.value = true
      val res = repository.registerUserProfile(username, displayName, bio, isPrivate, ageVerified)
      _isBusy.value = false
      res.onSuccess {
        _statusBanner.value = "Welcome to JUI Social Madia, @${it.username}!"
      }.onFailure { err ->
        _statusBanner.value = "Username registration failed: ${err.localizedMessage ?: "Username may already be taken."}"
      }
    }
  }

  fun updateProfile(displayName: String, bio: String, isPrivate: Boolean) {
    viewModelScope.launch {
      _isBusy.value = true
      val res = repository.updateUserProfile(displayName, bio, isPrivate)
      _isBusy.value = false
      res.onSuccess { _statusBanner.value = "Profile updated." }
        .onFailure { _statusBanner.value = "Update failed: ${it.localizedMessage}" }
    }
  }

  fun deleteOwnAccount(username: String, onDeleted: () -> Unit) {
    viewModelScope.launch {
      _isBusy.value = true
      val res = repository.deleteOwnAccount(username)
      _isBusy.value = false
      res.onSuccess {
        _statusBanner.value = "Account deleted."
        onDeleted()
      }.onFailure {
        _statusBanner.value = "Account deletion denied (Super Owner accounts are permanently protected)."
      }
    }
  }

  fun uploadVideo(
    authorUsername: String,
    authorDisplayName: String,
    caption: String,
    hashtags: String,
    videoUrl: String,
    audioTitle: String,
    audioLicense: String,
    fileMimeType: String,
    fileSizeBytes: Long,
    durationSeconds: Long,
  ) {
    viewModelScope.launch {
      _isBusy.value = true
      val res = repository.uploadShortVideo(
        authorUsername = authorUsername,
        authorDisplayName = authorDisplayName,
        caption = caption,
        hashtags = hashtags,
        videoUrl = videoUrl,
        audioTitle = audioTitle,
        audioLicense = audioLicense,
        fileMimeType = fileMimeType,
        fileSizeBytes = fileSizeBytes,
        durationSeconds = durationSeconds,
      )
      _isBusy.value = false
      res.onSuccess {
        _statusBanner.value = "Video uploaded with status PENDING. It will appear publicly once approved by a moderator."
      }.onFailure {
        _statusBanner.value = "Upload failed: ${it.localizedMessage}"
      }
    }
  }

  fun toggleLike(video: ShortVideo, actorUsername: String) {
    val isLiked = likedVideoIds.value.contains(video.id)
    viewModelScope.launch {
      repository.toggleLikeVideo(video, actorUsername, isLiked)
    }
  }

  fun toggleSave(video: ShortVideo) {
    val isSaved = savedVideoIds.value.contains(video.id)
    viewModelScope.launch {
      repository.toggleSaveVideo(video, isSaved)
        .onSuccess {
          _statusBanner.value = if (isSaved) "Removed from Saved Videos" else "Saved to Favorites"
        }
    }
  }

  fun recordShare(video: ShortVideo) {
    viewModelScope.launch {
      repository.recordVideoShareOrView(video, isShare = true)
    }
  }

  fun recordView(video: ShortVideo) {
    viewModelScope.launch {
      repository.recordVideoShareOrView(video, isShare = false)
    }
  }

  fun postComment(video: ShortVideo, authorUsername: String, text: String, parentCommentId: String = "") {
    if (text.isBlank()) return
    viewModelScope.launch {
      repository.addComment(video, authorUsername, text, parentCommentId)
        .onFailure { _statusBanner.value = "Comment failed: ${it.localizedMessage}" }
    }
  }

  fun removeCommentAsModerator(commentId: String) {
    viewModelScope.launch {
      repository.moderateRemoveComment(commentId)
        .onSuccess { _statusBanner.value = "Comment removed by moderator." }
        .onFailure { _statusBanner.value = "Moderator permission required." }
    }
  }

  fun toggleFollow(followerUsername: String, targetUid: String, targetUsername: String) {
    val isFollowing = followingList.value.any { it.followedUid == targetUid }
    viewModelScope.launch {
      if (isFollowing) {
        repository.unfollowUser(targetUid)
          .onSuccess { _statusBanner.value = "Unfollowed @$targetUsername" }
      } else {
        repository.followUser(followerUsername, targetUid, targetUsername)
          .onSuccess { _statusBanner.value = "Following @$targetUsername" }
          .onFailure { _statusBanner.value = "Cannot follow user (block restriction active)." }
      }
    }
  }

  fun blockUser(targetUid: String, targetUsername: String, reason: String) {
    viewModelScope.launch {
      repository.blockUser(targetUid, targetUsername, reason)
        .onSuccess { _statusBanner.value = "Blocked @$targetUsername" }
        .onFailure { _statusBanner.value = "Block rejected (Super Owner cannot be blocked)." }
    }
  }

  fun unblockUser(targetUid: String) {
    viewModelScope.launch {
      repository.unblockUser(targetUid)
        .onSuccess { _statusBanner.value = "User unblocked." }
    }
  }

  fun sendMessage(
    senderName: String,
    recipientUid: String,
    recipientName: String,
    text: String,
    retentionDays: Long,
  ) {
    if (text.isBlank()) return
    viewModelScope.launch {
      repository.sendPrivateMessage(senderName, recipientUid, recipientName, text, retentionDays)
        .onFailure {
          _statusBanner.value = "Message failed (recipient may have blocked messages)."
        }
    }
  }

  fun markMessageAsRead(messageId: String) {
    viewModelScope.launch {
      repository.markMessageRead(messageId)
    }
  }

  fun markNotificationAsRead(notificationId: String) {
    viewModelScope.launch {
      repository.markNotificationRead(notificationId)
    }
  }

  fun createCommunityGroup(
    name: String,
    description: String,
    creatorName: String,
    requirePostApproval: Boolean,
  ) {
    viewModelScope.launch {
      repository.createGroup(name, description, creatorName, requirePostApproval, isPublic = true)
        .onSuccess { _statusBanner.value = "Created group '$name'." }
        .onFailure { _statusBanner.value = "Failed to create group: ${it.localizedMessage}" }
    }
  }

  fun requestGroupJoin(group: CommunityGroup, username: String) {
    viewModelScope.launch {
      repository.requestGroupMembership(group, username)
        .onSuccess { _statusBanner.value = "Membership request sent to '${group.name}'." }
        .onFailure { _statusBanner.value = "Request failed: ${it.localizedMessage}" }
    }
  }

  fun approveMember(member: GroupMember, role: String = "MEMBER") {
    viewModelScope.launch {
      repository.approveGroupMember(member, role)
        .onSuccess { _statusBanner.value = "Approved @${member.username} as $role." }
        .onFailure { _statusBanner.value = "Approval denied: ${it.localizedMessage}" }
    }
  }

  fun leaveCommunityGroup(groupId: String) {
    viewModelScope.launch {
      repository.leaveGroup(groupId)
        .onSuccess { _statusBanner.value = "Left group." }
        .onFailure { _statusBanner.value = "Group creators cannot leave their own group." }
    }
  }

  fun publishGroupPost(
    group: CommunityGroup,
    authorName: String,
    contentType: String,
    text: String,
    mediaUrl: String,
  ) {
    viewModelScope.launch {
      repository.createGroupPost(group, authorName, contentType, text, mediaUrl)
        .onSuccess {
          _statusBanner.value = if (group.requirePostApproval) {
            "Group post submitted as PENDING for moderator approval."
          } else {
            "Group post published!"
          }
        }
        .onFailure { _statusBanner.value = "Post failed (must be an APPROVED group member)." }
    }
  }

  fun moderateGroupPostDecision(postId: String, approve: Boolean) {
    viewModelScope.launch {
      repository.moderateGroupPost(postId, approve)
        .onSuccess {
          _statusBanner.value = if (approve) "Group post approved!" else "Group post rejected."
        }
        .onFailure { _statusBanner.value = "Moderation failed: ${it.localizedMessage}" }
    }
  }

  fun submitSafetyReport(
    reporterName: String,
    targetId: String,
    targetType: String,
    reason: String,
    details: String,
  ) {
    viewModelScope.launch {
      repository.submitReportOrAppeal(reporterName, targetId, targetType, reason, details)
        .onSuccess { _statusBanner.value = "$targetType report/appeal submitted for moderator review." }
        .onFailure { _statusBanner.value = "Submission denied: ${it.localizedMessage}" }
    }
  }

  // =========================================================================
  // ADMIN & SUPER OWNER GOVERNANCE ACTIONS
  // =========================================================================
  fun moderatePendingVideo(
    video: ShortVideo,
    approve: Boolean,
    rejectionReason: String,
    moderatorName: String,
  ) {
    viewModelScope.launch {
      repository.moderateVideo(video, approve, rejectionReason, moderatorName, reauthVerified = true)
        .onSuccess {
          _statusBanner.value = if (approve) {
            "Approved video '${video.caption.take(30)}'. Now publicly visible!"
          } else {
            "Rejected video with reason notified to uploader."
          }
        }
        .onFailure {
          _statusBanner.value = "Moderation denied by backend security rules: ${it.localizedMessage}"
        }
    }
  }

  fun resolveModerationReport(
    reportId: String,
    status: String,
    resolutionNote: String,
    adminName: String,
  ) {
    viewModelScope.launch {
      repository.resolveReport(reportId, status, resolutionNote, adminName)
        .onSuccess { _statusBanner.value = "Report marked as $status." }
        .onFailure { _statusBanner.value = "Permission denied: ${it.localizedMessage}" }
    }
  }

  fun claimPermanentSuperOwner(ownerName: String) {
    viewModelScope.launch {
      repository.claimInitialSuperOwner(ownerName, reauthVerified = true)
        .onSuccess { _statusBanner.value = "Permanent Super Owner established & logged in Audit Log!" }
        .onFailure { _statusBanner.value = "Super Owner already established and locked on server." }
    }
  }

  fun updatePlatformSettings(
    ownerName: String,
    platformStatus: String,
    allowPublicRegistration: Boolean,
    requireModerationForAllVideos: Boolean,
  ) {
    viewModelScope.launch {
      repository.updateGlobalPlatformSettings(
        ownerName = ownerName,
        platformStatus = platformStatus,
        allowPublicRegistration = allowPublicRegistration,
        requireModerationForAllVideos = requireModerationForAllVideos,
        reauthVerified = true,
      )
        .onSuccess { _statusBanner.value = "Global platform settings updated & audited." }
        .onFailure { _statusBanner.value = "Only the Permanent Super Owner can modify global settings." }
    }
  }

  fun assignAdminPermissions(
    targetAdminUid: String,
    targetAdminName: String,
    canApproveVideos: Boolean,
    canModerateComments: Boolean,
    canManageReports: Boolean,
    canManageGroups: Boolean,
    canManageAppeals: Boolean,
    actorName: String,
  ) {
    viewModelScope.launch {
      repository.assignOrUpdateAdminRole(
        targetAdminUid = targetAdminUid,
        targetAdminName = targetAdminName,
        canApproveVideos = canApproveVideos,
        canModerateComments = canModerateComments,
        canManageReports = canManageReports,
        canManageGroups = canManageGroups,
        canManageAppeals = canManageAppeals,
        actorName = actorName,
        reauthVerified = true,
      )
        .onSuccess { _statusBanner.value = "Updated admin permissions for $targetAdminName." }
        .onFailure { _statusBanner.value = "Backend denied admin role change (Super Owner required)." }
    }
  }

  fun revokeAdminRole(targetAdminUid: String, actorName: String) {
    viewModelScope.launch {
      repository.removeAdminRole(targetAdminUid, actorName, reauthVerified = true)
        .onSuccess { _statusBanner.value = "Revoked global admin role." }
        .onFailure { _statusBanner.value = "Backend denied revoking admin role." }
    }
  }

  fun toggleUserAccountSuspension(
    targetUserId: String,
    suspend: Boolean,
    actorName: String,
  ) {
    viewModelScope.launch {
      repository.setAccountSuspensionStatus(targetUserId, suspend, actorName, reauthVerified = true)
        .onSuccess {
          _statusBanner.value = if (suspend) "Account suspended." else "Account restored."
        }
        .onFailure {
          _statusBanner.value = "Backend denied suspension (Super Owner cannot be suspended)."
        }
    }
  }

  private companion object {
    const val TAG = "JuiSocialVM"
  }
}
