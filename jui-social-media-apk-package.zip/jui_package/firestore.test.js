const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const SUPER_OWNER_UID = "owner_super_001";
const ADMIN_UID = "admin_mod_002";
const ALICE_UID = "alice_user_003";
const BOB_UID = "bob_user_004";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function serverNow() {
  return new Date();
}

async function seedSuperOwnerAndAdmin() {
  const now = serverNow();
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const db = context.firestore();
    await db.collection("platform_config").doc("super_owner").set({
      ownerUid: SUPER_OWNER_UID,
      ownerName: "Founder Super Owner",
      platformStatus: "ONLINE",
      allowPublicRegistration: true,
      requireModerationForAllVideos: true,
      reauthVerified: true,
      createdAt: now,
      updatedAt: now,
    });
    await db.collection("users").doc(SUPER_OWNER_UID).set({
      userId: SUPER_OWNER_UID,
      username: "jui_owner",
      displayName: "Founder Super Owner",
      bio: "Official JUI Social Madia Super Owner",
      avatarUrl: "",
      isPrivate: false,
      ageVerified: true,
      accountStatus: "ACTIVE",
      followersCount: 0,
      followingCount: 0,
      uploadedVideosCount: 0,
      createdAt: now,
      updatedAt: now,
    });
    await db.collection("admin_roles").doc(ADMIN_UID).set({
      adminUid: ADMIN_UID,
      adminName: "Video Moderator",
      assignedByUid: SUPER_OWNER_UID,
      canApproveVideos: true,
      canModerateComments: true,
      canManageReports: false,
      canManageGroups: false,
      canManageAppeals: false,
      reauthVerified: true,
      createdAt: now,
      updatedAt: now,
    });
  });
}

test("1. Unauthenticated callers cannot read videos, users, or platform config", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("videos").get());
  await assertFails(unauthDb.collection("users").get());
  await assertFails(unauthDb.collection("platform_config").doc("super_owner").get());
});

test("2. Duplicate usernames are rejected on registration", async () => {
  const now = serverNow();
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(
    aliceDb.collection("usernames").doc("alice_jui").set({
      username: "alice_jui",
      userId: ALICE_UID,
      createdAt: now,
    })
  );

  // Bob attempting to claim the same username must fail
  await assertFails(
    bobDb.collection("usernames").doc("alice_jui").set({
      username: "alice_jui",
      userId: BOB_UID,
      createdAt: now,
    })
  );
});

test("3. Video upload must start as PENDING and pending videos remain private until approved", async () => {
  await seedSuperOwnerAndAdmin();
  const now = serverNow();
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID).firestore();

  const baseVideo = {
    authorUid: ALICE_UID,
    authorUsername: "alice_jui",
    authorDisplayName: "Alice",
    caption: "Welcome to JUI Social Madia #jui",
    hashtags: "#jui #shortvideo",
    videoUrl: "https://storage.googleapis.com/jui-media/vid_1.mp4",
    thumbnailUrl: "",
    audioTitle: "JUI Original Synth",
    audioLicense: "CC-BY-4.0 Attribution",
    fileMimeType: "video/mp4",
    fileSizeBytes: 4500000,
    durationSeconds: 18,
    status: "PENDING",
    rejectionReason: "",
    moderatedByUid: "",
    likesCount: 0,
    commentsCount: 0,
    sharesCount: 0,
    viewsCount: 0,
    savesCount: 0,
    createdAt: now,
    updatedAt: now,
  };

  // Attempting to bypass moderation by uploading directly as APPROVED must fail
  await assertFails(
    aliceDb.collection("videos").doc("vid_bypass").set({
      ...baseVideo,
      status: "APPROVED",
    })
  );

  // Valid PENDING upload succeeds
  await assertSucceeds(aliceDb.collection("videos").doc("vid_1").set(baseVideo));

  // Bob (another user) CANNOT read Alice's PENDING video directly or via list
  await assertFails(bobDb.collection("videos").doc("vid_1").get());
  await assertFails(bobDb.collection("videos").where("status", "==", "PENDING").get());

  // Alice (uploader) and Video Moderator CAN read the PENDING video
  await assertSucceeds(aliceDb.collection("videos").doc("vid_1").get());
  await assertSucceeds(adminDb.collection("videos").doc("vid_1").get());

  // Bob CANNOT approve Alice's video
  await assertFails(
    bobDb.collection("videos").doc("vid_1").update({
      status: "APPROVED",
      moderatedByUid: BOB_UID,
      updatedAt: serverNow(),
    })
  );

  // Authorized Video Moderator CAN approve Alice's video
  await assertSucceeds(
    adminDb.collection("videos").doc("vid_1").update({
      status: "APPROVED",
      rejectionReason: "",
      moderatedByUid: ADMIN_UID,
      updatedAt: serverNow(),
    })
  );

  // Now that vid_1 is APPROVED, Bob can view it and query approved public feed
  await assertSucceeds(bobDb.collection("videos").doc("vid_1").get());
  await assertSucceeds(bobDb.collection("videos").where("status", "==", "APPROVED").get());
});

test("4. Permanent Super Owner protection: unauthorized owner-demotion, owner-deletion, and privilege escalation are DENIED", async () => {
  await seedSuperOwnerAndAdmin();
  const now = serverNow();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID).firestore();
  const superOwnerDb = testEnv.authenticatedContext(SUPER_OWNER_UID).firestore();

  // A. Ordinary admin attempting to demote or replace Super Owner -> DENIED
  await assertFails(
    adminDb.collection("platform_config").doc("super_owner").update({
      ownerUid: ADMIN_UID,
      reauthVerified: true,
      updatedAt: now,
    })
  );

  // B. Ordinary admin or even Super Owner attempting to delete Super Owner config -> DENIED
  await assertFails(adminDb.collection("platform_config").doc("super_owner").delete());
  await assertFails(superOwnerDb.collection("platform_config").doc("super_owner").delete());

  // C. Attempting to delete, suspend, or block the Super Owner user account -> DENIED
  await assertFails(adminDb.collection("users").doc(SUPER_OWNER_UID).delete());
  await assertFails(
    adminDb.collection("users").doc(SUPER_OWNER_UID).update({
      accountStatus: "SUSPENDED",
      updatedAt: now,
    })
  );
  await assertFails(
    adminDb.collection("blocks").doc(`${ADMIN_UID}_${SUPER_OWNER_UID}`).set({
      blockerUid: ADMIN_UID,
      blockedUid: SUPER_OWNER_UID,
      blockedUsername: "jui_owner",
      reason: "Attempt to block owner",
      createdAt: now,
    })
  );

  // D. Ordinary admin attempting privilege escalation (granting themselves canManageGroups or creating another admin) -> DENIED
  await assertFails(
    adminDb.collection("admin_roles").doc(ADMIN_UID).update({
      canManageGroups: true,
      assignedByUid: ADMIN_UID,
      reauthVerified: true,
      updatedAt: now,
    })
  );
  await assertFails(
    adminDb.collection("admin_roles").doc(BOB_UID).set({
      adminUid: BOB_UID,
      adminName: "Bob Escalated",
      assignedByUid: ADMIN_UID,
      canApproveVideos: true,
      canModerateComments: true,
      canManageReports: true,
      canManageGroups: true,
      canManageAppeals: true,
      reauthVerified: true,
      createdAt: now,
      updatedAt: now,
    })
  );

  // E. Super Owner CAN update admin permissions and write/read append-only audit logs
  await assertSucceeds(
    superOwnerDb.collection("admin_roles").doc(ADMIN_UID).update({
      canManageReports: true,
      assignedByUid: SUPER_OWNER_UID,
      reauthVerified: true,
      updatedAt: now,
    })
  );
  await assertSucceeds(
    superOwnerDb.collection("audit_logs").doc("log_001").set({
      actorUid: SUPER_OWNER_UID,
      actorName: "Founder Super Owner",
      action: "GRANT_ADMIN_PERMISSION",
      targetId: ADMIN_UID,
      targetType: "ADMIN_ROLE",
      result: "SUCCESS",
      details: "Granted canManageReports to moderator",
      reauthVerified: true,
      createdAt: now,
    })
  );

  // F. Audit logs are strictly append-only (cannot be updated or deleted, and non-owners cannot read them)
  await assertFails(adminDb.collection("audit_logs").doc("log_001").get());
  await assertFails(superOwnerDb.collection("audit_logs").doc("log_001").delete());
  await assertFails(
    superOwnerDb.collection("audit_logs").doc("log_001").update({
      details: "Tampered log",
    })
  );
});

test("5. Private messages are isolated to participants and enforce user blocking", async () => {
  await seedSuperOwnerAndAdmin();
  const now = serverNow();
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID).firestore();

  await assertSucceeds(
    aliceDb.collection("messages").doc("msg_1").set({
      conversationId: "conv_alice_bob",
      senderUid: ALICE_UID,
      senderName: "Alice",
      recipientUid: BOB_UID,
      participantUids: [ALICE_UID, BOB_UID],
      text: "Hello Bob on JUI Social Madia!",
      isRead: false,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Alice and Bob can read the message; ordinary admin CANNOT read private messages
  await assertSucceeds(aliceDb.collection("messages").doc("msg_1").get());
  await assertSucceeds(bobDb.collection("messages").doc("msg_1").get());
  await assertFails(adminDb.collection("messages").doc("msg_1").get());

  // Bob blocks Alice; Alice can no longer send Bob a message
  await assertSucceeds(
    bobDb.collection("blocks").doc(`${BOB_UID}_${ALICE_UID}`).set({
      blockerUid: BOB_UID,
      blockedUid: ALICE_UID,
      blockedUsername: "alice_jui",
      reason: "Unwanted messages",
      createdAt: now,
    })
  );

  await assertFails(
    aliceDb.collection("messages").doc("msg_2").set({
      conversationId: "conv_alice_bob",
      senderUid: ALICE_UID,
      senderName: "Alice",
      recipientUid: BOB_UID,
      participantUids: [ALICE_UID, BOB_UID],
      text: "Blocked message attempt",
      isRead: false,
      createdAt: serverNow(),
      updatedAt: serverNow(),
    })
  );
});

test("6. Group post approval workflow enforces PENDING status when requirePostApproval is enabled", async () => {
  await seedSuperOwnerAndAdmin();
  const now = serverNow();
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  // Alice creates a group with requirePostApproval = true
  await assertSucceeds(
    aliceDb.collection("groups").doc("grp_creators").set({
      name: "JUI Creators Hub",
      description: "Official short-video creators community",
      creatorUid: ALICE_UID,
      creatorName: "Alice",
      requirePostApproval: true,
      isPublic: true,
      membersCount: 1,
      moderatorUids: [ALICE_UID],
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertSucceeds(
    aliceDb.collection("group_members").doc(`grp_creators_${ALICE_UID}`).set({
      groupId: "grp_creators",
      userId: ALICE_UID,
      username: "alice_jui",
      role: "CREATOR",
      status: "APPROVED",
      moderatorUids: [ALICE_UID],
      createdAt: now,
      updatedAt: now,
    })
  );

  // Bob requests membership -> PENDING, then Alice approves Bob -> APPROVED
  await assertSucceeds(
    bobDb.collection("group_members").doc(`grp_creators_${BOB_UID}`).set({
      groupId: "grp_creators",
      userId: BOB_UID,
      username: "bob_jui",
      role: "MEMBER",
      status: "PENDING",
      moderatorUids: [ALICE_UID],
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertSucceeds(
    aliceDb.collection("group_members").doc(`grp_creators_${BOB_UID}`).update({
      status: "APPROVED",
      updatedAt: serverNow(),
    })
  );

  // Bob cannot publish directly as APPROVED because requirePostApproval is true
  await assertFails(
    bobDb.collection("group_posts").doc("gpost_bypass").set({
      groupId: "grp_creators",
      authorUid: BOB_UID,
      authorName: "Bob",
      contentType: "TEXT",
      text: "Direct approved post bypass",
      mediaUrl: "",
      status: "APPROVED",
      moderatedByUid: "",
      moderatorUids: [ALICE_UID],
      createdAt: serverNow(),
      updatedAt: serverNow(),
    })
  );

  // Bob submits post as PENDING -> succeeds
  await assertSucceeds(
    bobDb.collection("group_posts").doc("gpost_1").set({
      groupId: "grp_creators",
      authorUid: BOB_UID,
      authorName: "Bob",
      contentType: "TEXT",
      text: "My pending group post for review",
      mediaUrl: "",
      status: "PENDING",
      moderatedByUid: "",
      moderatorUids: [ALICE_UID],
      createdAt: serverNow(),
      updatedAt: serverNow(),
    })
  );

  // Alice (group creator/moderator) approves the post -> succeeds
  await assertSucceeds(
    aliceDb.collection("group_posts").doc("gpost_1").update({
      status: "APPROVED",
      moderatedByUid: ALICE_UID,
      updatedAt: serverNow(),
    })
  );
});
