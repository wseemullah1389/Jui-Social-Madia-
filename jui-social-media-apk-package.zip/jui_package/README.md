# JUI Social Madia — Native Android Application

**JUI Social Madia** is a complete native Android short-video, community groups, private messaging, and moderated governance application built with **Kotlin**, **Jetpack Compose (Material 3)**, **Firebase Authentication (Google Sign-In via Jetpack Credential Manager)**, and **Cloud Firestore (Enterprise Edition)** with zero-trust backend security rules.

---

## 1. Branding & Application Identity
- **Exact Display Name**: `JUI Social Madia` (configured in `app/src/main/res/values/strings.xml`, `settings.gradle.kts`, and `metadata.json`).
- **Application ID**: `com.aistudio.juisocialmadia.vqxkpm` (configured in `app/build.gradle.kts`).
  - **How to change the Application ID**: Edit `defaultConfig { applicationId = "com.yourcompany.juisocialmadia" }` in `app/build.gradle.kts`, then re-register the package name and SHA-1/SHA-256 certificate fingerprints in your Firebase Project Settings and download the updated `app/google-services.json`.
- **Custom Adaptive Icon & Logo Assets**:
  - Adaptive launcher icon configured in `app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml`, `ic_launcher_foreground.xml`, `ic_launcher_background.xml`, and density-specific PNGs (`mdpi` through `xxxhdpi`).
  - Vector/Canvas `JuiLogoBadge`, `JuiWordmarkHeader`, and `JuiSplashScreen` in `app/src/main/java/com/example/ui/components/JuiBrandingComponents.kt`.

---

## 2. Architecture & Backend Security Model

### Clean Architecture Layers
1. **Models (`app/src/main/java/com/example/data/model/JuiModels.kt`)**:
   - Type-safe `@IgnoreExtraProperties` data classes with `@DocumentId` and `@ServerTimestamp`:
     `SuperOwnerConfig`, `AdminRole`, `AuditLog`, `UserProfile`, `UsernameRecord`, `FollowRecord`, `BlockRecord`, `ShortVideo`, `VideoComment`, `VideoInteraction`, `Conversation`, `PrivateMessage`, `AppNotification`, `CommunityGroup`, `GroupMember`, `GroupPost`, `ModerationReport`.
2. **Repository & Error Diagnostics (`app/src/main/java/com/example/data/repository/`)**:
   - `JuiSocialRepository.kt`: Connects to the provisioned named Firestore database (`R.string.firestore_database_id`).
   - `FirestoreErrorHandler.kt`: Structured JSON error logger (`handleFirestoreError`).
3. **ViewModel (`app/src/main/java/com/example/ui/JuiSocialViewModel.kt`)**:
   - Exposes lifecycle-aware `StateFlow` streams and user/moderator/owner actions.
4. **Compose UI (`app/src/main/java/com/example/ui/screens/` & `ui/auth/`)**:
   - Adaptive `NavigationBar` (phones) and `NavigationRail` (tablets/foldables) with full edge-to-edge support.

### Zero-Trust Firestore Security Rules (`/firestore.rules` & `/firebase-blueprint.json`)
- **Video Approval Isolation (`/videos/{videoId}`)**:
  - Every uploaded video must be created with `status == 'PENDING'`, valid MIME type (`video/mp4`, `video/webm`, `video/quicktime`), and `fileSizeBytes <= 104857600` (100 MB).
  - Pending and rejected videos are strictly hidden from public `get` and `list` queries; only `status == 'APPROVED'`, the uploader (`authorUid == request.auth.uid`), or moderators with `canApproveVideos == true` can read them.
- **Permanent Super Owner Protection (`/platform_config/super_owner`)**:
  - Established via one-time server-side creation (`!exists(/databases/$(database)/documents/platform_config/super_owner)`) with `reauthVerified == true`.
  - `ownerUid` is strictly immutable (`incoming().ownerUid == existing().ownerUid`) and `allow delete: if false`.
  - Ordinary admins cannot demote, delete, suspend, block, or replace the Super Owner.
- **Granular Admin Permissions (`/admin_roles/{adminUid}`)**:
  - Only the Super Owner can create, update, or delete `/admin_roles/{adminUid}`.
  - Admins cannot grant themselves extra privileges or alter their own permission boundaries.
- **Append-Only Administrative Audit Log (`/audit_logs/{logId}`)**:
  - Viewable only by the Super Owner; `allow update, delete: if false`.
- **Private Messaging Isolation (`/conversations/{conversationId}`, `/messages/{messageId}`)**:
  - Strictly isolated to the two participants (`request.auth.uid in resource.data.participantUids`). Ordinary admins cannot snoop on private messages. Enforces user blocklists (`/blocks/{blockId}`).
- **Group Moderation (`/groups/{groupId}`, `/group_members/{membershipId}`, `/group_posts/{postId}`)**:
  - Supports `CREATOR`, `GROUP_ADMIN`, `MODERATOR`, and `MEMBER` roles and optional post approval (`requirePostApproval`).

---

## 3. Environment Variables & Third-Party Services
- See `/.env.example` for environment variable configuration managed via the Secrets Gradle Plugin.
- **Firebase Auth & Cloud Firestore (Enterprise Edition)**:
  - Configured via `app/google-services.json` and `app/src/main/res/values/firebase_applet_config.xml`.
  - Free-tier Spark limits apply to daily document reads/writes/deletes; see https://firebase.google.com/pricing.

---

## 4. Running Automated Tests
1. **JavaScript Firestore Security Rules Tests (`firestore.test.js`)**:
   ```bash
   FIRESTORE_EMULATOR_HOST="127.0.0.1:8085" node --test firestore.test.js
   ```
2. **Android Robolectric JVM & Emulator Integration Tests**:
   ```bash
   gradle :app:testDebugUnitTest
   ```

---

## 5. Building & Installing the Android APK
- **Build Debug APK**:
  ```bash
  gradle :app:assembleDebug
  ```
  Output location: `app/build/outputs/apk/debug/app-debug.apk`
- **Build Signed Release APK**:
  Set environment variables `KEYSTORE_PATH`, `STORE_PASSWORD`, and `KEY_PASSWORD` for your upload keystore, then run:
  ```bash
  gradle :app:assembleRelease
  ```
  Output location: `app/build/outputs/apk/release/app-release.apk`
- **Install on a Physical Android Device or Local Emulator**:
  ```bash
  adb install -r app/build/outputs/apk/debug/app-debug.apk
  ```
  *(Note: In this cloud build container, there is no attached physical USB device or local `adb` daemon; the APK is built and verified on disk and automatically streamed to the browser preview emulator.)*
